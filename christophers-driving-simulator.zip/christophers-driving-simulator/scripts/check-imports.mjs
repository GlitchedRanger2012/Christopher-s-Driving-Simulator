// scripts/check-imports.mjs
// Dev tool: statically verifies every `import ... from '...'` in client/ and
// shared/ resolves to a real file, and that every named import is actually
// exported by that file. Doesn't require a browser or executing the code
// (which we can't fully do here anyway, since much of it needs THREE/DOM) —
// it's a lightweight but genuine defense against typo'd paths and
// import/export name mismatches, which are exactly the kind of bug that
// would otherwise only show up as a console error in an actual browser.

import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs';
import { dirname, join, resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');

function walk(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      if (entry === 'node_modules') continue;
      walk(full, out);
    } else if (extname(entry) === '.js') {
      out.push(full);
    }
  }
  return out;
}

function getExports(filePath) {
  const src = readFileSync(filePath, 'utf-8');
  const names = new Set();
  for (const m of src.matchAll(/export\s+(?:class|function|const|let|var)\s+([A-Za-z0-9_$]+)/g)) names.add(m[1]);
  for (const m of src.matchAll(/export\s+\{([^}]+)\}/g)) {
    for (const part of m[1].split(',')) {
      const name = part.trim().split(/\s+as\s+/).pop().trim();
      if (name) names.add(name);
    }
  }
  const hasDefault = /export\s+default\s+/.test(src);
  const hasStarExport = /export\s+\*\s+from/.test(src);
  return { names, hasDefault, hasStarExport };
}

const files = [...walk(join(ROOT, 'client')), ...walk(join(ROOT, 'shared'))];
let problems = 0;

for (const file of files) {
  const src = readFileSync(file, 'utf-8');
  const importRe = /import\s+(?:([A-Za-z0-9_$]+)\s*,\s*)?(?:\{([^}]*)\}|(\*\s+as\s+[A-Za-z0-9_$]+))?\s*from\s*['"]([^'"]+)['"]/g;
  let m;
  while ((m = importRe.exec(src))) {
    const [, defaultImport, namedImports, , specifier] = m;
    if (specifier.startsWith('http://') || specifier.startsWith('https://')) continue; // CDN — can't check without network

    const resolved = resolve(dirname(file), specifier);
    if (!existsSync(resolved)) {
      console.error(`FAIL: ${rel(file)} imports "${specifier}" — file not found (resolved: ${rel(resolved)})`);
      problems += 1;
      continue;
    }

    const target = getExports(resolved);
    if (target.hasStarExport) continue; // re-exports an external module — trust it

    if (namedImports) {
      for (const raw of namedImports.split(',')) {
        const name = raw.trim().split(/\s+as\s+/)[0].trim();
        if (!name) continue;
        if (!target.names.has(name)) {
          console.error(`FAIL: ${rel(file)} imports { ${name} } from "${specifier}" — not exported by ${rel(resolved)}`);
          problems += 1;
        }
      }
    }
    if (defaultImport && !target.hasDefault) {
      console.error(`FAIL: ${rel(file)} default-imports from "${specifier}" — no default export in ${rel(resolved)}`);
      problems += 1;
    }
  }
}

function rel(p) {
  return p.replace(ROOT + '/', '');
}

console.log(`Checked ${files.length} files.`);
if (problems === 0) {
  console.log('PASS: every local import resolves to a real file and a real export.');
  process.exit(0);
} else {
  console.error(`${problems} problem(s) found.`);
  process.exit(1);
}
