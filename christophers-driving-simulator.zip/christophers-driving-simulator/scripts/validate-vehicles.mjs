// scripts/validate-vehicles.mjs
// Dev tool: run with `node scripts/validate-vehicles.mjs`.
// Fails (non-zero exit) if the vehicle catalog has duplicate ids, missing
// fields, out-of-range stats, or any other structural problem. Run this after
// editing shared/vehicleData.js, especially after adding new cars.

import { VEHICLES, CATEGORY_LIST } from '../shared/vehicleData.js';

const REQUIRED_FIELDS = [
  'id', 'name', 'category', 'mass', 'acceleration', 'topSpeed', 'braking',
  'handling', 'grip', 'steering', 'drivetrain', 'dimensions', 'color', 'accentColor',
];
const DRIVETRAINS = new Set(['FWD', 'RWD', 'AWD']);
const HEX_RE = /^#[0-9A-Fa-f]{6}$/;

let failures = 0;
const fail = (msg) => { failures += 1; console.error(`FAIL: ${msg}`); };

console.log(`Validating ${VEHICLES.length} vehicles...`);

if (VEHICLES.length !== 45) {
  fail(`expected exactly 45 vehicles, found ${VEHICLES.length}`);
}

const seenIds = new Set();
const seenNames = new Set();
const countByCategory = {};

for (const v of VEHICLES) {
  for (const field of REQUIRED_FIELDS) {
    if (v[field] === undefined || v[field] === null) {
      fail(`${v.id || v.name || '(unknown)'} is missing required field "${field}"`);
    }
  }

  if (seenIds.has(v.id)) fail(`duplicate id "${v.id}"`);
  seenIds.add(v.id);

  if (seenNames.has(v.name)) fail(`duplicate name "${v.name}"`);
  seenNames.add(v.name);

  if (!CATEGORY_LIST.includes(v.category)) {
    fail(`${v.id}: unknown category "${v.category}"`);
  }
  countByCategory[v.category] = (countByCategory[v.category] || 0) + 1;

  if (!DRIVETRAINS.has(v.drivetrain)) fail(`${v.id}: invalid drivetrain "${v.drivetrain}"`);

  if (!(v.mass > 0 && v.mass < 6000)) fail(`${v.id}: implausible mass ${v.mass}`);
  if (!(v.acceleration > 0 && v.acceleration < 30)) fail(`${v.id}: implausible acceleration ${v.acceleration}`);
  if (!(v.topSpeed > 0 && v.topSpeed < 500)) fail(`${v.id}: implausible topSpeed ${v.topSpeed}`);
  if (!(v.braking > 0 && v.braking < 150)) fail(`${v.id}: implausible braking ${v.braking}`);
  for (const stat of ['handling', 'grip', 'steering']) {
    if (!(v[stat] >= 0 && v[stat] <= 100)) fail(`${v.id}: ${stat} ${v[stat]} out of 0-100 range`);
  }

  const { length, width, height } = v.dimensions || {};
  if (!(length > 1 && length < 10)) fail(`${v.id}: implausible length ${length}`);
  if (!(width > 0.5 && width < 4)) fail(`${v.id}: implausible width ${width}`);
  if (!(height > 0.5 && height < 4)) fail(`${v.id}: implausible height ${height}`);

  if (!HEX_RE.test(v.color)) fail(`${v.id}: color "${v.color}" is not a #RRGGBB hex string`);
  if (!HEX_RE.test(v.accentColor)) fail(`${v.id}: accentColor "${v.accentColor}" is not a #RRGGBB hex string`);
}

console.log('Vehicles per category:', countByCategory);

if (failures === 0) {
  console.log('PASS: all 45 vehicles have valid, distinct, in-range data.');
  process.exit(0);
} else {
  console.error(`${failures} validation failure(s).`);
  process.exit(1);
}
