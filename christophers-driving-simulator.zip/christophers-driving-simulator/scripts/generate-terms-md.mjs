// scripts/generate-terms-md.mjs
// Run with `node scripts/generate-terms-md.mjs` after editing
// shared/termsContent.js. Writes TERMS_OF_SERVICE.md at the repo root.

import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { TERMS_SECTIONS, TERMS_EFFECTIVE_DATE } from '../shared/termsContent.js';
import { TERMS_VERSION, GAME_TITLE } from '../shared/constants.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const outPath = join(__dirname, '..', 'TERMS_OF_SERVICE.md');

function renderBody(body) {
  return body
    .map((item) => {
      if (typeof item === 'string') return item + '\n';
      if (item.ul) return item.ul.map((li) => `- ${li}`).join('\n') + '\n';
      return '';
    })
    .join('\n');
}

const lines = [];
lines.push(`# ${GAME_TITLE} — Terms of Service`);
lines.push('');
lines.push(`Version ${TERMS_VERSION} · Effective ${TERMS_EFFECTIVE_DATE}`);
lines.push('');
lines.push(
  '> This document is auto-generated from `shared/termsContent.js` — the same data the in-game ' +
  'Terms of Service screen renders. Edit that file and re-run `node scripts/generate-terms-md.mjs` ' +
  'rather than editing this file directly, or the two will drift out of sync.',
);
lines.push('');

for (const section of TERMS_SECTIONS) {
  lines.push(`## ${section.heading}`);
  lines.push('');
  lines.push(renderBody(section.body).trim());
  lines.push('');
}

lines.push('---');
lines.push('');
lines.push(
  '**This is a template drafted for a hobby project and is not legal advice.** ' +
  'Christopher Ranger (or whoever deploys this project) should have it reviewed by a ' +
  'lawyer before relying on it for a real public release, especially the placeholder ' +
  'governing-law and contact sections above.',
);
lines.push('');

writeFileSync(outPath, lines.join('\n'), 'utf-8');
console.log(`Wrote ${outPath}`);
