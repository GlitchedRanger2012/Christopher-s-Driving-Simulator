# Christopher's Driving Simulator — Privacy Notes

This is a short, plain description of what data the Game actually handles.
It's written to be accurate to the code in this repository, not a formal
legal privacy policy — see the note at the end.

## Stored in your browser (localStorage)

All of this stays on your device and is never sent anywhere:

- Whether you've accepted the current Terms of Service, and when.
- Your graphics, audio, and gameplay settings.
- Your key bindings.
- The driver name you last used in multiplayer.
- The last vehicle you selected.

You can clear all of it at any time by clearing this site's data in your
browser settings.

## Sent to the multiplayer server (multiplayer mode only)

Singleplayer never contacts any server. If you use multiplayer, your browser
sends the multiplayer server:

- The driver name you typed in.
- Your selected vehicle.
- Your in-game position and rotation, at a throttled rate, for the duration
  of your session — this is how other players see your car move.
- Your IP address, incidentally, as part of the normal WebSocket/HTTP
  connection (the same way any web server sees the IP address of a client
  that connects to it). The server code in this repository does not log,
  store, or otherwise persist IP addresses beyond what's needed to maintain
  your live connection.
- A numeric ID when you use a quick-chat preset message, so other players
  see which phrase you sent.

None of this is written to a database in the version of the server in this
repository — it's held in memory for the duration of your connection and
discarded when you disconnect. If whoever deploys the server modifies it to
add persistence, accounts, or analytics, this document should be updated to
match.

## Third-party services

- If a multiplayer server is deployed, your connection to it depends on
  wherever it's hosted (see README.md) — that host's own privacy practices
  apply to the network layer.
- The game loads Three.js, Socket.IO, and Google Fonts from third-party CDNs
  (see THIRD_PARTY_LICENSES.md for the exact URLs). Those requests are
  subject to the relevant CDN provider's own privacy practices, the same as
  any other website that uses a public CDN.

## No accounts, no analytics, no ads

As of this version, the Game has no user accounts, no analytics or
tracking scripts, and shows no ads.

---

**This is a plain description for a hobby project, not a legal privacy
policy.** If you deploy this project publicly — especially anywhere with
users who may be covered by GDPR, CCPA, or similar laws — have an actual
privacy policy drafted or reviewed by a lawyer before relying on this
document.
