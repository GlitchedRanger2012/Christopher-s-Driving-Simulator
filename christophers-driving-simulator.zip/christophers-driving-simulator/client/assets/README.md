# client/assets/

This folder is intentionally close to empty. Christopher's Driving Simulator
currently uses no external image, model, or audio files:

- Vehicle appearances are built procedurally from primitive geometry —
  see `client/js/vehicles/VehicleFactory.js`.
- The city, ramps, and props are built procedurally — see
  `client/js/world/World.js` and `TrackGenerator.js`.
- All audio is synthesized at runtime with the WebAudio API — see
  `client/js/core/AudioManager.js`.

This was a deliberate choice (see README.md "Known limitations" and
THIRD_PARTY_LICENSES.md) to avoid shipping any asset without a clear,
checked license.

**If you add real assets** (3D models, textures, music, sound effects):

1. Put them in a subfolder here, e.g. `client/assets/models/`,
   `client/assets/audio/`.
2. Record their source and license in `THIRD_PARTY_LICENSES.md` before
   distributing your build — don't skip this even for "free" assets; check
   what license they actually carry.
3. If you don't have redistribution rights for an asset, don't commit it to
   the repository — document where a properly licensed replacement should go
   instead, the same way this project documents the lack of asset files here
   rather than pretending they exist.
