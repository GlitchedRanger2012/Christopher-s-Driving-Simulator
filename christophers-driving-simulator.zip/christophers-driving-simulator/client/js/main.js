// client/js/main.js
// Boot sequence: check WebGL support -> load Three.js -> init input/audio ->
// build the GameStateManager -> gate on Terms acceptance -> show the menu.
// Each step is real (see core/LoadingManager.js) — the percentage shown on
// the loading screen reflects actual completed steps, not a timer.

import { isWebGLAvailable } from './core/Engine.js';
import { LoadingManager } from './core/LoadingManager.js';
import { InputManager } from './core/InputManager.js';
import { AudioManager } from './core/AudioManager.js';
import { SaveManager } from './core/SaveManager.js';
import { GameStateManager } from './game/GameStateManager.js';

function setLoadingUI(progress) {
  document.getElementById('loading-bar-fill').style.width = `${progress.percent}%`;
  document.getElementById('loading-percent').textContent = `${progress.percent}%`;
  document.getElementById('loading-task').textContent = progress.currentLabel;
}

async function boot() {
  const settings = SaveManager.loadSettings();
  if (settings.gameplay.reducedMotion) document.body.classList.add('reduced-motion');

  if (!isWebGLAvailable()) {
    document.getElementById('error-message').textContent =
      "Your browser doesn't appear to support WebGL, which Christopher's Driving Simulator needs to render. " +
      'Try updating your browser or enabling hardware acceleration, then reload.';
    showScreen('error');
    return;
  }

  const loader = new LoadingManager(setLoadingUI);
  let inputManager, audio, game;

  try {
    await loader.step('Loading renderer', async () => {
      // Actually resolves the Three.js CDN module — a real network step, not
      // a fake delay. If this fails (offline, CDN blocked), the whole boot
      // fails loudly here rather than crashing later mid-scene-build.
      await import('./vendor/three.js');
    });

    await loader.step('Setting up controls', () => {
      inputManager = new InputManager();
    });

    await loader.step('Preparing audio', () => {
      audio = new AudioManager();
      // Actual unlock happens on first user gesture (browsers require it);
      // this just constructs the manager so it's ready to unlock.
    }, { optional: true });

    await loader.step('Loading vehicle catalog', async () => {
      const { VEHICLES } = await import('../../shared/vehicleData.js');
      if (VEHICLES.length !== 45) throw new Error(`Expected 45 vehicles, found ${VEHICLES.length}`);
    });

    await loader.step('Building menus', () => {
      game = new GameStateManager({ inputManager, audio, settings });
    });
  } catch (err) {
    console.error('[boot] fatal error during startup:', err);
    document.getElementById('error-message').textContent =
      `Something failed while starting the game: ${err.message}. Check the browser console for details.`;
    showScreen('error');
    return;
  }

  if (loader.failed.length) {
    console.warn('[boot] non-fatal issues during startup:', loader.failed);
  }

  // Unlock audio on the very first user gesture anywhere in the document —
  // required by every modern browser's autoplay policy.
  const unlockAudio = () => { audio.unlock(); document.removeEventListener('pointerdown', unlockAudio); document.removeEventListener('keydown', unlockAudio); };
  document.addEventListener('pointerdown', unlockAudio, { once: true });
  document.addEventListener('keydown', unlockAudio, { once: true });

  document.getElementById('terms-decline') && document.getElementById('terms-decline').blur();

  if (game.hasAcceptedTerms()) {
    showScreen('mainmenu');
    game.mainMenu.focusDefault();
  } else {
    game.showTermsGate();
  }

  window.__christophersDrivingSimulator = { game }; // convenience hook for manual console testing
}

function showScreen(id) {
  for (const el of document.querySelectorAll('.screen')) {
    el.classList.toggle('screen--active', el.id === `screen-${id}`);
  }
}

boot();
