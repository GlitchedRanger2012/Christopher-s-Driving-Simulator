// client/js/game/SingleplayerSession.js
import { Engine } from '../core/Engine.js';
import { World } from '../world/World.js';
import { ChaseCamera } from '../camera/ChaseCamera.js';
import { VehicleController } from '../vehicles/VehicleController.js';
import { getVehicle } from '../../../shared/vehicleData.js';
import { SPAWN_POINTS } from '../../../shared/constants.js';

export class SingleplayerSession {
  constructor({ container, settings, inputManager, audio, hud }) {
    this.container = container;
    this.inputManager = inputManager;
    this.audio = audio;
    this.hud = hud;
    this.engine = new Engine(container, settings);
    this.world = new World(this.engine.scene);
    this.camera = new ChaseCamera(container.clientWidth / Math.max(1, container.clientHeight));
    this.camera.setDistanceMultiplier(settings.gameplay.cameraDistance);
    this.camera.setSensitivity(settings.gameplay.cameraSensitivity);
    this.engine.setActiveCamera(this.camera.camera);

    this.paused = false;
    this.player = null;
    this._unsubscribe = null;
  }

  start(vehicleId) {
    const vehicle = getVehicle(vehicleId);
    const spawn = SPAWN_POINTS[0];
    this.player = new VehicleController(vehicle, spawn, { audio: this.audio });
    this.player.attachTo(this.engine.scene);
    this.player.startAudio();
    this.camera.resetBehindVehicle(this.player.physics.position, this.player.physics.yaw);
    this.hud.setVehicleName(vehicle.name);
    this.hud.setConnectionStatus('', false);

    this._unsubscribe = this.engine.onFrame((dt) => this._frame(dt));
    this.engine.start();
  }

  _frame(dt) {
    if (this.paused) return;
    const input = this.inputManager.read();

    if (input.resetPressed) {
      this.player.physics.resetToSafePosition();
    }

    this.player.update(dt, input, this.world);
    this.camera.update(dt, this.player, input);
    this.hud.updateTelemetry(this.player.physics.getTelemetry());
    this.hud.updateMinimap(this.player.physics.getTransform(), this.world, []);
  }

  setPaused(paused) {
    this.paused = paused;
    if (paused) {
      this.player.stopAudio();
    } else {
      this.player.startAudio();
    }
  }

  applyGraphicsSettings(graphics) {
    this.engine.applyGraphicsSettings(graphics);
  }

  applyGameplaySettings(gameplay) {
    this.camera.setDistanceMultiplier(gameplay.cameraDistance);
    this.camera.setSensitivity(gameplay.cameraSensitivity);
  }

  dispose() {
    if (this._unsubscribe) this._unsubscribe();
    this.player?.stopAudio();
    this.engine.dispose();
  }
}
