// client/js/game/GameStateManager.js
import { MainMenu } from '../ui/MainMenu.js';
import { CarSelect } from '../ui/CarSelect.js';
import { SettingsMenu } from '../ui/SettingsMenu.js';
import { CreditsScreen } from '../ui/CreditsScreen.js';
import { TermsScreen } from '../ui/TermsScreen.js';
import { LobbyScreen } from '../ui/LobbyScreen.js';
import { HUD } from '../ui/HUD.js';
import { SingleplayerSession } from './SingleplayerSession.js';
import { MultiplayerSession } from './MultiplayerSession.js';
import { SaveManager } from '../core/SaveManager.js';

const SCREEN_IDS = [
  'loading', 'error', 'terms', 'declined', 'mainmenu', 'exit',
  'carselect', 'lobby', 'settings', 'credits', 'game',
];

export class GameStateManager {
  constructor({ inputManager, audio, settings }) {
    this.inputManager = inputManager;
    this.audio = audio;
    this.settings = settings;
    this.session = null;
    this.pendingCarSelectMode = 'singleplayer';
    this.previousScreen = 'mainmenu';

    this.hud = new HUD({ onQuickChat: (id) => this._onQuickChat(id) });

    this.mainMenu = new MainMenu({
      onSingleplayer: () => { this.pendingCarSelectMode = 'singleplayer'; this.carSelect.show('singleplayer'); this.showScreen('carselect'); },
      onMultiplayer: () => { this.pendingCarSelectMode = 'multiplayer'; this.carSelect.show('multiplayer'); this.showScreen('carselect'); },
      onSettings: () => { this.previousScreen = 'mainmenu'; this.showScreen('settings'); },
      onCredits: () => this.showScreen('credits'),
      onViewTerms: () => { this._termsViewOnly = true; this.termsScreen.show(); this.showScreen('terms'); },
      onExit: () => this.showScreen('exit'),
      onExitReturn: () => this.showScreen('mainmenu'),
    });

    this.carSelect = new CarSelect({
      onBack: () => this.showScreen('mainmenu'),
      onConfirm: (vehicleId) => this._onCarConfirmed(vehicleId),
    });

    this.settingsMenu = new SettingsMenu({
      inputManager,
      onGraphicsChange: (g) => this.session?.applyGraphicsSettings(g),
      onAudioChange: (a) => this.audio.applySettings(a),
      onGameplayChange: (gp) => this.session?.applyGameplaySettings(gp),
      onBack: () => this.showScreen(this.previousScreen),
    });

    this.creditsScreen = new CreditsScreen({ onBack: () => this.showScreen('mainmenu') });

    this.termsScreen = new TermsScreen({
      onAccept: () => {
        if (this._termsViewOnly) { this._termsViewOnly = false; this.showScreen('mainmenu'); }
        else this.showScreen('mainmenu');
      },
      onDecline: () => {
        if (this._termsViewOnly) { this._termsViewOnly = false; this.showScreen('mainmenu'); }
        else this.showScreen('declined');
      },
    });
    document.getElementById('declined-review').addEventListener('click', () => { this.termsScreen.show(); this.showScreen('terms'); });

    this.lobbyScreen = new LobbyScreen({
      onBack: () => this.showScreen('mainmenu'),
      onConnect: (name) => this._startMultiplayer(name),
    });

    this._wireGameChrome();
  }

  _wireGameChrome() {
    document.getElementById('hud-pause-btn').addEventListener('click', () => this.pause());
    document.getElementById('pause-resume').addEventListener('click', () => this.resume());
    document.getElementById('pause-settings').addEventListener('click', () => { this.previousScreen = 'game'; this.showScreen('settings'); });
    document.getElementById('pause-reset').addEventListener('click', () => { this.session?.player?.physics.resetToSafePosition(); this.resume(); });
    document.getElementById('pause-quit').addEventListener('click', () => this.quitToMenu());
    document.getElementById('error-reload').addEventListener('click', () => window.location.reload());

    window.addEventListener('keydown', (e) => {
      if (e.code !== 'Escape') return;
      if (this._currentScreen === 'game') this.paused ? this.resume() : this.pause();
    });
  }

  showScreen(id) {
    if (!SCREEN_IDS.includes(id)) {
      console.error(`[GameStateManager] showScreen("${id}") is not a known screen — falling back to mainmenu.`);
      id = 'mainmenu';
    }
    this._currentScreen = id;
    for (const s of SCREEN_IDS) {
      document.getElementById(`screen-${s}`).classList.toggle('screen--active', s === id);
    }
    if (id === 'mainmenu') this.mainMenu.focusDefault();
  }

  showFatalError(message) {
    document.getElementById('error-message').textContent = message;
    this.showScreen('error');
  }

  _onCarConfirmed(vehicleId) {
    if (this.pendingCarSelectMode === 'singleplayer') {
      this._startSingleplayer(vehicleId);
    } else {
      this._pendingVehicleId = vehicleId;
      this.lobbyScreen.show();
      this.showScreen('lobby');
    }
  }

  _startSingleplayer(vehicleId) {
    this._teardownSession();
    this.session = new SingleplayerSession({
      container: document.getElementById('render-target'),
      settings: this.settings,
      inputManager: this.inputManager,
      audio: this.audio,
      hud: this.hud,
    });
    this.inputManager.start();
    this.showScreen('game');
    this.session.start(vehicleId);
  }

  _startMultiplayer(playerName) {
    this._teardownSession();
    this.session = new MultiplayerSession({
      container: document.getElementById('render-target'),
      settings: this.settings,
      inputManager: this.inputManager,
      audio: this.audio,
      hud: this.hud,
      lobbyScreen: this.lobbyScreen,
    });
    this.session.onEnteredGame = () => this.showScreen('game');
    this.session.onQuickChatReceived = (id, messageId) => this._showRemoteQuickChat(id, messageId);
    this.inputManager.start();
    this.session.connect(playerName, this._pendingVehicleId);
  }

  _onQuickChat(messageId) {
    if (this.session instanceof MultiplayerSession) this.session.sendLocalQuickChat(messageId);
  }

  _showRemoteQuickChat() {
    // Minimal, honest scope: incoming quick-chat currently surfaces via the
    // browser console rather than an in-world speech bubble. Wiring a
    // transient on-screen bubble per remote player is a reasonable follow-up
    // (see TESTING_REPORT.md / README "Known limitations").
    console.log('[quickChat] a nearby driver sent a quick-chat message');
  }

  pause() {
    if (!this.session) return;
    this.paused = true;
    this.session.setPaused(true);
    document.getElementById('pause-overlay').hidden = false;
  }

  resume() {
    if (!this.session) return;
    this.paused = false;
    this.session.setPaused(false);
    document.getElementById('pause-overlay').hidden = true;
    if (this._currentScreen !== 'game') this.showScreen('game');
  }

  quitToMenu() {
    document.getElementById('pause-overlay').hidden = true;
    this._teardownSession();
    this.inputManager.stop();
    this.showScreen('mainmenu');
  }

  _teardownSession() {
    if (this.session) {
      this.session.dispose();
      this.session = null;
    }
    this.paused = false;
  }

  hasAcceptedTerms() {
    return SaveManager.hasAcceptedCurrentTerms();
  }

  showTermsGate() {
    this._termsViewOnly = false;
    this.termsScreen.show();
    this.showScreen('terms');
  }
}
