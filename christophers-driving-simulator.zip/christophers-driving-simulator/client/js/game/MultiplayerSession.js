// client/js/game/MultiplayerSession.js
//
// Real client/server multiplayer: the local car runs the same VehiclePhysics
// as singleplayer and reports its transform to the server at a throttled
// rate; remote cars are NOT simulated locally at all — they're just meshes
// whose position/rotation is set directly from whatever the server last told
// us (with simple linear interpolation toward each new sample so 15Hz
// updates don't look like a slideshow). The server is authoritative for who
// is connected and validates every position update — see
// server/src/GameServer.js and shared/validation.js.

import { Engine } from '../core/Engine.js';
import { World } from '../world/World.js';
import { ChaseCamera } from '../camera/ChaseCamera.js';
import { VehicleController } from '../vehicles/VehicleController.js';
import { NetworkClient } from '../multiplayer/NetworkClient.js';
import { getVehicle, DEFAULT_VEHICLE_ID } from '../../../shared/vehicleData.js';
import { CONFIG } from '../config.js';

const REMOTE_LERP_RATE = 10; // higher = snappier, lower = smoother but laggier-feeling

export class MultiplayerSession {
  constructor({ container, settings, inputManager, audio, hud, lobbyScreen }) {
    this.container = container;
    this.inputManager = inputManager;
    this.audio = audio;
    this.hud = hud;
    this.lobbyScreen = lobbyScreen;

    this.engine = new Engine(container, settings);
    this.world = new World(this.engine.scene);
    this.camera = new ChaseCamera(container.clientWidth / Math.max(1, container.clientHeight));
    this.camera.setDistanceMultiplier(settings.gameplay.cameraDistance);
    this.camera.setSensitivity(settings.gameplay.cameraSensitivity);
    this.engine.setActiveCamera(this.camera.camera);

    this.paused = false;
    this.player = null;
    this.remotes = new Map(); // id -> { controller, targetX, targetY, targetZ, targetYaw }
    this._unsubscribe = null;

    this.network = new NetworkClient({
      onJoined: (self, players) => this._onJoined(self, players),
      onConnectError: (msg) => this._onConnectError(msg),
      onDisconnected: (reason) => this._onDisconnected(reason),
      onPlayerLeft: (id) => this._removeRemote(id),
      onPlayerMoved: (p) => this._onRemoteMoved(p),
      onPlayerVehicleChanged: (id, vehicleId) => this._onRemoteVehicleChanged(id, vehicleId),
      onRosterUpdate: () => this._updateConnectionLabel(),
      onQuickChat: (id, messageId) => this._onQuickChat(id, messageId),
    });
  }

  /** Called once the player clicks Connect in the lobby. */
  connect(playerName, vehicleId) {
    this.pendingVehicleId = vehicleId;
    this.lobbyScreen.setConnecting(true);
    this.lobbyScreen.setStatus('Connecting…', 'neutral');
    this.network.connect(CONFIG.multiplayerServerUrl, { name: playerName, vehicleId });
  }

  _onJoined(self, players) {
    this.lobbyScreen.setConnecting(false);
    this.lobbyScreen.setStatus(`Connected — ${players.length + 1} player(s) online.`, 'ok');

    const vehicle = getVehicle(this.pendingVehicleId) || getVehicle(DEFAULT_VEHICLE_ID);
    this.player = new VehicleController(vehicle, { x: self.x, z: self.z, heading: self.rotationY }, { audio: this.audio });
    this.player.attachTo(this.engine.scene);
    this.player.startAudio();
    this.camera.resetBehindVehicle(this.player.physics.position, self.rotationY);
    this.hud.setVehicleName(vehicle.name);
    this._updateConnectionLabel();

    for (const p of players) this._addRemote(p);

    this._unsubscribe = this.engine.onFrame((dt) => this._frame(dt));
    this.engine.start();
    this.onEnteredGame?.();
  }

  _onConnectError(message) {
    this.lobbyScreen.setConnecting(false);
    this.lobbyScreen.setStatus(message, 'error');
  }

  _onDisconnected(reason) {
    this.hud.setConnectionStatus(`Disconnected (${reason})`, false);
  }

  _addRemote(p) {
    const vehicle = getVehicle(p.vehicleId) || getVehicle(DEFAULT_VEHICLE_ID);
    const controller = new VehicleController(vehicle, { x: p.x, z: p.z, heading: p.rotationY });
    controller.attachTo(this.engine.scene);
    this.remotes.set(p.id, { controller, targetX: p.x, targetY: p.y || 0, targetZ: p.z, targetYaw: p.rotationY, name: p.name });
  }

  _removeRemote(id) {
    const entry = this.remotes.get(id);
    if (!entry) return;
    entry.controller.detach(this.engine.scene);
    this.remotes.delete(id);
    this._updateConnectionLabel();
  }

  _onRemoteMoved(p) {
    const entry = this.remotes.get(p.id);
    if (!entry) return; // could arrive just before playerJoined in rare orderings; next update will catch it up
    entry.targetX = p.x;
    entry.targetY = p.y || 0;
    entry.targetZ = p.z;
    entry.targetYaw = p.rotationY;
  }

  _onRemoteVehicleChanged(id, vehicleId) {
    const entry = this.remotes.get(id);
    if (!entry) return;
    const vehicle = getVehicle(vehicleId);
    if (!vehicle) return;
    const oldPos = entry.controller.physics.position;
    entry.controller.detach(this.engine.scene);
    const controller = new VehicleController(vehicle, { x: oldPos.x, z: oldPos.z, heading: entry.controller.physics.yaw });
    controller.attachTo(this.engine.scene);
    entry.controller = controller;
  }

  _onQuickChat(id, messageId) {
    this.onQuickChatReceived?.(id, messageId);
  }

  _updateConnectionLabel() {
    this.hud.setConnectionStatus(`Online · ${this.remotes.size + 1} player(s)`, true);
  }

  sendLocalQuickChat(messageId) {
    this.network.sendQuickChat(messageId);
  }

  _frame(dt) {
    if (this.paused) return;
    const input = this.inputManager.read();

    if (input.resetPressed) this.player.physics.resetToSafePosition();

    this.player.update(dt, input, this.world);
    const t = this.player.physics.getTransform();
    this.network.sendTransform(t.position.x, t.position.y, t.position.z, t.yaw);

    for (const entry of this.remotes.values()) {
      const c = entry.controller;
      const rate = Math.min(1, dt * REMOTE_LERP_RATE);
      const curX = c.physics.position.x + (entry.targetX - c.physics.position.x) * rate;
      const curY = c.physics.position.y + (entry.targetY - c.physics.position.y) * rate;
      const curZ = c.physics.position.z + (entry.targetZ - c.physics.position.z) * rate;
      let yawDelta = entry.targetYaw - c.physics.yaw;
      yawDelta = Math.atan2(Math.sin(yawDelta), Math.cos(yawDelta)); // shortest angular path
      const curYaw = c.physics.yaw + yawDelta * rate;
      c.applyNetworkTransform(curX, curY, curZ, curYaw);
    }

    this.camera.update(dt, this.player, input);
    this.hud.updateTelemetry(this.player.physics.getTelemetry());
    const remoteDots = Array.from(this.remotes.values()).map((e) => ({ x: e.controller.physics.position.x, z: e.controller.physics.position.z }));
    this.hud.updateMinimap(this.player.physics.getTransform(), this.world, remoteDots);
  }

  setPaused(paused) {
    this.paused = paused;
    if (paused) this.player?.stopAudio();
    else this.player?.startAudio();
  }

  applyGraphicsSettings(graphics) {
    this.engine.applyGraphicsSettings(graphics);
  }

  applyGameplaySettings(gameplay) {
    this.camera.setDistanceMultiplier(gameplay.cameraDistance);
    this.camera.setSensitivity(gameplay.cameraSensitivity);
  }

  dispose() {
    if (this._unsubscribe) this._unsubscribe();
    this.player?.stopAudio();
    this.network.disconnect();
    for (const entry of this.remotes.values()) entry.controller.detach(this.engine.scene);
    this.remotes.clear();
    this.engine.dispose();
  }
}
