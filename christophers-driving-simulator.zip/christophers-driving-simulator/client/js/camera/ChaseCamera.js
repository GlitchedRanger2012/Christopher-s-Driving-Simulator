// client/js/camera/ChaseCamera.js
//
// A spring-damped chase camera: rather than snapping to a fixed offset
// behind the car every frame (which looks robotic), the camera's actual
// position eases toward a target offset, and looks slightly ahead of the
// car based on current speed. Three modes cycle with the configured
// "cameraMode" key (default C): chase, close chase, hood. Camera collision
// (pulling the rig closer if a wall is behind the car) is intentionally
// out of scope for this build — see README "Known limitations" — the
// camera can clip through buildings if you park a car against one.

import * as THREE from '../vendor/three.js';

const MODES = {
  chase: { distance: 8.5, height: 3.2, lookAheadFactor: 0.05, fov: 62 },
  closeChase: { distance: 5.2, height: 2.0, lookAheadFactor: 0.03, fov: 68 },
  hood: { distance: -0.2, height: 1.25, lookAheadFactor: 0.12, fov: 75 },
};
const MODE_ORDER = ['chase', 'closeChase', 'hood'];

export class ChaseCamera {
  constructor(aspect) {
    this.camera = new THREE.PerspectiveCamera(62, aspect, 0.1, 2000);
    this.modeIndex = 0;
    this.distanceMultiplier = 1.0;
    this.sensitivity = 1.0;
    this._currentPos = new THREE.Vector3(0, 5, -10);
    this._currentLook = new THREE.Vector3();
    this._wasCameraModePressed = false;
  }

  get modeName() {
    return MODE_ORDER[this.modeIndex];
  }

  setDistanceMultiplier(m) {
    this.distanceMultiplier = m;
  }

  setSensitivity(s) {
    this.sensitivity = s;
  }

  handleModeToggle(input) {
    if (input.cameraModePressed && !this._wasCameraModePressed) {
      this.modeIndex = (this.modeIndex + 1) % MODE_ORDER.length;
    }
    this._wasCameraModePressed = input.cameraModePressed;
  }

  resetBehindVehicle(vehiclePosition, vehicleYaw) {
    const mode = MODES[this.modeName];
    const behind = new THREE.Vector3(
      vehiclePosition.x - Math.cos(vehicleYaw) * mode.distance,
      vehiclePosition.y + mode.height,
      vehiclePosition.z - Math.sin(vehicleYaw) * mode.distance,
    );
    this._currentPos.copy(behind);
    this._currentLook.copy(vehiclePosition);
  }

  update(dt, vehicleController, input) {
    this.handleModeToggle(input);
    const mode = MODES[this.modeName];
    const { position, yaw } = vehicleController.physics.getTransform();
    const speedKph = vehicleController.physics.getSpeedKph();

    const distance = mode.distance * this.distanceMultiplier;
    const targetPos = new THREE.Vector3(
      position.x - Math.cos(yaw) * distance,
      position.y + mode.height,
      position.z - Math.sin(yaw) * distance,
    );

    const lookAhead = THREE.MathUtils.clamp(speedKph * mode.lookAheadFactor, -3, 14);
    const targetLook = new THREE.Vector3(
      position.x + Math.cos(yaw) * lookAhead,
      position.y + 0.6,
      position.z + Math.sin(yaw) * lookAhead,
    );

    const followSpeed = 1 - Math.pow(0.001, dt * this.sensitivity * 4);
    this._currentPos.lerp(targetPos, followSpeed);
    this._currentLook.lerp(targetLook, Math.min(1, followSpeed * 1.6));

    this.camera.position.copy(this._currentPos);
    this.camera.lookAt(this._currentLook);

    if (Math.abs(this.camera.fov - mode.fov) > 0.05) {
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, mode.fov, Math.min(1, dt * 3));
      this.camera.updateProjectionMatrix();
    }
  }

  setAspect(aspect) {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }
}
