// client/js/world/World.js
//
// Turns the pure-data city layout (TrackGenerator.js) into an actual THREE
// scene, plus the two query functions VehiclePhysics needs:
// sampleGroundHeight(x, z) and getNearbyColliders(x, z). Repeated small
// props (trees, streetlights) use THREE.InstancedMesh — one draw call per
// prop type instead of one per instance — and building/barrier colliders are
// bucketed into a coarse grid keyed by block cell so collision queries only
// scan nearby buckets instead of every collider in the city every frame
// (see _buildColliderIndex / getNearbyColliders).

import * as THREE from '../vendor/three.js';
import { generateCityLayout } from './TrackGenerator.js';
import { WORLD_SEED } from '../../../shared/constants.js';

const TERRAIN_AMPLITUDE = 2.2;
const TERRAIN_FREQ = 0.012;

function smoothstep(edge0, edge1, x) {
  const t = THREE.MathUtils.clamp((x - edge0) / (edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function buildRampGeometry(length, width, maxHeight) {
  const hl = length / 2;
  const hw = width / 2;
  const positions = new Float32Array([
    // front-bottom-left(A), front-bottom-right(B), back-bottom-left(C), back-bottom-right(D)
    -hl, 0, -hw, /*A*/ -hl, 0, hw, /*B*/ hl, 0, -hw, /*C*/ hl, 0, hw, /*D*/
    hl, maxHeight, -hw, /*E*/ hl, maxHeight, hw, /*F*/
  ]);
  const idx = [
    0, 2, 1, 1, 2, 3, // bottom (A,C,B)(B,C,D)
    0, 1, 5, 0, 5, 4, // top slope (A,B,F)(A,F,E)
    2, 4, 5, 2, 5, 3, // back vertical (C,E,F)(C,F,D)
    0, 4, 2, // left triangle
    1, 3, 5, // right triangle
  ];
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setIndex(idx);
  geo.computeVertexNormals();
  return geo;
}

export class World {
  constructor(scene, { seed = WORLD_SEED } = {}) {
    this.scene = scene;
    this.layout = generateCityLayout(seed);
    this._colliderBuckets = new Map();
    this._allColliders = [];

    this._buildGround();
    this._buildRoads();
    this._buildBuildings();
    this._buildTreesInstanced();
    this._buildStreetlightsInstanced();
    this._buildSignsAndBarriers();
    this._buildRamps();
    this._buildParkingSpots();
    this._buildLighting();
  }

  _buildGround() {
    const half = this.layout.worldHalfExtent;
    const geo = new THREE.PlaneGeometry(half * 2, half * 2, 1, 1);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({ color: 0x2f3b2f, roughness: 0.95, metalness: 0 });
    const ground = new THREE.Mesh(geo, mat);
    ground.receiveShadow = true;
    this.scene.add(ground);
  }

  _buildRoads() {
    const { gridRadius, blockSize, roadWidth, cityHalfSpan } = this.layout;
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x24262b, roughness: 0.85 });
    const roadLength = cityHalfSpan * 2 + 20;

    for (let g = -gridRadius; g <= gridRadius + 1; g++) {
      const offset = (g - 0.5) * blockSize;
      const vStrip = new THREE.Mesh(new THREE.PlaneGeometry(roadWidth, roadLength), roadMat);
      vStrip.rotation.x = -Math.PI / 2;
      vStrip.position.set(offset, 0.01, 0);
      vStrip.receiveShadow = true;
      this.scene.add(vStrip);

      const hStrip = new THREE.Mesh(new THREE.PlaneGeometry(roadLength, roadWidth), roadMat);
      hStrip.rotation.x = -Math.PI / 2;
      hStrip.position.set(0, 0.01, offset);
      hStrip.receiveShadow = true;
      this.scene.add(hStrip);
    }
  }

  _buildBuildings() {
    for (const block of this.layout.blocks) {
      if (block.type !== 'building' || !block.building) continue;
      const { width, depth, height, color } = block.building;
      const geo = new THREE.BoxGeometry(width, height, depth);
      const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.8, metalness: 0.05 });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(block.cx, height / 2, block.cz);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);

      const collider = {
        minX: block.cx - width / 2, maxX: block.cx + width / 2,
        minZ: block.cz - depth / 2, maxZ: block.cz + depth / 2,
      };
      this._addCollider(collider);
    }
  }

  _buildTreesInstanced() {
    const trunkGeo = new THREE.CylinderGeometry(0.15, 0.2, 1.6, 6);
    const foliageGeo = new THREE.ConeGeometry(1.3, 2.6, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3728, roughness: 0.9 });
    const foliageMat = new THREE.MeshStandardMaterial({ color: 0x2f5a34, roughness: 0.85 });

    const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, this.layout.trees.length);
    const foliage = new THREE.InstancedMesh(foliageGeo, foliageMat, this.layout.trees.length);
    trunks.castShadow = true;
    foliage.castShadow = true;

    const m = new THREE.Object3D();
    this.layout.trees.forEach((tree, i) => {
      m.position.set(tree.x, 0.8 * tree.scale, tree.z);
      m.scale.setScalar(tree.scale);
      m.updateMatrix();
      trunks.setMatrixAt(i, m.matrix);

      m.position.set(tree.x, 2.1 * tree.scale, tree.z);
      m.updateMatrix();
      foliage.setMatrixAt(i, m.matrix);
    });
    this.scene.add(trunks, foliage);
  }

  _buildStreetlightsInstanced() {
    const poleGeo = new THREE.CylinderGeometry(0.08, 0.08, 5, 6);
    const headGeo = new THREE.SphereGeometry(0.22, 8, 8);
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x1e2128, roughness: 0.6, metalness: 0.5 });
    const headMat = new THREE.MeshStandardMaterial({ color: 0xffd23f, emissive: 0xffd23f, emissiveIntensity: 0.6 });

    const poles = new THREE.InstancedMesh(poleGeo, poleMat, this.layout.streetlights.length);
    const heads = new THREE.InstancedMesh(headGeo, headMat, this.layout.streetlights.length);
    poles.castShadow = true;

    const m = new THREE.Object3D();
    this.layout.streetlights.forEach((l, i) => {
      m.position.set(l.x, 2.5, l.z);
      m.updateMatrix();
      poles.setMatrixAt(i, m.matrix);
      m.position.set(l.x, 5, l.z);
      m.updateMatrix();
      heads.setMatrixAt(i, m.matrix);
    });
    this.scene.add(poles, heads);
  }

  _buildSignsAndBarriers() {
    const signMat = new THREE.MeshStandardMaterial({ color: 0xeef0f3, roughness: 0.5 });
    const poleMat = new THREE.MeshStandardMaterial({ color: 0x6e7480, roughness: 0.6, metalness: 0.4 });
    for (const sign of this.layout.signs) {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 6), poleMat);
      pole.position.set(sign.x, 1.1, sign.z);
      const board = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.6, 0.6), signMat);
      board.position.set(sign.x, 2.1, sign.z);
      board.rotation.y = sign.rotationY;
      pole.castShadow = true;
      board.castShadow = true;
      this.scene.add(pole, board);
    }

    const barrierMat = new THREE.MeshStandardMaterial({ color: 0xc9c9d1, roughness: 0.5, metalness: 0.3 });
    for (const b of this.layout.barriers) {
      const length = Math.hypot(b.x2 - b.x1, b.z2 - b.z1);
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(length, 0.7, 0.25), barrierMat);
      mesh.position.set((b.x1 + b.x2) / 2, 0.35, (b.z1 + b.z2) / 2);
      mesh.rotation.y = -Math.atan2(b.z2 - b.z1, b.x2 - b.x1);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);

      const pad = 0.3;
      this._addCollider({
        minX: Math.min(b.x1, b.x2) - pad, maxX: Math.max(b.x1, b.x2) + pad,
        minZ: Math.min(b.z1, b.z2) - pad, maxZ: Math.max(b.z1, b.z2) + pad,
      });
    }
  }

  _buildRamps() {
    const rampMat = new THREE.MeshStandardMaterial({ color: 0x8a8f99, roughness: 0.7, metalness: 0.2 });
    this._ramps = [];
    for (const ramp of this.layout.ramps) {
      const geo = buildRampGeometry(ramp.length, ramp.width, ramp.maxHeight);
      const mesh = new THREE.Mesh(geo, rampMat);
      mesh.position.set(ramp.x, 0, ramp.z);
      mesh.rotation.y = -ramp.heading;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
      this._ramps.push(ramp);
    }
  }

  _buildParkingSpots() {
    const mat = new THREE.MeshStandardMaterial({ color: 0x3a3f4a, roughness: 0.9 });
    for (const spot of this.layout.parkingSpots) {
      const marking = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 5), mat);
      marking.rotation.x = -Math.PI / 2;
      marking.position.set(spot.x, 0.02, spot.z);
      this.scene.add(marking);
    }
  }

  _buildLighting() {
    const hemi = new THREE.HemisphereLight(0x9fc6ff, 0x2b2f22, 0.65);
    this.scene.add(hemi);

    const sun = new THREE.DirectionalLight(0xfff2df, 1.15);
    sun.position.set(180, 260, 120);
    sun.castShadow = true;
    sun.shadow.mapSize.set(2048, 2048);
    const d = 420;
    sun.shadow.camera.left = -d;
    sun.shadow.camera.right = d;
    sun.shadow.camera.top = d;
    sun.shadow.camera.bottom = -d;
    sun.shadow.camera.far = 800;
    sun.shadow.bias = -0.0004;
    this.scene.add(sun);
    this.scene.add(sun.target);
    this.sun = sun;
  }

  // ---- physics queries ----

  sampleGroundHeight(x, z) {
    for (const ramp of this._ramps) {
      const dx = x - ramp.x;
      const dz = z - ramp.z;
      const cos = Math.cos(-ramp.heading);
      const sin = Math.sin(-ramp.heading);
      const localX = dx * cos - dz * sin;
      const localZ = dx * sin + dz * cos;
      if (Math.abs(localZ) <= ramp.width / 2 && localX >= -ramp.length / 2 && localX <= ramp.length / 2) {
        const t = (localX + ramp.length / 2) / ramp.length;
        return { height: t * ramp.maxHeight };
      }
    }

    const dist = Math.hypot(x, z);
    const flatEdge = this.layout.cityHalfSpan + 20;
    const blend = smoothstep(flatEdge, flatEdge + 260, dist);
    if (blend <= 0) return { height: 0 };
    const height = blend * TERRAIN_AMPLITUDE * Math.sin(x * TERRAIN_FREQ) * Math.cos(z * TERRAIN_FREQ);
    return { height };
  }

  _addCollider(aabb) {
    this._allColliders.push(aabb);
    const cellsTouched = new Set();
    for (const [px, pz] of [[aabb.minX, aabb.minZ], [aabb.maxX, aabb.minZ], [aabb.minX, aabb.maxZ], [aabb.maxX, aabb.maxZ]]) {
      cellsTouched.add(this._cellKey(px, pz));
    }
    for (const key of cellsTouched) {
      if (!this._colliderBuckets.has(key)) this._colliderBuckets.set(key, []);
      this._colliderBuckets.get(key).push(aabb);
    }
  }

  _cellKey(x, z) {
    const bs = this.layout.blockSize;
    return `${Math.round(x / bs)},${Math.round(z / bs)}`;
  }

  /** Only scans the 3x3 block-cell neighborhood around (x, z), not every collider in the city. */
  getNearbyColliders(x, z) {
    const bs = this.layout.blockSize;
    const gx = Math.round(x / bs);
    const gz = Math.round(z / bs);
    const out = [];
    const seen = new Set();
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        const list = this._colliderBuckets.get(`${gx + dx},${gz + dz}`);
        if (!list) continue;
        for (const c of list) {
          if (seen.has(c)) continue;
          seen.add(c);
          out.push(c);
        }
      }
    }
    return out;
  }

  getSpawnPlazaRadius() {
    return this.layout.blockSize * 1.1;
  }
}
