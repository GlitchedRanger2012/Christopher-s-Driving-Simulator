// client/js/world/TrackGenerator.js
//
// Produces a deterministic city layout from a single integer seed: the same
// seed always produces the exact same blocks, buildings, trees, streetlights
// and ramps (see server/test/trackGenerator.test.mjs, which asserts this
// directly). This file has NO THREE.js dependency — it only returns plain
// data. World.js turns that data into actual meshes and colliders. Keeping
// generation pure like this is what makes "deterministic, not meaningless
// random generation" (requirement 8) something that's actually verifiable
// rather than just asserted.

import { BLOCK_SIZE, ROAD_WIDTH, WORLD_HALF_EXTENT } from '../../../shared/constants.js';

const GRID_RADIUS = 3; // blocks extend from -3..3 on each axis => 7x7 grid
const CITY_HALF_SPAN = GRID_RADIUS * BLOCK_SIZE + BLOCK_SIZE / 2;

function mulberry32(seed) {
  let s = seed >>> 0;
  return function rand() {
    s |= 0;
    s = (s + 0x6d2b79f5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick(rand, list) {
  return list[Math.floor(rand() * list.length) % list.length];
}

/**
 * @param {number} seed
 * @returns plain-data city layout: blocks, streetlights, signs, barriers,
 * trees, ramps, parking spots, and the spawn plaza bounds.
 */
export function generateCityLayout(seed) {
  const rand = mulberry32(seed);
  const blocks = [];
  const trees = [];
  const streetlights = [];
  const signs = [];
  const parkingSpots = [];

  const buildingPalette = ['#4A5568', '#6E7480', '#3A3F4A', '#5A5248', '#42474F', '#565B52'];

  for (let gx = -GRID_RADIUS; gx <= GRID_RADIUS; gx++) {
    for (let gz = -GRID_RADIUS; gz <= GRID_RADIUS; gz++) {
      const cx = gx * BLOCK_SIZE;
      const cz = gz * BLOCK_SIZE;
      const distFromCenter = Math.hypot(gx, gz);

      let type;
      if (distFromCenter < 1.1) {
        type = 'plaza'; // keep the center clear — this is the spawn area
      } else if (distFromCenter < 1.9) {
        type = rand() < 0.6 ? 'parking' : 'park';
      } else {
        const r = rand();
        type = r < 0.62 ? 'building' : r < 0.85 ? 'park' : 'parking';
      }

      const block = { cx, cz, type };

      if (type === 'building') {
        const footprint = BLOCK_SIZE * (0.45 + rand() * 0.25);
        const height = 8 + rand() * 32;
        block.building = {
          width: footprint,
          depth: footprint * (0.7 + rand() * 0.5),
          height,
          color: pick(rand, buildingPalette),
        };
      } else if (type === 'park') {
        const treeCount = 4 + Math.floor(rand() * 6);
        for (let i = 0; i < treeCount; i++) {
          trees.push({
            x: cx + (rand() - 0.5) * BLOCK_SIZE * 0.7,
            z: cz + (rand() - 0.5) * BLOCK_SIZE * 0.7,
            scale: 0.8 + rand() * 0.6,
          });
        }
      } else if (type === 'parking') {
        const rows = 2;
        const cols = 4;
        for (let r = 0; r < rows; r++) {
          for (let c = 0; c < cols; c++) {
            if (rand() < 0.7) {
              parkingSpots.push({
                x: cx + (c - (cols - 1) / 2) * 6,
                z: cz + (r - (rows - 1) / 2) * 10,
              });
            }
          }
        }
      }

      blocks.push(block);
    }
  }

  // Streetlights + signs at every grid intersection within the city.
  for (let gx = -GRID_RADIUS; gx <= GRID_RADIUS + 1; gx++) {
    for (let gz = -GRID_RADIUS; gz <= GRID_RADIUS + 1; gz++) {
      const x = (gx - 0.5) * BLOCK_SIZE;
      const z = (gz - 0.5) * BLOCK_SIZE;
      if (rand() < 0.55) streetlights.push({ x, z });
      if (rand() < 0.12) signs.push({ x, z, rotationY: rand() * Math.PI * 2 });
    }
  }

  // A handful of fixed jump ramps out past the city grid, for airborne
  // physics/camera to actually be reachable during testing and play.
  const ramps = [
    { x: CITY_HALF_SPAN + 40, z: 0, heading: 0, length: 22, width: 8, maxHeight: 3.2 },
    { x: -(CITY_HALF_SPAN + 40), z: 0, heading: Math.PI, length: 22, width: 8, maxHeight: 3.2 },
    { x: 0, z: CITY_HALF_SPAN + 40, heading: Math.PI / 2, length: 18, width: 7, maxHeight: 2.4 },
  ];

  // Guardrail barriers along the boundary between the city grid and the
  // open off-road perimeter, with gaps left at the four cardinal exits.
  const barriers = [];
  const b = CITY_HALF_SPAN + 6;
  const gapHalf = BLOCK_SIZE * 0.9;
  const segment = 24;
  for (let along = -b; along < b; along += segment) {
    const skipNorth = Math.abs(along + segment / 2) < gapHalf;
    if (!skipNorth) barriers.push({ x1: along, z1: -b, x2: along + segment, z2: -b });
    if (!skipNorth) barriers.push({ x1: along, z1: b, x2: along + segment, z2: b });
    if (!skipNorth) barriers.push({ x1: -b, z1: along, x2: -b, z2: along + segment });
    if (!skipNorth) barriers.push({ x1: b, z1: along, x2: b, z2: along + segment });
  }

  return {
    seed,
    gridRadius: GRID_RADIUS,
    blockSize: BLOCK_SIZE,
    roadWidth: ROAD_WIDTH,
    cityHalfSpan: CITY_HALF_SPAN,
    worldHalfExtent: WORLD_HALF_EXTENT,
    blocks,
    trees,
    streetlights,
    signs,
    parkingSpots,
    ramps,
    barriers,
  };
}
