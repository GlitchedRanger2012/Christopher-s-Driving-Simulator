// client/js/ui/CarSelect.js
// One car-select screen used for both singleplayer and multiplayer (the
// spec's car-selection requirements are identical either way — only what
// happens after confirming differs, which the caller supplies via onConfirm).

import { VEHICLES, CATEGORY_LIST, getVehicle } from '../../../shared/vehicleData.js';
import { SaveManager } from '../core/SaveManager.js';

const STAT_MAX = { acceleration: 12, topSpeed: 360, braking: 55, handling: 100, grip: 100, mass: 2800 };

function statBar(label, value, max, invert = false) {
  const pct = invert
    ? Math.max(0, Math.min(100, 100 - (value / max) * 100))
    : Math.max(0, Math.min(100, (value / max) * 100));
  const row = document.createElement('div');
  row.className = 'statbar';
  row.innerHTML = `
    <div class="statbar__label"><span>${label}</span><span>${value}</span></div>
    <div class="statbar__track"><div class="statbar__fill" style="width:${pct}%"></div></div>`;
  return row;
}

export class CarSelect {
  constructor({ onConfirm, onBack }) {
    this.onConfirm = onConfirm;
    this.onBack = onBack;
    this.activeCategory = 'all';
    this.selectedId = null;

    this.gridEl = document.getElementById('carselect-grid');
    this.filtersEl = document.getElementById('carselect-filters');
    this.detailEl = document.getElementById('carselect-detail');
    this.confirmBtn = document.getElementById('carselect-confirm');
    this.headingEl = document.getElementById('carselect-heading');

    this._buildFilters();
    this._buildGrid();

    document.getElementById('carselect-back').addEventListener('click', () => onBack());
    this.confirmBtn.addEventListener('click', () => {
      if (this.selectedId) {
        SaveManager.saveLastVehicleId(this.selectedId);
        this.onConfirm(this.selectedId);
      }
    });
  }

  _buildFilters() {
    this.filtersEl.innerHTML = '';
    const makeChip = (value, label) => {
      const chip = document.createElement('button');
      chip.className = 'chip';
      chip.textContent = label;
      chip.setAttribute('role', 'tab');
      chip.setAttribute('aria-selected', String(value === this.activeCategory));
      chip.addEventListener('click', () => {
        this.activeCategory = value;
        this._buildFilters();
        this._buildGrid();
      });
      return chip;
    };
    this.filtersEl.appendChild(makeChip('all', 'All'));
    for (const cat of CATEGORY_LIST) {
      this.filtersEl.appendChild(makeChip(cat, cat[0].toUpperCase() + cat.slice(1)));
    }
  }

  _buildGrid() {
    this.gridEl.innerHTML = '';
    const list = this.activeCategory === 'all' ? VEHICLES : VEHICLES.filter((v) => v.category === this.activeCategory);
    for (const v of list) {
      const card = document.createElement('button');
      card.className = 'car-card';
      card.setAttribute('role', 'listitem');
      card.setAttribute('aria-pressed', String(v.id === this.selectedId));
      card.innerHTML = `
        <div class="car-card__swatch" style="background:${v.color}"></div>
        <span class="car-card__name">${v.name}</span>
        <span class="car-card__cat">${capitalize(v.category)} · ${v.drivetrain}</span>`;
      card.addEventListener('click', () => this.select(v.id));
      this.gridEl.appendChild(card);
    }
  }

  select(vehicleId) {
    this.selectedId = vehicleId;
    this.confirmBtn.disabled = false;
    for (const card of this.gridEl.querySelectorAll('.car-card')) {
      const name = card.querySelector('.car-card__name').textContent;
      card.setAttribute('aria-pressed', String(name === getVehicle(vehicleId).name));
    }
    this._renderDetail(getVehicle(vehicleId));
  }

  _renderDetail(v) {
    this.detailEl.innerHTML = '';
    const title = document.createElement('h2');
    title.textContent = v.name;
    const sub = document.createElement('p');
    sub.className = 'muted small';
    sub.textContent = `${capitalize(v.category)} · ${v.drivetrain} · ${v.dimensions.length}m long`;
    this.detailEl.append(title, sub);
    this.detailEl.appendChild(statBar('Acceleration (0-100 km/h)', v.acceleration, STAT_MAX.acceleration, true));
    this.detailEl.appendChild(statBar('Top speed (km/h)', v.topSpeed, STAT_MAX.topSpeed));
    this.detailEl.appendChild(statBar('Braking (100-0 km/h, m)', v.braking, STAT_MAX.braking, true));
    this.detailEl.appendChild(statBar('Handling', v.handling, STAT_MAX.handling));
    this.detailEl.appendChild(statBar('Grip', v.grip, STAT_MAX.grip));
    this.detailEl.appendChild(statBar('Weight (kg)', v.mass, STAT_MAX.mass, true));
  }

  /** @param {'singleplayer'|'multiplayer'} mode */
  show(mode) {
    this.headingEl.textContent = mode === 'multiplayer' ? 'Choose your vehicle — Multiplayer' : 'Choose your vehicle';
    const last = SaveManager.loadLastVehicleId();
    if (last && getVehicle(last)) {
      this.activeCategory = 'all';
      this._buildFilters();
      this._buildGrid();
      this.select(last);
    } else {
      this.selectedId = null;
      this.confirmBtn.disabled = true;
      this.detailEl.innerHTML = '<p class="muted">Select a car to see its stats.</p>';
    }
  }
}

function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
