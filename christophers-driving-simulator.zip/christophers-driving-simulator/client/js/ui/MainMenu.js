// client/js/ui/MainMenu.js
// Wires every main-menu button to a real action. Nothing here is a stub:
// Exit goes to a real (honest) explanation screen rather than pretending a
// browser tab can be force-closed — see index.html #screen-exit.

export class MainMenu {
  constructor(handlers) {
    this.handlers = handlers;
    document.getElementById('nav-singleplayer').addEventListener('click', () => handlers.onSingleplayer());
    document.getElementById('nav-multiplayer').addEventListener('click', () => handlers.onMultiplayer());
    document.getElementById('nav-settings').addEventListener('click', () => handlers.onSettings());
    document.getElementById('nav-credits').addEventListener('click', () => handlers.onCredits());
    document.getElementById('nav-terms').addEventListener('click', () => handlers.onViewTerms());
    document.getElementById('nav-exit').addEventListener('click', () => handlers.onExit());
    document.getElementById('exit-return').addEventListener('click', () => handlers.onExitReturn());
  }

  focusDefault() {
    document.querySelector('[data-default-focus]')?.focus();
  }
}
