// client/js/ui/HUD.js
import { QUICK_CHAT_MESSAGES } from '../../../shared/constants.js';

const MINIMAP_RADIUS_M = 140; // how much world space the minimap shows around the player

export class HUD {
  constructor({ onQuickChat } = {}) {
    this.root = document.getElementById('hud');
    this.speedEl = document.getElementById('hud-speed');
    this.gearEl = document.getElementById('hud-gear');
    this.rpmFillEl = document.getElementById('hud-rpm-fill');
    this.nameEl = document.getElementById('hud-vehicle-name');
    this.connEl = document.getElementById('hud-connection');
    this.minimap = document.getElementById('hud-minimap');
    this.minimapCtx = this.minimap.getContext('2d');
    this.quickChatEl = document.getElementById('hud-quickchat');

    if (onQuickChat) {
      this.quickChatEl.hidden = false;
      QUICK_CHAT_MESSAGES.forEach((msg, id) => {
        const btn = document.createElement('button');
        btn.textContent = msg;
        btn.addEventListener('click', () => onQuickChat(id));
        this.quickChatEl.appendChild(btn);
      });
    }
  }

  setVehicleName(name) {
    this.nameEl.textContent = name;
  }

  setConnectionStatus(text, ok) {
    this.connEl.hidden = !text;
    this.connEl.textContent = text;
    this.connEl.className = 'hud__connection ' + (ok ? 'hud__connection--ok' : 'hud__connection--bad');
  }

  updateTelemetry(telemetry) {
    this.speedEl.textContent = Math.max(0, Math.round(telemetry.speedKph));
    this.gearEl.textContent = telemetry.gear;
    const rpmPct = Math.min(100, (telemetry.rpm / 7000) * 100);
    this.rpmFillEl.style.width = `${rpmPct}%`;
  }

  updateMinimap(playerTransform, world, remotePlayers = []) {
    const ctx = this.minimapCtx;
    const size = this.minimap.width;
    const scale = size / (MINIMAP_RADIUS_M * 2);
    ctx.clearRect(0, 0, size, size);

    ctx.save();
    ctx.translate(size / 2, size / 2);
    ctx.rotate(playerTransform.yaw + Math.PI / 2);

    // Roads as a faint grid, positioned relative to the player.
    ctx.strokeStyle = 'rgba(139, 146, 160, 0.35)';
    ctx.lineWidth = Math.max(1, 3 * scale);
    const bs = world?.layout?.blockSize || 90;
    const startX = Math.floor((playerTransform.position.x - MINIMAP_RADIUS_M) / bs) * bs;
    const endX = playerTransform.position.x + MINIMAP_RADIUS_M;
    for (let x = startX; x <= endX; x += bs) {
      const rx = (x - playerTransform.position.x) * scale;
      ctx.beginPath();
      ctx.moveTo(rx, -size);
      ctx.lineTo(rx, size);
      ctx.stroke();
    }
    const startZ = Math.floor((playerTransform.position.z - MINIMAP_RADIUS_M) / bs) * bs;
    const endZ = playerTransform.position.z + MINIMAP_RADIUS_M;
    for (let z = startZ; z <= endZ; z += bs) {
      const rz = (z - playerTransform.position.z) * scale;
      ctx.beginPath();
      ctx.moveTo(-size, rz);
      ctx.lineTo(size, rz);
      ctx.stroke();
    }

    // Remote players.
    ctx.fillStyle = '#4fd1e8';
    for (const p of remotePlayers) {
      const rx = (p.x - playerTransform.position.x) * scale;
      const rz = (p.z - playerTransform.position.z) * scale;
      if (Math.abs(rx) > size || Math.abs(rz) > size) continue;
      ctx.beginPath();
      ctx.arc(rx, rz, 4, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();

    // Player arrow, always centered and pointing up.
    ctx.fillStyle = '#ff7a3d';
    ctx.save();
    ctx.translate(size / 2, size / 2);
    ctx.beginPath();
    ctx.moveTo(0, -8);
    ctx.lineTo(6, 7);
    ctx.lineTo(-6, 7);
    ctx.closePath();
    ctx.fill();
    ctx.restore();

    // Ring border.
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2 - 2, 0, Math.PI * 2);
    ctx.stroke();
  }
}
