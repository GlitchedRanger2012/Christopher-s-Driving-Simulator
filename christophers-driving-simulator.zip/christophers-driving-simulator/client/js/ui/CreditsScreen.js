// client/js/ui/CreditsScreen.js
import { GAME_TITLE } from '../../../shared/constants.js';

const THIRD_PARTY = [
  { name: 'Three.js', use: 'WebGL 3D rendering engine', license: 'MIT License', url: 'https://threejs.org' },
  { name: 'Socket.IO', use: 'Multiplayer networking (client + server)', license: 'MIT License', url: 'https://socket.io' },
  { name: 'Rajdhani', use: 'Display typeface (menus, HUD)', license: 'SIL Open Font License 1.1', url: 'https://fonts.google.com/specimen/Rajdhani' },
  { name: 'Public Sans', use: 'Body typeface (settings, Terms of Service)', license: 'SIL Open Font License 1.1', url: 'https://fonts.google.com/specimen/Public+Sans' },
];

export class CreditsScreen {
  constructor({ onBack }) {
    document.getElementById('credits-back').addEventListener('click', () => onBack());
    this._render();
  }

  _render() {
    const el = document.getElementById('credits-content');
    el.innerHTML = '';

    const project = document.createElement('div');
    project.className = 'credits-block';
    project.innerHTML = `<h2>${GAME_TITLE}</h2><p>Created by <strong>Christopher Ranger</strong>.</p><p class="muted small">All original code, game design, and vehicle data are © Christopher Ranger unless noted below. See LICENSE and TERMS_OF_SERVICE.md for reuse and attribution terms.</p>`;
    el.appendChild(project);

    const thirdParty = document.createElement('div');
    thirdParty.className = 'credits-block';
    thirdParty.innerHTML = '<h2>Third-party software &amp; fonts</h2>';
    const ul = document.createElement('ul');
    for (const item of THIRD_PARTY) {
      const li = document.createElement('li');
      li.textContent = `${item.name} — ${item.use} (${item.license})`;
      ul.appendChild(li);
    }
    thirdParty.appendChild(ul);
    const note = document.createElement('p');
    note.className = 'muted small';
    note.textContent = 'Full license details are in THIRD_PARTY_LICENSES.md. These libraries are not created by Christopher Ranger and remain the property of their respective authors.';
    thirdParty.appendChild(note);
    el.appendChild(thirdParty);
  }
}
