// client/js/ui/LobbyScreen.js
import { CONFIG } from '../config.js';
import { SaveManager } from '../core/SaveManager.js';

export class LobbyScreen {
  constructor({ onConnect, onBack }) {
    this.nameInput = document.getElementById('lobby-name');
    this.statusEl = document.getElementById('lobby-status');
    this.connectBtn = document.getElementById('lobby-connect');
    this.serverUrlEl = document.getElementById('lobby-server-url');

    this.nameInput.value = SaveManager.loadPlayerName() || '';
    this.serverUrlEl.textContent = CONFIG.multiplayerServerUrl
      ? `Server: ${CONFIG.multiplayerServerUrl}`
      : 'No multiplayer server is configured for this build yet (see README "Configuring the client").';

    document.getElementById('lobby-back').addEventListener('click', () => onBack());
    this.connectBtn.addEventListener('click', () => {
      const name = this.nameInput.value.trim() || 'Driver';
      SaveManager.savePlayerName(name);
      onConnect(name);
    });
  }

  setStatus(text, state) {
    // state: 'neutral' | 'ok' | 'error'
    this.statusEl.textContent = text;
    this.statusEl.className = 'lobby-status' + (state === 'ok' ? ' lobby-status--ok' : state === 'error' ? ' lobby-status--error' : '');
  }

  setConnecting(isConnecting) {
    this.connectBtn.disabled = isConnecting;
    this.connectBtn.textContent = isConnecting ? 'Connecting…' : 'Connect';
  }

  show() {
    this.setStatus(CONFIG.multiplayerServerUrl ? 'Not connected.' : 'No server configured — see README.', 'neutral');
    this.setConnecting(false);
  }
}
