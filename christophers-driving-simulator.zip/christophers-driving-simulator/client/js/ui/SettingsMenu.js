// client/js/ui/SettingsMenu.js
// Reusable from both the main menu and the in-game pause menu. Every control
// reads its initial value from SaveManager and writes back on change, then
// calls the relevant live-apply callback so a graphics/audio change takes
// effect immediately instead of requiring a restart.

import { SaveManager, DEFAULT_KEYBINDINGS } from '../core/SaveManager.js';

const ACTION_LABELS = {
  accelerate: 'Accelerate', brake: 'Brake / Reverse', steerLeft: 'Steer left', steerRight: 'Steer right',
  handbrake: 'Handbrake', reset: 'Reset vehicle', pause: 'Pause', cameraMode: 'Change camera',
};

export class SettingsMenu {
  constructor({ inputManager, onGraphicsChange, onAudioChange, onGameplayChange, onBack }) {
    this.inputManager = inputManager;
    this.onGraphicsChange = onGraphicsChange;
    this.onAudioChange = onAudioChange;
    this.onGameplayChange = onGameplayChange;
    this.settings = SaveManager.loadSettings();

    this.panelsEl = document.getElementById('settings-panels');
    this.tabsEl = document.getElementById('settings-tabs');

    this.tabsEl.querySelectorAll('.settings-tab').forEach((tab) => {
      tab.addEventListener('click', () => this._activateTab(tab.dataset.tab));
    });
    document.getElementById('settings-back').addEventListener('click', () => onBack());

    this._renderAll();
  }

  _activateTab(name) {
    this.tabsEl.querySelectorAll('.settings-tab').forEach((t) => t.classList.toggle('settings-tab--active', t.dataset.tab === name));
    this.panelsEl.querySelectorAll('.settings-panel').forEach((p) => p.classList.toggle('settings-panel--active', p.dataset.panel === name));
  }

  _save() {
    SaveManager.saveSettings(this.settings);
  }

  _renderAll() {
    this.panelsEl.innerHTML = '';
    this.panelsEl.appendChild(this._buildGraphicsPanel());
    this.panelsEl.appendChild(this._buildAudioPanel());
    this.panelsEl.appendChild(this._buildControlsPanel());
    this.panelsEl.appendChild(this._buildGameplayPanel());
    this._activateTab('graphics');
  }

  _panel(name, active = false) {
    const div = document.createElement('div');
    div.className = 'settings-panel' + (active ? ' settings-panel--active' : '');
    div.dataset.panel = name;
    return div;
  }

  _select(labelText, value, options, onChange) {
    const row = document.createElement('div');
    row.className = 'field-row';
    const label = document.createElement('label');
    label.textContent = labelText;
    const select = document.createElement('select');
    select.style.cssText = 'background:var(--panel-alt);color:var(--text);border:1px solid var(--border);border-radius:6px;padding:0.4rem 0.6rem;';
    for (const opt of options) {
      const o = document.createElement('option');
      o.value = opt;
      o.textContent = opt[0].toUpperCase() + opt.slice(1);
      if (opt === value) o.selected = true;
      select.appendChild(o);
    }
    select.addEventListener('change', () => onChange(select.value));
    row.append(label, select);
    return row;
  }

  _toggle(labelText, checked, onChange) {
    const row = document.createElement('div');
    row.className = 'field-row';
    const label = document.createElement('label');
    label.textContent = labelText;
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.className = 'toggle';
    input.checked = checked;
    input.addEventListener('change', () => onChange(input.checked));
    row.append(label, input);
    return row;
  }

  _slider(labelText, value, min, max, step, onChange) {
    const row = document.createElement('div');
    row.className = 'field-row';
    const label = document.createElement('label');
    label.textContent = labelText;
    const input = document.createElement('input');
    Object.assign(input, { type: 'range', min, max, step, value });
    input.addEventListener('input', () => onChange(parseFloat(input.value)));
    row.append(label, input);
    return row;
  }

  _buildGraphicsPanel() {
    const g = this.settings.graphics;
    const panel = this._panel('graphics', true);
    panel.appendChild(this._select('Quality preset', g.quality, ['low', 'medium', 'high'], (v) => {
      g.quality = v;
      this._save();
      this.onGraphicsChange(g);
    }));
    panel.appendChild(this._toggle('Shadows', g.shadows, (v) => {
      g.shadows = v; this._save(); this.onGraphicsChange(g);
    }));
    panel.appendChild(this._toggle('Anti-aliasing (applies on next launch)', g.antialiasing, (v) => {
      g.antialiasing = v; this._save();
    }));
    panel.appendChild(this._slider('View distance (m)', g.viewDistance, 150, 1000, 10, (v) => {
      g.viewDistance = v; this._save(); this.onGraphicsChange(g);
    }));
    return panel;
  }

  _buildAudioPanel() {
    const a = this.settings.audio;
    const panel = this._panel('audio');
    panel.appendChild(this._slider('Master volume', a.master, 0, 1, 0.01, (v) => {
      a.master = v; this._save(); this.onAudioChange(a);
    }));
    panel.appendChild(this._slider('Music volume', a.music, 0, 1, 0.01, (v) => {
      a.music = v; this._save(); this.onAudioChange(a);
    }));
    panel.appendChild(this._slider('Effects volume', a.effects, 0, 1, 0.01, (v) => {
      a.effects = v; this._save(); this.onAudioChange(a);
    }));
    return panel;
  }

  _buildControlsPanel() {
    const panel = this._panel('controls');
    const bindings = this.inputManager.bindings;
    for (const action of Object.keys(DEFAULT_KEYBINDINGS)) {
      const row = document.createElement('div');
      row.className = 'keybind-row';
      const label = document.createElement('span');
      label.textContent = ACTION_LABELS[action] || action;
      const btn = document.createElement('button');
      btn.className = 'keybind-btn';
      btn.textContent = this.inputManager.bindingLabel(action);
      btn.addEventListener('click', () => {
        btn.textContent = 'Press a key…';
        btn.classList.add('listening');
        this.inputManager.beginRebind(action, (a, code) => {
          btn.textContent = this.inputManager.bindingLabel(a);
          btn.classList.remove('listening');
        });
      });
      row.append(label, btn);
      panel.appendChild(row);
    }
    const resetBtn = document.createElement('button');
    resetBtn.className = 'btn btn--ghost';
    resetBtn.style.marginTop = '0.6rem';
    resetBtn.textContent = 'Reset to defaults';
    resetBtn.addEventListener('click', () => {
      this.inputManager.resetBindingsToDefault(DEFAULT_KEYBINDINGS);
      this._renderAll();
      this._activateTab('controls');
    });
    panel.appendChild(resetBtn);
    return panel;
  }

  _buildGameplayPanel() {
    const gp = this.settings.gameplay;
    const panel = this._panel('gameplay');
    panel.appendChild(this._slider('Camera sensitivity', gp.cameraSensitivity, 0.4, 2, 0.05, (v) => {
      gp.cameraSensitivity = v; this._save(); this.onGameplayChange(gp);
    }));
    panel.appendChild(this._slider('Camera distance', gp.cameraDistance, 0.6, 1.6, 0.05, (v) => {
      gp.cameraDistance = v; this._save(); this.onGameplayChange(gp);
    }));
    panel.appendChild(this._toggle('Driving assist (mild traction help)', gp.drivingAssist, (v) => {
      gp.drivingAssist = v; this._save(); this.onGameplayChange(gp);
    }));
    panel.appendChild(this._toggle('Reduced motion (disables menu animation)', gp.reducedMotion, (v) => {
      gp.reducedMotion = v; this._save();
      document.body.classList.toggle('reduced-motion', v);
    }));
    return panel;
  }
}
