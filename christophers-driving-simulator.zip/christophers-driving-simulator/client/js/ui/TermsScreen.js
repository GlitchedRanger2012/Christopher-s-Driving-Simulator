// client/js/ui/TermsScreen.js
// Renders shared/termsContent.js into the scrollable terms panel, and only
// enables Accept once the player has actually scrolled to the bottom —
// checked against real scroll position, not a timer or a fake delay.

import { TERMS_SECTIONS, TERMS_EFFECTIVE_DATE } from '../../../shared/termsContent.js';
import { TERMS_VERSION } from '../../../shared/constants.js';
import { SaveManager } from '../core/SaveManager.js';

function renderBodyItem(item) {
  if (typeof item === 'string') {
    const p = document.createElement('p');
    p.textContent = item;
    return p;
  }
  if (item.ul) {
    const ul = document.createElement('ul');
    for (const li of item.ul) {
      const el = document.createElement('li');
      el.textContent = li;
      ul.appendChild(el);
    }
    return ul;
  }
  return document.createDocumentFragment();
}

export class TermsScreen {
  constructor({ onAccept, onDecline }) {
    this.onAccept = onAccept;
    this.onDecline = onDecline;
    this.scrollEl = document.getElementById('terms-scroll');
    this.contentEl = document.getElementById('terms-content');
    this.acceptBtn = document.getElementById('terms-accept');
    this.declineBtn = document.getElementById('terms-decline');

    this._render();

    this._onScroll = this._onScroll.bind(this);
    this.scrollEl.addEventListener('scroll', this._onScroll);
    this.acceptBtn.addEventListener('click', () => {
      SaveManager.acceptCurrentTerms();
      this.onAccept();
    });
    this.declineBtn.addEventListener('click', () => this.onDecline());
  }

  _render() {
    this.contentEl.innerHTML = '';
    const meta = document.createElement('p');
    meta.className = 'muted small';
    meta.textContent = `Version ${TERMS_VERSION} · Effective ${TERMS_EFFECTIVE_DATE}`;
    this.contentEl.appendChild(meta);

    for (const section of TERMS_SECTIONS) {
      const h2 = document.createElement('h2');
      h2.textContent = section.heading;
      this.contentEl.appendChild(h2);
      for (const item of section.body) {
        this.contentEl.appendChild(renderBodyItem(item));
      }
    }
  }

  _onScroll() {
    const el = this.scrollEl;
    const reachedBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 12;
    if (reachedBottom) this.acceptBtn.disabled = false;
  }

  /** Handles the case where the content is short enough to need no scrolling at all. */
  checkInitialFit() {
    if (this.scrollEl.scrollHeight <= this.scrollEl.clientHeight + 4) {
      this.acceptBtn.disabled = false;
    }
  }

  show() {
    this.acceptBtn.disabled = true;
    this.scrollEl.scrollTop = 0;
    // Layout needs a frame to settle before scrollHeight is reliable.
    requestAnimationFrame(() => this.checkInitialFit());
  }
}
