// client/js/config.js
//
// Single place that decides where the multiplayer server lives. Do NOT
// hard-code a production URL here as a fallback for everyone — an empty
// production value fails loudly (see MultiplayerSession) instead of quietly
// trying to reach someone's localhost.
//
// To point this build at your deployed backend, set PRODUCTION_SERVER_URL
// below before you deploy the frontend to GitHub Pages. See README.md
// ("Deploying the backend" and "Configuring the client").

const PRODUCTION_SERVER_URL = ''; // e.g. 'https://your-server.onrender.com'
const LOCAL_DEV_SERVER_URL = 'http://localhost:3001';

const isLocalHost = ['localhost', '127.0.0.1', ''].includes(window.location.hostname);

// Lets you point a deployed frontend at a test backend without rebuilding,
// e.g. https://you.github.io/repo/?server=https://staging-server.example.com
const urlOverride = new URLSearchParams(window.location.search).get('server');

export const CONFIG = {
  gameTitle: "Christopher's Driving Simulator",
  multiplayerServerUrl: urlOverride || (isLocalHost ? LOCAL_DEV_SERVER_URL : PRODUCTION_SERVER_URL),
  isLocalHost,
  build: {
    threeVersion: '0.170.x (via jsDelivr)',
    socketIoVersion: '4.8.3',
  },
};
