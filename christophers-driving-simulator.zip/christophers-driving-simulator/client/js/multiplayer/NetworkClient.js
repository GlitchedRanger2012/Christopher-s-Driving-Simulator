// client/js/multiplayer/NetworkClient.js
//
// Thin wrapper around the socket.io-client global (loaded via CDN script tag
// in index.html — see README for why it's a <script> tag rather than an ES
// import: it needs to work from a plain GitHub Pages static file, and the
// socket.io CDN build attaches a global `io` rather than shipping as a
// same-origin ES module). Every outbound event carries only what the server
// actually needs; the server is the one that decides whether to trust it
// (see server/src/validators — client-side, this module does no validation
// of its own beyond "is this a finite number," which is just to avoid
// spamming obviously-broken packets during development).

import { NETWORK_SEND_RATE_HZ } from '../../../shared/constants.js';

const SEND_INTERVAL_MS = 1000 / NETWORK_SEND_RATE_HZ;

export class NetworkClient {
  constructor(handlers = {}) {
    this.handlers = handlers;
    this.socket = null;
    this.connected = false;
    this.selfId = null;
    this._lastSendAt = 0;
    this.remotePlayers = new Map(); // id -> { name, vehicleId, x, y, z, rotationY }
  }

  connect(serverUrl, { name, vehicleId }) {
    if (!serverUrl) {
      this.handlers.onConnectError?.('No multiplayer server is configured for this build.');
      return;
    }
    if (typeof window.io !== 'function') {
      this.handlers.onConnectError?.('The multiplayer library failed to load (check your internet connection and try again).');
      return;
    }

    this.socket = window.io(serverUrl, {
      transports: ['websocket', 'polling'],
      timeout: 8000,
      reconnectionAttempts: 5,
    });

    this.socket.on('connect', () => {
      this.connected = true;
      this.selfId = this.socket.id;
      this.socket.emit('join', { name, vehicleId });
    });

    this.socket.on('connect_error', (err) => {
      this.handlers.onConnectError?.(err?.message || 'Could not reach the multiplayer server.');
    });

    this.socket.on('joinRejected', (payload) => {
      this.handlers.onConnectError?.(payload?.reason || 'The server rejected the connection.');
      this.disconnect();
    });

    // Sent only to us, once, right after the server accepts our 'join': our
    // assigned spawn point plus a snapshot of everyone already connected.
    // This (rather than a generic repeating "roster" broadcast) is what lets
    // the server hand out spawn points without two players landing on top
    // of each other.
    this.socket.on('joined', ({ self, players }) => {
      this.remotePlayers.clear();
      for (const p of players) {
        if (p.id !== this.selfId) this.remotePlayers.set(p.id, p);
      }
      this.handlers.onJoined?.(self, this._rosterArray());
    });

    this.socket.on('playerJoined', (p) => {
      if (p.id === this.selfId) return;
      this.remotePlayers.set(p.id, p);
      this.handlers.onRosterUpdate?.(this._rosterArray());
    });

    this.socket.on('playerLeft', ({ id }) => {
      this.remotePlayers.delete(id);
      this.handlers.onPlayerLeft?.(id);
      this.handlers.onRosterUpdate?.(this._rosterArray());
    });

    this.socket.on('playerMoved', (p) => {
      const existing = this.remotePlayers.get(p.id);
      if (existing) Object.assign(existing, p);
      this.handlers.onPlayerMoved?.(p);
    });

    this.socket.on('playerVehicleChanged', ({ id, vehicleId }) => {
      const existing = this.remotePlayers.get(id);
      if (existing) existing.vehicleId = vehicleId;
      this.handlers.onPlayerVehicleChanged?.(id, vehicleId);
    });

    this.socket.on('quickChat', ({ id, messageId }) => {
      this.handlers.onQuickChat?.(id, messageId);
    });

    this.socket.on('disconnect', (reason) => {
      this.connected = false;
      this.handlers.onDisconnected?.(reason);
    });
  }

  _rosterArray() {
    return Array.from(this.remotePlayers.entries()).map(([id, p]) => ({ id, ...p }));
  }

  /** Throttled to NETWORK_SEND_RATE_HZ regardless of how often the caller invokes this. */
  sendTransform(x, y, z, rotationY) {
    if (!this.connected) return;
    const now = performance.now();
    if (now - this._lastSendAt < SEND_INTERVAL_MS) return;
    if (![x, y, z, rotationY].every(Number.isFinite)) return;
    this._lastSendAt = now;
    this.socket.emit('move', { x, y, z, rotationY, t: Date.now() });
  }

  sendVehicleSelection(vehicleId) {
    if (!this.connected) return;
    this.socket.emit('selectVehicle', { vehicleId });
  }

  sendQuickChat(messageId) {
    if (!this.connected) return;
    this.socket.emit('quickChat', { messageId });
  }

  disconnect() {
    if (this.socket) {
      this.socket.removeAllListeners();
      this.socket.disconnect();
    }
    this.socket = null;
    this.connected = false;
    this.remotePlayers.clear();
  }
}
