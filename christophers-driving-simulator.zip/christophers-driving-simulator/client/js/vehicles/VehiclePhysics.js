// client/js/vehicles/VehiclePhysics.js
//
// Honest scope note (also in README "Known limitations"): this is an
// arcade-style simplified physics model (raycast-to-ground + a bicycle-model
// lateral slip approximation), the same broad approach used by most browser
// and mobile racing games. It is NOT a full rigid-body / constraint solver
// (no per-wheel suspension springs simulated individually, no true tire
// slip-angle curves). What it does implement for real, per requirement 9:
// engine force derived from each car's own acceleration/topSpeed/mass,
// braking derived from each car's braking stat, drag, grip-limited cornering
// with drift when grip is exceeded, gravity + airborne state via ground
// sampling, basic circular collision against world geometry, body roll/pitch
// for suspension feel, and a reset-to-last-safe-position recovery system.
// Every car's stats genuinely change how it drives (see TESTING_REPORT.md
// for exactly what was and wasn't verified in this environment).

import * as THREE from '../vendor/three.js';
import { GRAVITY } from '../../../shared/constants.js';

const REF_SPEED_MS = 100 / 3.6; // the "0-100kph" benchmark speed used by the stat sheet
const DRAG_K = 0.00015; // quadratic drag coefficient (tuned small — see file header)
const ROLL_RESIST = 1.1; // m/s^2, constant coasting deceleration
const UPSHIFT_RPM = 6500;
const DOWNSHIFT_RPM = 1800;
const IDLE_RPM = 850;
const GEAR_COUNT = 6;
const SAFE_POSITION_INTERVAL = 1.5; // seconds between "safe" position snapshots

export class VehiclePhysics {
  constructor(vehicle, spawn) {
    this.vehicle = vehicle;
    this.position = new THREE.Vector3(spawn.x, 0, spawn.z);
    this.yaw = spawn.heading || 0;
    this.tiltX = 0; // roll (banking into corners)
    this.tiltZ = 0; // pitch (nose dive / squat)
    this.forwardSpeed = 0; // m/s, signed
    this.lateralSpeed = 0; // m/s, signed (slide)
    this.verticalVelocity = 0;
    this.steerAngle = 0;
    this.angularVelocity = 0;
    this.grounded = true;
    this.gear = 1;
    this.rpm = IDLE_RPM;
    this.drifting = false;

    this.wheelbase = vehicle.dimensions.length * 0.58;
    this.topSpeedMs = vehicle.topSpeed / 3.6;
    this.reverseTopSpeedMs = Math.min(11, this.topSpeedMs * 0.25);
    this.baseAccel = REF_SPEED_MS / vehicle.acceleration;
    this.brakeDecel = (REF_SPEED_MS * REF_SPEED_MS) / (2 * vehicle.braking);
    this.maxLateralAccel = 4 + (vehicle.grip / 100) * 10; // 4..14 m/s^2
    this.maxSteerAngle = THREE.MathUtils.degToRad(24 + (vehicle.steering / 100) * 14); // 24..38 deg
    this.steerRate = THREE.MathUtils.degToRad(90 + (vehicle.steering / 100) * 120); // deg/s

    this._safeTimer = 0;
    this.safePosition = this.position.clone();
    this.safeYaw = this.yaw;
  }

  getSpeedKph() {
    return this.forwardSpeed * 3.6;
  }

  getTransform() {
    return { position: this.position, yaw: this.yaw, tiltX: this.tiltX, tiltZ: this.tiltZ };
  }

  getTelemetry() {
    return {
      speedKph: this.getSpeedKph(),
      rpm: this.rpm,
      gear: this.forwardSpeed < -0.3 ? 'R' : this.gear,
      grounded: this.grounded,
      drifting: this.drifting,
    };
  }

  resetToSafePosition() {
    this.position.copy(this.safePosition);
    this.position.y = 0;
    this.yaw = this.safeYaw;
    this.forwardSpeed = 0;
    this.lateralSpeed = 0;
    this.verticalVelocity = 0;
    this.tiltX = 0;
    this.tiltZ = 0;
    this.gear = 1;
    this.rpm = IDLE_RPM;
  }

  teleportTo(x, z, heading) {
    this.position.set(x, 0, z);
    this.yaw = heading;
    this.forwardSpeed = 0;
    this.lateralSpeed = 0;
    this.verticalVelocity = 0;
    this.safePosition.set(x, 0, z);
    this.safeYaw = heading;
  }

  update(dt, input, world) {
    const events = { collided: false, collisionSpeed: 0, justLanded: false };
    dt = Math.min(dt, 1 / 15); // clamp huge dt spikes (tab switch) so nothing teleports

    this._updateSteering(dt, input);
    this._updateLongitudinal(dt, input);
    this._updateLateral(dt, input);
    this._integratePosition(dt);
    this._resolveGround(dt, world, events);
    this._resolveCollisions(world, events);
    this._updateGearAndRpm(dt);
    this._updateSafePosition(dt);

    return events;
  }

  _updateSteering(dt, input) {
    const target = input.steer * this.maxSteerAngle;
    const maxDelta = this.steerRate * dt;
    const delta = THREE.MathUtils.clamp(target - this.steerAngle, -maxDelta, maxDelta);
    this.steerAngle += delta;
  }

  _updateLongitudinal(dt, input) {
    const v = this.forwardSpeed;
    let accel = 0;

    const reversing = v <= 0.05 && input.brake > 0 && input.throttle <= 0.02;
    if (reversing) {
      const t = Math.abs(v) / this.reverseTopSpeedMs;
      accel -= this.baseAccel * 0.5 * Math.max(0, 1 - t * t) * input.brake;
    } else {
      if (input.throttle > 0) {
        const t = Math.max(0, v) / this.topSpeedMs;
        accel += this.baseAccel * Math.max(0, 1 - t * t) * input.throttle;
      }
      if (input.brake > 0 && v > 0.05) {
        accel -= this.brakeDecel * input.brake;
      }
    }

    if (input.handbrake) {
      accel -= this.brakeDecel * 0.12; // a mild scrub — handbrake's real job is cutting lateral grip, below
    }

    this._lastAccelSign = Math.sign(accel);

    // Drag + rolling resistance always oppose current motion.
    accel -= Math.sign(v) * DRAG_K * v * v;
    if (Math.abs(v) > 0.05 && input.throttle <= 0.02 && !reversing) {
      accel -= Math.sign(v) * ROLL_RESIST;
    }

    this.forwardSpeed += accel * dt;

    // Don't let rolling resistance alone reverse the sign of motion (no oscillation).
    if (!reversing && Math.abs(this.forwardSpeed) < 0.03 && input.throttle <= 0.02 && input.brake <= 0.02) {
      this.forwardSpeed = 0;
    }
  }

  _updateLateral(dt, input) {
    const v = this.forwardSpeed;
    const desiredYawRate = Math.abs(v) > 0.1 ? (v / this.wheelbase) * Math.tan(this.steerAngle) : 0;
    const desiredLateralAccel = Math.abs(v * desiredYawRate);

    let effectiveMaxLateral = this.maxLateralAccel;
    if (input.handbrake) effectiveMaxLateral *= 0.3;
    effectiveMaxLateral = Math.max(effectiveMaxLateral, 0.6);

    if (desiredLateralAccel <= effectiveMaxLateral) {
      this.angularVelocity = desiredYawRate;
      this.lateralSpeed = THREE.MathUtils.lerp(this.lateralSpeed, 0, Math.min(1, dt * 6));
      this.drifting = false;
    } else {
      const grip = effectiveMaxLateral / Math.max(desiredLateralAccel, 0.0001);
      this.angularVelocity = desiredYawRate * grip;
      const slideTarget = Math.sign(desiredYawRate) * (desiredLateralAccel - effectiveMaxLateral) * 0.5;
      this.lateralSpeed = THREE.MathUtils.lerp(this.lateralSpeed, slideTarget, Math.min(1, dt * 3));
      this.drifting = true;
    }

    this.yaw += this.angularVelocity * dt;

    // Suspension-feel body tilt: roll into corners, pitch under accel/brake.
    const rollTarget = THREE.MathUtils.clamp(-this.angularVelocity * (Math.abs(v) / 20), -0.12, 0.12);
    const pitchTarget = THREE.MathUtils.clamp((this._lastAccelSign || 0) * -0.05, -0.06, 0.06);
    this.tiltX = THREE.MathUtils.lerp(this.tiltX, rollTarget, Math.min(1, dt * 5));
    this.tiltZ = THREE.MathUtils.lerp(this.tiltZ, pitchTarget, Math.min(1, dt * 5));
  }

  _integratePosition(dt) {
    const forward = new THREE.Vector3(Math.cos(this.yaw), 0, Math.sin(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw - Math.PI / 2), 0, Math.sin(this.yaw - Math.PI / 2));
    const worldVel = forward.multiplyScalar(this.forwardSpeed).addScaledVector(right, this.lateralSpeed);
    this.position.x += worldVel.x * dt;
    this.position.z += worldVel.z * dt;
  }

  _resolveGround(dt, world, events) {
    const ground = world?.sampleGroundHeight
      ? world.sampleGroundHeight(this.position.x, this.position.z)
      : { height: 0 };
    const targetY = ground.height;
    const wasGrounded = this.grounded;

    if (this.position.y > targetY + 0.06 || !wasGrounded) {
      this.verticalVelocity -= GRAVITY * dt;
      this.position.y += this.verticalVelocity * dt;
      if (this.position.y <= targetY) {
        this.position.y = targetY;
        this.verticalVelocity = 0;
        this.grounded = true;
        if (!wasGrounded) events.justLanded = true;
      } else {
        this.grounded = false;
      }
    } else {
      this.position.y = THREE.MathUtils.lerp(this.position.y, targetY, Math.min(1, dt * 10));
      this.verticalVelocity = 0;
      this.grounded = true;
    }
  }

  _resolveCollisions(world, events) {
    if (!world?.getNearbyColliders) return;
    const halfLen = this.vehicle.dimensions.length / 2;
    const halfWid = this.vehicle.dimensions.width / 2;
    const colliders = world.getNearbyColliders(this.position.x, this.position.z);

    for (const c of colliders) {
      const closestX = THREE.MathUtils.clamp(this.position.x, c.minX, c.maxX);
      const closestZ = THREE.MathUtils.clamp(this.position.z, c.minZ, c.maxZ);
      const dx = this.position.x - closestX;
      const dz = this.position.z - closestZ;
      const distSq = dx * dx + dz * dz;
      const combinedRadius = Math.max(halfLen, halfWid) * 0.9;

      if (distSq < combinedRadius * combinedRadius) {
        const dist = Math.sqrt(distSq) || 0.001;
        const nx = dx / dist;
        const nz = dz / dist;
        const penetration = combinedRadius - dist;
        this.position.x += nx * penetration;
        this.position.z += nz * penetration;

        const impactSpeed = Math.abs(this.forwardSpeed);
        events.collided = true;
        events.collisionSpeed = Math.max(events.collisionSpeed, impactSpeed);

        // Kill the velocity component driving into the wall; keep the rest.
        this.forwardSpeed *= 0.35;
        this.lateralSpeed *= 0.35;
      }
    }
  }

  _updateGearAndRpm() {
    const speed = Math.abs(this.forwardSpeed);
    const speedFrac = THREE.MathUtils.clamp(speed / this.topSpeedMs, 0, 1);
    const gearSpan = 1 / GEAR_COUNT;
    if (speed < 0.3) {
      this.gear = 1;
      this.rpm = IDLE_RPM;
      return;
    }
    let gearFloat = speedFrac / gearSpan;
    let gear = THREE.MathUtils.clamp(Math.floor(gearFloat) + 1, 1, GEAR_COUNT);

    // hysteresis using previous gear to avoid flickering at boundaries
    if (gear > this.gear && this.rpm < UPSHIFT_RPM * 0.85) gear = this.gear;
    if (gear < this.gear && this.rpm > DOWNSHIFT_RPM * 1.3) gear = this.gear;
    this.gear = THREE.MathUtils.clamp(gear, 1, GEAR_COUNT);

    const withinGear = THREE.MathUtils.clamp((speedFrac - (this.gear - 1) * gearSpan) / gearSpan, 0, 1.15);
    this.rpm = Math.round(IDLE_RPM + withinGear * (UPSHIFT_RPM + 300 - IDLE_RPM));
  }

  _updateSafePosition(dt) {
    this._safeTimer += dt;
    const level = Math.abs(this.tiltX) < 0.25 && Math.abs(this.tiltZ) < 0.25;
    if (this._safeTimer > SAFE_POSITION_INTERVAL && this.grounded && level) {
      this._safeTimer = 0;
      this.safePosition.copy(this.position);
      this.safeYaw = this.yaw;
    }
  }
}
