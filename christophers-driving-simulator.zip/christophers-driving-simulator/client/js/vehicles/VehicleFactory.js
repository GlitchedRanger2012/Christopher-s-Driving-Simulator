// client/js/vehicles/VehicleFactory.js
//
// Builds a THREE.Group for a vehicle from its data record — no external 3D
// model files. Honest scope note (see README "Known limitations"): this is
// NOT 45 unique hand-modeled meshes. It's 8 category "silhouette" templates
// (one per category in shared/vehicleData.js), each parametrized by that
// car's actual length/width/height and colors, plus category-specific
// details (spoilers, a truck bed, a roof rack, a bull bar). Two cars in the
// same category with different dimensions and colors really do look
// different in-scene; they don't have unique body panels.
//
// Every builder returns a THREE.Group with named references
// (wheelFL/FR/RL/RR, brakeLightL/R) that VehicleController animates each
// frame (wheel spin + steer, brake light glow).

import * as THREE from '../vendor/three.js';

function box(w, h, d, color, opts = {}) {
  const geo = new THREE.BoxGeometry(w, h, d);
  const mat = new THREE.MeshStandardMaterial({
    color,
    metalness: opts.metalness ?? 0.35,
    roughness: opts.roughness ?? 0.5,
    emissive: opts.emissive ?? 0x000000,
    emissiveIntensity: opts.emissiveIntensity ?? 0,
    transparent: !!opts.transparent,
    opacity: opts.opacity ?? 1,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  return mesh;
}

function buildWheel(radius, width, hubColor = 0x1b1e24) {
  const group = new THREE.Group();
  const tire = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, width, 16),
    new THREE.MeshStandardMaterial({ color: 0x111214, roughness: 0.9, metalness: 0.05 }),
  );
  tire.rotation.z = Math.PI / 2;
  tire.castShadow = true;
  const hub = new THREE.Mesh(
    new THREE.CylinderGeometry(radius * 0.55, radius * 0.55, width * 1.02, 10),
    new THREE.MeshStandardMaterial({ color: hubColor, roughness: 0.4, metalness: 0.7 }),
  );
  hub.rotation.z = Math.PI / 2;
  group.add(tire, hub);
  return group;
}

function addWheels(root, vehicle, wheelRadius, wheelWidth) {
  const { length, width } = vehicle.dimensions;
  const axleX = length * 0.32;
  const axleY = wheelRadius;
  const axleZ = width / 2 + wheelWidth * 0.15;

  const wheelFL = buildWheel(wheelRadius, wheelWidth);
  wheelFL.position.set(axleX, axleY, axleZ);
  const wheelFR = buildWheel(wheelRadius, wheelWidth);
  wheelFR.position.set(axleX, axleY, -axleZ);
  const wheelRL = buildWheel(wheelRadius, wheelWidth);
  wheelRL.position.set(-axleX, axleY, axleZ);
  const wheelRR = buildWheel(wheelRadius, wheelWidth);
  wheelRR.position.set(-axleX, axleY, -axleZ);

  root.add(wheelFL, wheelFR, wheelRL, wheelRR);
  return { wheelFL, wheelFR, wheelRL, wheelRR };
}

function addBrakeLights(root, vehicle, atX, atZ, atY) {
  const mat = { emissive: 0xff2222, emissiveIntensity: 0, metalness: 0.1, roughness: 0.6 };
  const brakeLightL = box(0.08, 0.14, 0.35, 0xff2222, mat);
  brakeLightL.position.set(atX, atY, atZ);
  const brakeLightR = box(0.08, 0.14, 0.35, 0xff2222, mat);
  brakeLightR.position.set(atX, atY, -atZ);
  root.add(brakeLightL, brakeLightR);
  return { brakeLightL, brakeLightR };
}

function baseGroup(vehicle) {
  const root = new THREE.Group();
  root.name = `vehicle-${vehicle.id}`;
  return root;
}

// ---- category builders ----
// Each receives the vehicle data record and returns { root, wheels, brakeLights, groundClearance }

function buildLowBody(vehicle, { cabinSet = 0, cabinHeightScale = 0.55, wheelRadiusScale = 0.34 }) {
  const { length, width, height } = vehicle.dimensions;
  const root = baseGroup(vehicle);
  const wheelRadius = height * wheelRadiusScale;
  const groundClearance = wheelRadius * 0.9;

  const lower = box(length, height * 0.55, width, vehicle.color);
  lower.position.y = groundClearance + height * 0.275;
  root.add(lower);

  const cabin = box(length * 0.5, height * cabinHeightScale, width * 0.86, vehicle.accentColor, {
    metalness: 0.15, roughness: 0.25, transparent: true, opacity: 0.85,
  });
  cabin.position.set(length * (0.02 - cabinSet), groundClearance + height * 0.55 + (height * cabinHeightScale) / 2, 0);
  root.add(cabin);

  const wheels = addWheels(root, vehicle, wheelRadius, width * 0.22);
  const brakeLights = addBrakeLights(root, vehicle, -length / 2 - 0.02, width * 0.32, groundClearance + height * 0.45);
  return { root, wheels, brakeLights, groundClearance, wheelRadius };
}

const BUILDERS = {
  compact: (v) => buildLowBody(v, { cabinSet: -0.02, cabinHeightScale: 0.62, wheelRadiusScale: 0.36 }),
  sedan: (v) => buildLowBody(v, { cabinSet: 0.02, cabinHeightScale: 0.56, wheelRadiusScale: 0.33 }),

  sports: (v) => {
    const built = buildLowBody(v, { cabinSet: 0.08, cabinHeightScale: 0.42, wheelRadiusScale: 0.36 });
    const { length, width, height } = v.dimensions;
    const spoiler = box(width * 0.7, 0.06, 0.28, v.accentColor, { metalness: 0.5 });
    spoiler.position.set(-length / 2 + 0.1, built.groundClearance + height * 0.75, 0);
    built.root.add(spoiler);
    return built;
  },

  supercar: (v) => {
    const built = buildLowBody(v, { cabinSet: 0.1, cabinHeightScale: 0.36, wheelRadiusScale: 0.38 });
    const { length, width, height } = v.dimensions;
    const wing = box(width * 0.82, 0.05, 0.32, v.accentColor, { metalness: 0.6 });
    wing.position.set(-length / 2 + 0.05, built.groundClearance + height * 0.85, 0);
    const strutL = box(0.05, 0.18, 0.05, v.accentColor);
    strutL.position.set(-length / 2 + 0.1, built.groundClearance + height * 0.7, width * 0.28);
    const strutR = strutL.clone();
    strutR.position.z = -width * 0.28;
    built.root.add(wing, strutL, strutR);
    return built;
  },

  muscle: (v) => {
    const built = buildLowBody(v, { cabinSet: -0.14, cabinHeightScale: 0.5, wheelRadiusScale: 0.36 });
    const { length, width, height } = v.dimensions;
    const hoodScoop = box(length * 0.14, 0.08, width * 0.3, 0x14161a, { metalness: 0.2 });
    hoodScoop.position.set(length * 0.28, built.groundClearance + height * 0.58, 0);
    built.root.add(hoodScoop);
    return built;
  },

  suv: (v) => {
    const built = buildLowBody(v, { cabinSet: 0.0, cabinHeightScale: 0.78, wheelRadiusScale: 0.36 });
    const { length, width, height } = v.dimensions;
    const rackRail = (side) => {
      const rail = box(length * 0.6, 0.04, 0.04, 0x2c3038, { metalness: 0.7, roughness: 0.3 });
      rail.position.set(0, built.groundClearance + height * 1.02, side * width * 0.36);
      return rail;
    };
    built.root.add(rackRail(1), rackRail(-1));
    return built;
  },

  truck: (v) => {
    const { length, width, height } = v.dimensions;
    const root = baseGroup(v);
    const wheelRadius = height * 0.34;
    const groundClearance = wheelRadius * 1.05;

    const cab = box(length * 0.38, height * 0.62, width, v.color);
    cab.position.set(length * 0.24, groundClearance + height * 0.31, 0);
    const cabin = box(length * 0.32, height * 0.4, width * 0.88, v.accentColor, {
      transparent: true, opacity: 0.85, metalness: 0.15, roughness: 0.25,
    });
    cabin.position.set(length * 0.28, groundClearance + height * 0.62 + (height * 0.4) / 2, 0);
    const bedFloor = box(length * 0.5, height * 0.08, width * 0.94, v.color);
    bedFloor.position.set(-length * 0.22, groundClearance + height * 0.18, 0);
    const bedWallBack = box(0.08, height * 0.32, width * 0.94, v.color);
    bedWallBack.position.set(-length * 0.47, groundClearance + height * 0.34, 0);
    const bedWallL = box(length * 0.5, height * 0.22, 0.06, v.color);
    bedWallL.position.set(-length * 0.22, groundClearance + height * 0.29, width * 0.47);
    const bedWallR = bedWallL.clone();
    bedWallR.position.z = -width * 0.47;

    root.add(cab, cabin, bedFloor, bedWallBack, bedWallL, bedWallR);
    const wheels = addWheels(root, v, wheelRadius, width * 0.24);
    const brakeLights = addBrakeLights(root, v, -length / 2 - 0.02, width * 0.34, groundClearance + height * 0.32);
    return { root, wheels, brakeLights, groundClearance, wheelRadius };
  },

  offroad: (v) => {
    const built = buildLowBody(v, { cabinSet: 0.0, cabinHeightScale: 0.72, wheelRadiusScale: 0.42 });
    const { length, width, height } = v.dimensions;
    const bullBar = box(0.12, height * 0.3, width * 0.9, 0x2c3038, { metalness: 0.6, roughness: 0.3 });
    bullBar.position.set(length / 2 + 0.08, built.groundClearance + height * 0.32, 0);
    built.root.add(bullBar);
    return built;
  },
};

/**
 * Creates a fully-assembled, positioned vehicle mesh.
 * @returns {{ root: THREE.Group, wheels: object, brakeLights: object, groundClearance: number }}
 */
export function createVehicleMesh(vehicle) {
  const builder = BUILDERS[vehicle.category];
  if (!builder) {
    console.warn(`[VehicleFactory] no builder for category "${vehicle.category}", using sedan fallback`);
    return BUILDERS.sedan(vehicle);
  }
  const built = builder(vehicle);
  built.root.traverse((obj) => {
    if (obj.isMesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });
  return built;
}
