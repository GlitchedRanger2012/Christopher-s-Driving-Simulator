// client/js/vehicles/VehicleController.js
// Owns one vehicle's physics + mesh + (optionally) audio, and updates all
// three together each frame. Used for both the local player's car (full
// physics + input + audio) and remote multiplayer players (mesh only, driven
// by networked transforms — see MultiplayerSession.js).
//
// Wheel spin is derived from actual distance traveled since the last sync
// (arc length / wheel radius), not from speed*dt. That was a deliberate fix:
// an earlier version drove spin off physics telemetry, which stays at zero
// for remote players since their VehiclePhysics never has update() called on
// it (only position is set directly from the network) — their wheels would
// never visibly turn. Distance-based spin works identically for both paths.

import { createVehicleMesh } from './VehicleFactory.js';
import { VehiclePhysics } from './VehiclePhysics.js';

export class VehicleController {
  constructor(vehicle, spawn, { audio = null } = {}) {
    this.vehicle = vehicle;
    this.physics = new VehiclePhysics(vehicle, spawn);
    const built = createVehicleMesh(vehicle);
    this.mesh = built.root;
    this.wheels = built.wheels;
    this.brakeLights = built.brakeLights;
    this.groundClearance = built.groundClearance;
    this.wheelRadius = built.wheelRadius;
    this.audio = audio;

    this._wheelSpin = 0;
    this._wasSliding = false;
    this._lastSyncX = this.physics.position.x;
    this._lastSyncZ = this.physics.position.z;

    this.mesh.position.copy(this.physics.position);
  }

  attachTo(scene) {
    scene.add(this.mesh);
  }

  detach(scene) {
    scene.remove(this.mesh);
  }

  startAudio() {
    if (this.audio) this.audio.startEngine();
  }

  stopAudio() {
    if (this.audio) {
      this.audio.stopEngine();
      this.audio.stopSkid();
    }
  }

  /** Local-player path: reads live input, steps physics, updates mesh + audio. */
  update(dt, input, world) {
    const events = this.physics.update(dt, input, world);
    this._syncMesh();
    this._syncAudio(input, events);
    return events;
  }

  /** Remote-player path: no local physics stepping, just apply a networked transform. */
  applyNetworkTransform(x, y, z, rotationY) {
    this.physics.position.set(x, y, z);
    this.physics.yaw = rotationY;
    this._syncMesh();
  }

  _syncMesh() {
    const t = this.physics.getTransform();
    this.mesh.position.set(t.position.x, t.position.y + this.groundClearance, t.position.z);
    this.mesh.rotation.set(t.tiltZ, -t.yaw, t.tiltX);

    const dx = t.position.x - this._lastSyncX;
    const dz = t.position.z - this._lastSyncZ;
    const distance = Math.sqrt(dx * dx + dz * dz);
    // Sign the spin using the vehicle's own forward speed when we have real
    // physics (local player); remote cars just spin forward — good enough
    // for a cosmetic detail on a car you're not driving.
    const direction = this.physics.forwardSpeed < -0.05 ? -1 : 1;
    this._wheelSpin += (distance / Math.max(this.wheelRadius, 0.05)) * direction;
    this._lastSyncX = t.position.x;
    this._lastSyncZ = t.position.z;

    for (const key of ['wheelFL', 'wheelFR', 'wheelRL', 'wheelRR']) {
      const wheel = this.wheels[key];
      if (!wheel) continue;
      wheel.rotation.x = this._wheelSpin;
      if (key === 'wheelFL' || key === 'wheelFR') {
        wheel.rotation.y = this.physics.steerAngle;
      }
    }
  }

  _syncAudio(input, events) {
    if (!this.audio) return;
    const telemetry = this.physics.getTelemetry();
    this.audio.updateEngine(telemetry.rpm, input.throttle);

    const sliding = telemetry.drifting || input.brake > 0.4;
    if (sliding && !this._wasSliding) this.audio.startSkid();
    if (sliding) this.audio.setSkidIntensity(telemetry.drifting ? 0.4 : 0.15);
    if (!sliding && this._wasSliding) this.audio.stopSkid();
    this._wasSliding = sliding;

    if (events.collided && events.collisionSpeed > 2) {
      this.audio.playCollisionThud(Math.min(1, events.collisionSpeed / 20));
    }

    for (const key of ['brakeLightL', 'brakeLightR']) {
      const light = this.brakeLights[key];
      if (light) light.material.emissiveIntensity = input.brake > 0.05 ? 1.4 : 0;
    }
  }
}
