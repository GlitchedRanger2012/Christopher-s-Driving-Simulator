// client/js/core/InputManager.js
//
// Polls keyboard state (via a held-key set, not per-keypress events, so
// holding W actually accelerates continuously) and the Gamepad API, and
// exposes one normalized reading both the driving code and the UI can use.
// Rebinding just changes which KeyboardEvent.code values map to which action.

import { SaveManager } from './SaveManager.js';

export class InputManager {
  constructor() {
    this.bindings = SaveManager.loadKeybindings();
    this.heldCodes = new Set();
    this.gamepadIndex = null;
    this.listening = false;

    this._onKeyDown = this._onKeyDown.bind(this);
    this._onKeyUp = this._onKeyUp.bind(this);
    this._onGamepadConnected = this._onGamepadConnected.bind(this);
    this._onGamepadDisconnected = this._onGamepadDisconnected.bind(this);

    // If true, the next key pressed is captured for rebinding instead of
    // being treated as gameplay input. Set by SettingsMenu.
    this.rebindTarget = null;
    this.onRebindCaptured = null;
  }

  start() {
    if (this.listening) return;
    this.listening = true;
    window.addEventListener('keydown', this._onKeyDown);
    window.addEventListener('keyup', this._onKeyUp);
    window.addEventListener('gamepadconnected', this._onGamepadConnected);
    window.addEventListener('gamepaddisconnected', this._onGamepadDisconnected);
  }

  stop() {
    this.listening = false;
    window.removeEventListener('keydown', this._onKeyDown);
    window.removeEventListener('keyup', this._onKeyUp);
    window.removeEventListener('gamepadconnected', this._onGamepadConnected);
    window.removeEventListener('gamepaddisconnected', this._onGamepadDisconnected);
    this.heldCodes.clear();
  }

  beginRebind(action, callback) {
    this.rebindTarget = action;
    this.onRebindCaptured = callback;
  }

  setBinding(action, code) {
    this.bindings[action] = [code];
    SaveManager.saveKeybindings(this.bindings);
  }

  resetBindingsToDefault(defaults) {
    this.bindings = { ...defaults };
    SaveManager.saveKeybindings(this.bindings);
  }

  _onKeyDown(e) {
    if (this.rebindTarget) {
      e.preventDefault();
      this.setBinding(this.rebindTarget, e.code);
      const action = this.rebindTarget;
      const cb = this.onRebindCaptured;
      this.rebindTarget = null;
      this.onRebindCaptured = null;
      if (cb) cb(action, e.code);
      return;
    }
    this.heldCodes.add(e.code);
  }

  _onKeyUp(e) {
    this.heldCodes.delete(e.code);
  }

  _onGamepadConnected(e) {
    this.gamepadIndex = e.gamepad.index;
    console.log(`[InputManager] gamepad connected: ${e.gamepad.id}`);
  }

  _onGamepadDisconnected(e) {
    if (this.gamepadIndex === e.gamepad.index) this.gamepadIndex = null;
  }

  _isActionHeld(action) {
    const codes = this.bindings[action] || [];
    return codes.some((c) => this.heldCodes.has(c));
  }

  _readGamepad() {
    if (this.gamepadIndex === null) return null;
    const pads = navigator.getGamepads ? navigator.getGamepads() : [];
    const pad = pads[this.gamepadIndex];
    if (!pad || !pad.connected) return null;

    // Standard mapping: right trigger (7) = accelerate, left trigger (6) =
    // brake, left stick X (axis 0) = steering, button 0 (A/Cross) = handbrake,
    // button 1 (B/Circle) = reset, button 9 (Start) = pause.
    const throttle = clamp01(pad.buttons[7]?.value ?? 0);
    const brake = clamp01(pad.buttons[6]?.value ?? 0);
    const steer = clampSigned(pad.axes[0] ?? 0);
    return {
      throttle,
      brake,
      steer,
      handbrake: !!pad.buttons[0]?.pressed,
      resetPressed: !!pad.buttons[1]?.pressed,
      pausePressed: !!pad.buttons[9]?.pressed,
    };
  }

  /**
   * Returns a normalized input frame: throttle/brake in 0..1, steer in -1..1,
   * plus booleans for one-shot-feeling actions. Keyboard and gamepad are
   * merged (whichever is providing input wins for that axis).
   */
  read() {
    const gp = this._readGamepad();

    let throttle = this._isActionHeld('accelerate') ? 1 : 0;
    let brake = this._isActionHeld('brake') ? 1 : 0;
    let steer = 0;
    if (this._isActionHeld('steerLeft')) steer -= 1;
    if (this._isActionHeld('steerRight')) steer += 1;

    if (gp) {
      throttle = Math.max(throttle, gp.throttle);
      brake = Math.max(brake, gp.brake);
      if (Math.abs(gp.steer) > 0.08) steer = gp.steer; // deadzone
    }

    return {
      throttle,
      brake,
      steer,
      handbrake: this._isActionHeld('handbrake') || !!gp?.handbrake,
      resetPressed: this._isActionHeld('reset') || !!gp?.resetPressed,
      pausePressed: this._isActionHeld('pause') || !!gp?.pausePressed,
      cameraModePressed: this._isActionHeld('cameraMode'),
      usingGamepad: !!gp,
    };
  }

  bindingLabel(action) {
    const codes = this.bindings[action] || [];
    return codes.map(prettyCode).join(' / ') || '—';
  }
}

function clamp01(n) {
  return Math.min(1, Math.max(0, n));
}
function clampSigned(n) {
  return Math.min(1, Math.max(-1, n));
}

function prettyCode(code) {
  if (!code) return '—';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Arrow')) return code.slice(5) + ' Arrow';
  if (code === 'Space') return 'Space';
  if (code === 'Escape') return 'Esc';
  return code;
}
