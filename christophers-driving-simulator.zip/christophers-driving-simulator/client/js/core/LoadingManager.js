// client/js/core/LoadingManager.js
//
// Tracks a real list of boot steps (loading the renderer, generating the
// world, building vehicle meshes, ...) and reports genuine percent-complete
// based on how many have finished — not an animated fake bar. main.js
// registers the actual steps; this module just tracks and reports them.

export class LoadingManager {
  constructor(onUpdate) {
    this.steps = [];
    this.completed = 0;
    this.onUpdate = onUpdate || (() => {});
    this.failed = [];
  }

  /**
   * Runs an async or sync task, updating progress before and after. Errors
   * are caught and recorded rather than crashing the whole boot sequence —
   * an optional system (e.g. a gamepad polyfill) failing shouldn't prevent
   * the game from starting (requirement 24).
   */
  async step(label, taskFn, { optional = false } = {}) {
    this.steps.push(label);
    this._emit(label, 'running');
    try {
      await taskFn();
      this.completed += 1;
      this._emit(label, 'done');
    } catch (err) {
      console.error(`[LoadingManager] step "${label}" failed:`, err);
      this.failed.push({ label, error: err, optional });
      if (!optional) throw err;
      this.completed += 1; // still counts toward progress so the bar doesn't stall
      this._emit(label, 'failed-optional');
    }
  }

  _emit(currentLabel, status) {
    const total = Math.max(this.steps.length, 1);
    this.onUpdate({
      currentLabel,
      status,
      completed: this.completed,
      total,
      percent: Math.round((this.completed / total) * 100),
      failed: this.failed,
    });
  }
}
