// client/js/core/SaveManager.js
//
// The only module that touches localStorage directly. Everything here is
// wrapped in try/catch: private browsing, storage quotas, and browsers with
// storage disabled can all make localStorage throw, and none of those should
// crash the game (see requirement 24, "error handling").

import { TERMS_VERSION } from '../../../shared/constants.js';

const KEYS = {
  TERMS_ACCEPTED_VERSION: 'cds.termsVersionAccepted',
  SETTINGS: 'cds.settings',
  KEYBINDINGS: 'cds.keybindings',
  PLAYER_NAME: 'cds.playerName',
  LAST_VEHICLE: 'cds.lastVehicleId',
};

export const DEFAULT_SETTINGS = {
  graphics: {
    quality: 'medium', // low | medium | high
    shadows: true,
    antialiasing: true,
    viewDistance: 500, // meters
    pixelRatioCap: 2,
  },
  audio: {
    master: 0.8,
    music: 0.5,
    effects: 0.9,
  },
  gameplay: {
    cameraSensitivity: 1.0,
    cameraDistance: 1.0, // multiplier
    drivingAssist: true, // mild traction assist for new players
    reducedMotion: false,
  },
};

export const DEFAULT_KEYBINDINGS = {
  accelerate: ['KeyW', 'ArrowUp'],
  brake: ['KeyS', 'ArrowDown'],
  steerLeft: ['KeyA', 'ArrowLeft'],
  steerRight: ['KeyD', 'ArrowRight'],
  handbrake: ['Space'],
  reset: ['KeyR'],
  pause: ['Escape'],
  cameraMode: ['KeyC'],
};

function safeGet(key) {
  try {
    return window.localStorage.getItem(key);
  } catch (err) {
    console.warn(`[SaveManager] could not read "${key}":`, err);
    return null;
  }
}

function safeSet(key, value) {
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch (err) {
    console.warn(`[SaveManager] could not write "${key}":`, err);
    return false;
  }
}

function deepMerge(base, override) {
  const out = { ...base };
  for (const k of Object.keys(override || {})) {
    if (override[k] && typeof override[k] === 'object' && !Array.isArray(override[k])) {
      out[k] = deepMerge(base[k] || {}, override[k]);
    } else {
      out[k] = override[k];
    }
  }
  return out;
}

export const SaveManager = {
  hasAcceptedCurrentTerms() {
    return safeGet(KEYS.TERMS_ACCEPTED_VERSION) === TERMS_VERSION;
  },

  acceptCurrentTerms() {
    safeSet(KEYS.TERMS_ACCEPTED_VERSION, TERMS_VERSION);
    safeSet('cds.termsAcceptedAt', new Date().toISOString());
  },

  loadSettings() {
    const raw = safeGet(KEYS.SETTINGS);
    if (!raw) return structuredCloneSafe(DEFAULT_SETTINGS);
    try {
      return deepMerge(DEFAULT_SETTINGS, JSON.parse(raw));
    } catch (err) {
      console.warn('[SaveManager] corrupt settings, resetting to defaults:', err);
      return structuredCloneSafe(DEFAULT_SETTINGS);
    }
  },

  saveSettings(settings) {
    safeSet(KEYS.SETTINGS, JSON.stringify(settings));
  },

  loadKeybindings() {
    const raw = safeGet(KEYS.KEYBINDINGS);
    if (!raw) return structuredCloneSafe(DEFAULT_KEYBINDINGS);
    try {
      return { ...DEFAULT_KEYBINDINGS, ...JSON.parse(raw) };
    } catch (err) {
      console.warn('[SaveManager] corrupt keybindings, resetting to defaults:', err);
      return structuredCloneSafe(DEFAULT_KEYBINDINGS);
    }
  },

  saveKeybindings(bindings) {
    safeSet(KEYS.KEYBINDINGS, JSON.stringify(bindings));
  },

  loadPlayerName() {
    return safeGet(KEYS.PLAYER_NAME) || '';
  },

  savePlayerName(name) {
    safeSet(KEYS.PLAYER_NAME, name);
  },

  loadLastVehicleId() {
    return safeGet(KEYS.LAST_VEHICLE);
  },

  saveLastVehicleId(id) {
    safeSet(KEYS.LAST_VEHICLE, id);
  },
};

function structuredCloneSafe(obj) {
  return typeof structuredClone === 'function' ? structuredClone(obj) : JSON.parse(JSON.stringify(obj));
}
