// client/js/core/AudioManager.js
//
// Requirement 17 says: if audio assets aren't available, build a real audio
// architecture rather than pretending files exist. Rather than ship silent
// stub functions, this synthesizes every sound with the WebAudio API —
// engine drone, skid noise, collision thud, UI clicks are all generated at
// runtime. That means zero licensing risk and zero "missing asset" failure
// mode, at the cost of not sounding like a real engine recording. See
// THIRD_PARTY_LICENSES.md and README.md "Known limitations".

export class AudioManager {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.musicGain = null;
    this.fxGain = null;
    this.engine = null; // { osc, gain, filter }
    this.settings = { master: 0.8, music: 0.5, effects: 0.9 };
    this.enabled = false;
  }

  /** Must be called from a user gesture (click) — browsers block autoplay otherwise. */
  unlock() {
    if (this.ctx) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) {
      console.warn('[AudioManager] WebAudio not supported in this browser; running muted.');
      return;
    }
    this.ctx = new Ctx();
    this.master = this.ctx.createGain();
    this.musicGain = this.ctx.createGain();
    this.fxGain = this.ctx.createGain();
    this.musicGain.connect(this.master);
    this.fxGain.connect(this.master);
    this.master.connect(this.ctx.destination);
    this.enabled = true;
    this.applySettings(this.settings);
  }

  applySettings(settings) {
    this.settings = settings;
    if (!this.ctx) return;
    this.master.gain.setTargetAtTime(settings.master, this.ctx.currentTime, 0.05);
    this.musicGain.gain.setTargetAtTime(settings.music, this.ctx.currentTime, 0.05);
    this.fxGain.gain.setTargetAtTime(settings.effects, this.ctx.currentTime, 0.05);
  }

  _noiseBuffer(seconds = 1) {
    const ctx = this.ctx;
    const buffer = ctx.createBuffer(1, ctx.sampleRate * seconds, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    return buffer;
  }

  playUiClick() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(880, t);
    osc.frequency.exponentialRampToValueAtTime(440, t + 0.06);
    gain.gain.setValueAtTime(0.15, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.08);
    osc.connect(gain).connect(this.fxGain);
    osc.start(t);
    osc.stop(t + 0.09);
  }

  playCollisionThud(intensity = 1) {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(0.25);
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 300 + intensity * 200;
    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(Math.min(1, 0.4 * intensity), t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);
    src.connect(filter).connect(gain).connect(this.fxGain);
    src.start(t);
  }

  startSkid() {
    if (!this.ctx || this.skid) return;
    const ctx = this.ctx;
    const src = ctx.createBufferSource();
    src.buffer = this._noiseBuffer(2);
    src.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1400;
    filter.Q.value = 0.7;
    const gain = ctx.createGain();
    gain.gain.value = 0;
    src.connect(filter).connect(gain).connect(this.fxGain);
    src.start();
    this.skid = { src, gain };
  }

  setSkidIntensity(amount) {
    if (!this.skid) return;
    this.skid.gain.gain.setTargetAtTime(Math.max(0, Math.min(0.5, amount)), this.ctx.currentTime, 0.05);
  }

  stopSkid() {
    if (!this.skid) return;
    this.skid.gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    const skid = this.skid;
    this.skid = null;
    setTimeout(() => { try { skid.src.stop(); } catch { /* already stopped */ } }, 300);
  }

  startEngine() {
    if (!this.ctx || this.engine) return;
    const ctx = this.ctx;
    const osc = ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.value = 60;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 400;
    const gain = ctx.createGain();
    gain.gain.value = 0.0001;
    osc.connect(filter).connect(gain).connect(this.fxGain);
    osc.start();
    this.engine = { osc, filter, gain };
  }

  /** rpm: 800-7000ish. throttle: 0..1 (controls loudness + a little brightness). */
  updateEngine(rpm, throttle) {
    if (!this.engine) return;
    const t = this.ctx.currentTime;
    const freq = 40 + (rpm / 7000) * 160; // audible drone, not a literal RPM tone
    this.engine.osc.frequency.setTargetAtTime(freq, t, 0.05);
    this.engine.filter.frequency.setTargetAtTime(300 + throttle * 900, t, 0.08);
    const targetGain = 0.05 + throttle * 0.12;
    this.engine.gain.gain.setTargetAtTime(targetGain, t, 0.1);
  }

  stopEngine() {
    if (!this.engine) return;
    const { osc, gain } = this.engine;
    gain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
    this.engine = null;
    setTimeout(() => { try { osc.stop(); } catch { /* already stopped */ } }, 300);
  }
}
