// client/js/core/Engine.js
//
// Owns the THREE.Scene, WebGLRenderer, and the requestAnimationFrame loop.
// Deliberately doesn't own a camera — ChaseCamera instances are swapped in
// by whatever session (singleplayer/multiplayer) is currently running, via
// setActiveCamera(). Detects missing WebGL support up front rather than
// letting three.js throw partway through scene construction (requirement 24).

import * as THREE from '../vendor/three.js';

export function isWebGLAvailable() {
  try {
    const canvas = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (canvas.getContext('webgl2') || canvas.getContext('webgl')));
  } catch {
    return false;
  }
}

export class Engine {
  constructor(container, settings) {
    this.container = container;
    this.scene = new THREE.Scene();
    this.activeCamera = null;
    this._running = false;
    this._callbacks = [];
    this._clock = { last: performance.now() };

    this.renderer = new THREE.WebGLRenderer({
      antialias: settings.graphics.antialiasing,
      powerPreference: 'high-performance',
    });
    this.applyGraphicsSettings(settings.graphics);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    container.appendChild(this.renderer.domElement);

    this._onResize = this._onResize.bind(this);
    window.addEventListener('resize', this._onResize);
    this._onResize();
  }

  applyGraphicsSettings(graphics) {
    const pixelRatio = Math.min(window.devicePixelRatio || 1, graphics.pixelRatioCap ?? 2);
    this.renderer.setPixelRatio(graphics.quality === 'low' ? Math.min(1, pixelRatio) : pixelRatio);
    this.renderer.shadowMap.enabled = !!graphics.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  }

  setActiveCamera(camera) {
    this.activeCamera = camera;
    this._onResize();
  }

  onFrame(callback) {
    this._callbacks.push(callback);
    return () => {
      this._callbacks = this._callbacks.filter((cb) => cb !== callback);
    };
  }

  start() {
    if (this._running) return;
    this._running = true;
    this._clock.last = performance.now();
    requestAnimationFrame(this._tick.bind(this));
  }

  stop() {
    this._running = false;
  }

  _tick(now) {
    if (!this._running) return;
    const dt = Math.min((now - this._clock.last) / 1000, 0.1); // clamp so a dropped/background tab doesn't jump physics
    this._clock.last = now;

    for (const cb of this._callbacks) cb(dt);

    if (this.activeCamera) {
      this.renderer.render(this.scene, this.activeCamera);
    }
    requestAnimationFrame(this._tick.bind(this));
  }

  _onResize() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height);
    if (this.activeCamera) {
      this.activeCamera.aspect = width / height;
      this.activeCamera.updateProjectionMatrix();
    }
  }

  dispose() {
    this.stop();
    window.removeEventListener('resize', this._onResize);
    this.renderer.dispose();
    if (this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
  }
}
