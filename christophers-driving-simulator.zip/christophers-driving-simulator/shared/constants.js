// shared/constants.js
// Values that both the browser client and the multiplayer server must agree on.
// Changing WORLD_HALF_EXTENT, TERMS_VERSION, or the network rates here affects
// both sides at once, which is the point: it's the single source of truth.

export const GAME_TITLE = "Christopher's Driving Simulator";

// Bump this whenever TERMS_OF_SERVICE.md changes in a way players must re-accept.
export const TERMS_VERSION = '1.0.0';

// World layout (meters). The drivable area is a square centered on the origin.
export const WORLD_HALF_EXTENT = 1000;
export const WORLD_SEED = 1337; // deterministic — same seed always builds the same city
export const BLOCK_SIZE = 90;
export const ROAD_WIDTH = 12;

export const GRAVITY = 9.81; // m/s^2

// Networking
export const NETWORK_SEND_RATE_HZ = 15; // client -> server position updates per second
export const SERVER_MAX_INBOUND_HZ = 30; // hard cap the server accepts per socket
export const MAX_PLAYERS_PER_SESSION = 24;
export const INTERPOLATION_DELAY_MS = 100; // remote player smoothing window

export const SPAWN_POINTS = [
  { x: 0, z: 20, heading: 0 },
  { x: 40, z: 20, heading: 0 },
  { x: -40, z: 20, heading: 0 },
  { x: 0, z: -20, heading: Math.PI },
  { x: 40, z: -20, heading: Math.PI },
  { x: -40, z: -20, heading: Math.PI },
  { x: 80, z: 0, heading: Math.PI / 2 },
  { x: -80, z: 0, heading: -Math.PI / 2 },
];

export const QUICK_CHAT_MESSAGES = [
  'GG!',
  'Nice one!',
  'Watch out!',
  'Follow me',
  'Need a sec',
  'Sorry!',
];
