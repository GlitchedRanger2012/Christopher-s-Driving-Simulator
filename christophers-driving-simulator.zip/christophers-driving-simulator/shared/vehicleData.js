// shared/vehicleData.js
//
// Data-driven vehicle catalog for Christopher's Driving Simulator.
// Every one of the 45 cars is a distinct, original, fictional vehicle (no real
// manufacturer names, logos, or trims) with real, meaningfully different stats
// that the physics engine (client/js/vehicles/VehiclePhysics.js) actually reads.
//
// How the numbers are generated:
// Each category (compact, sedan, sports, ...) has a CATEGORY_RANGE: a "base
// trim" value and a "top trim" value for every stat. Each car picks a `tier`
// from 0 (base trim) to 1 (top trim) within its category and a `sizeFactor`
// that scales its footprint. This is a deterministic, hand-authored curve —
// not a random number generator — so every value below is reviewable and
// reproducible. A handful of cars also get an explicit drivetrain override
// where that tells a better story (an AWD halo supercar, a 2WD work truck).

const CATEGORIES = [
  'compact', 'sedan', 'sports', 'supercar', 'muscle', 'suv', 'truck', 'offroad',
];

// [tier0 ("base trim"), tier1 ("top trim")] for every stat, per category.
const CATEGORY_RANGE = {
  compact: {
    mass: [1220, 1040], acceleration: [11.5, 9.0], topSpeed: [165, 195],
    braking: [42, 37], handling: [58, 76], grip: [52, 66], steering: [64, 82],
    dims: [3.9, 1.72, 1.5], drivetrain: 'FWD',
  },
  sedan: {
    mass: [1580, 1380], acceleration: [9.2, 7.2], topSpeed: [200, 225],
    braking: [40, 35], handling: [56, 72], grip: [58, 70], steering: [58, 72],
    dims: [4.75, 1.82, 1.45], drivetrain: 'FWD',
  },
  sports: {
    mass: [1420, 1240], acceleration: [5.6, 4.3], topSpeed: [245, 275],
    braking: [36, 31], handling: [78, 90], grip: [74, 85], steering: [80, 92],
    dims: [4.35, 1.86, 1.24], drivetrain: 'RWD',
  },
  supercar: {
    mass: [1480, 1290], acceleration: [3.6, 2.7], topSpeed: [315, 355],
    braking: [32, 27], handling: [88, 98], grip: [86, 97], steering: [88, 98],
    dims: [4.55, 2.02, 1.14], drivetrain: 'RWD',
  },
  muscle: {
    mass: [1820, 1640], acceleration: [5.8, 4.6], topSpeed: [245, 272],
    braking: [41, 36], handling: [56, 70], grip: [62, 74], steering: [56, 70],
    dims: [4.95, 1.92, 1.38], drivetrain: 'RWD',
  },
  suv: {
    mass: [2300, 2000], acceleration: [9.4, 7.3], topSpeed: [185, 212],
    braking: [46, 39], handling: [46, 60], grip: [54, 66], steering: [46, 60],
    dims: [4.85, 1.96, 1.78], drivetrain: 'AWD',
  },
  truck: {
    mass: [2650, 2280], acceleration: [10.8, 8.3], topSpeed: [155, 182],
    braking: [50, 43], handling: [38, 52], grip: [48, 60], steering: [42, 54],
    dims: [5.65, 2.02, 1.92], drivetrain: 'RWD',
  },
  offroad: {
    mass: [2150, 1880], acceleration: [10.2, 7.8], topSpeed: [145, 172],
    braking: [48, 41], handling: [50, 64], grip: [64, 78], steering: [50, 64],
    dims: [4.45, 1.92, 1.98], drivetrain: 'AWD',
  },
};

function lerp(a, b, t) {
  return a + (b - a) * t;
}

function round(n, places = 0) {
  const f = 10 ** places;
  return Math.round(n * f) / f;
}

/**
 * Build one full vehicle record from a category curve + this car's own tuning.
 * @param {string} id unique kebab-case id
 * @param {string} name original fictional display name
 * @param {string} category one of CATEGORIES
 * @param {number} tier 0..1 position within the category's stat curve
 * @param {number} sizeFactor scales the category's base footprint (~0.9-1.1)
 * @param {string} color primary body color (hex)
 * @param {string} accentColor secondary trim/glass color (hex)
 * @param {object} [overrides] explicit field overrides (e.g. drivetrain)
 */
function mk(id, name, category, tier, sizeFactor, color, accentColor, overrides = {}) {
  const r = CATEGORY_RANGE[category];
  if (!r) throw new Error(`Unknown category "${category}" for vehicle "${id}"`);
  const [l, w, h] = r.dims;
  return {
    id,
    name,
    category,
    drivetrain: r.drivetrain,
    mass: round(lerp(r.mass[0], r.mass[1], tier)),
    acceleration: round(lerp(r.acceleration[0], r.acceleration[1], tier), 1),
    topSpeed: round(lerp(r.topSpeed[0], r.topSpeed[1], tier)),
    braking: round(lerp(r.braking[0], r.braking[1], tier), 1),
    handling: round(lerp(r.handling[0], r.handling[1], tier)),
    grip: round(lerp(r.grip[0], r.grip[1], tier)),
    steering: round(lerp(r.steering[0], r.steering[1], tier)),
    dimensions: {
      length: round(l * sizeFactor, 2),
      width: round(w * sizeFactor, 2),
      height: round(h * sizeFactor, 2),
    },
    color,
    accentColor,
    ...overrides,
  };
}

export const VEHICLES = [
  // ---- Compact (6) ----
  mk('voss-comet', 'Voss Comet', 'compact', 0.2, 0.95, '#E4E7EA', '#2C3038'),
  mk('kestrel-micro', 'Kestrel Micro', 'compact', 0.4, 0.90, '#FFD23F', '#14161A'),
  mk('halcyon-dart', 'Halcyon Dart', 'compact', 0.6, 1.00, '#3DA5FF', '#FFFFFF'),
  mk('fenwick-pip', 'Fenwick Pip', 'compact', 0.1, 0.92, '#7CD992', '#1B1E24'),
  mk('ashgrove-breeze', 'Ashgrove Breeze', 'compact', 0.5, 1.02, '#FF7A3D', '#14161A'),
  mk('corvidae-nimbus', 'Corvidae Nimbus', 'compact', 0.8, 0.97, '#C9C9D1', '#FF4B4B'),

  // ---- Sedan (6) ----
  mk('marrow-meridian', 'Marrow Meridian', 'sedan', 0.3, 1.00, '#1E2128', '#C9C9D1'),
  mk('drayton-halden', 'Drayton Halden', 'sedan', 0.5, 1.03, '#6E7480', '#EDEFF3'),
  mk('northgate-ledger', 'Northgate Ledger', 'sedan', 0.2, 0.98, '#FFFFFF', '#1E2128'),
  mk('baskerton-aster', 'Baskerton Aster', 'sedan', 0.7, 1.05, '#7A1F2B', '#14161A', { drivetrain: 'AWD' }),
  mk('solace-parish', 'Solace Parish', 'sedan', 0.4, 1.00, '#294D6B', '#C9C9D1'),
  mk('quillon-ferro', 'Quillon Ferro', 'sedan', 0.9, 1.02, '#14161A', '#4FD1E8', { drivetrain: 'AWD' }),

  // ---- Sports (6) ----
  mk('ironvale-apex', 'Ironvale Apex', 'sports', 0.6, 1.00, '#FF4B4B', '#14161A'),
  mk('corvidae-talon', 'Corvidae Talon', 'sports', 0.8, 0.97, '#14161A', '#FF7A3D'),
  mk('halcyon-nightshade', 'Halcyon Nightshade', 'sports', 0.9, 0.95, '#2B1030', '#4FD1E8'),
  mk('voss-sprintline', 'Voss Sprintline', 'sports', 0.4, 1.02, '#FFFFFF', '#FF4B4B'),
  mk('kestrel-veloce', 'Kestrel Veloce', 'sports', 0.5, 1.00, '#FFD23F', '#14161A'),
  mk('fenwick-zephyr', 'Fenwick Zephyr', 'sports', 0.7, 0.98, '#4FD1E8', '#14161A'),

  // ---- Supercar (5) ----
  mk('drayton-prometheus', 'Drayton Prometheus', 'supercar', 0.8, 1.00, '#FF7A3D', '#14161A'),
  mk('northgate-solstice', 'Northgate Solstice', 'supercar', 0.95, 0.96, '#FFFFFF', '#FF4B4B', { drivetrain: 'AWD' }),
  mk('baskerton-infinion', 'Baskerton Infinion', 'supercar', 0.6, 1.00, '#14161A', '#4FD1E8'),
  mk('quillon-obsidian', 'Quillon Obsidian', 'supercar', 1.0, 0.94, '#0C0D10', '#FF4B4B'),
  mk('marrow-nebulon', 'Marrow Nebulon', 'supercar', 0.7, 1.02, '#3DA5FF', '#14161A', { drivetrain: 'AWD' }),

  // ---- Muscle (5) ----
  mk('ironvale-thunderclap', 'Ironvale Thunderclap', 'muscle', 0.6, 1.00, '#FF4B4B', '#14161A'),
  mk('corvidae-brawler', 'Corvidae Brawler', 'muscle', 0.4, 1.03, '#14161A', '#FFD23F'),
  mk('halcyon-ironclad', 'Halcyon Ironclad', 'muscle', 0.5, 1.00, '#6E7480', '#FF4B4B'),
  mk('voss-emberline', 'Voss Emberline', 'muscle', 0.8, 0.98, '#FF7A3D', '#14161A'),
  mk('kestrel-redline', 'Kestrel Redline', 'muscle', 0.9, 0.97, '#B0122B', '#EDEFF3'),

  // ---- SUV (6) ----
  mk('fenwick-highland', 'Fenwick Highland', 'suv', 0.3, 1.00, '#4A5568', '#EDEFF3'),
  mk('drayton-crestway', 'Drayton Crestway', 'suv', 0.5, 1.03, '#7A6A53', '#14161A'),
  mk('northgate-outpost', 'Northgate Outpost', 'suv', 0.2, 1.05, '#2F3B2F', '#C9C9D1'),
  mk('baskerton-trekker', 'Baskerton Trekker', 'suv', 0.6, 1.00, '#C9C9D1', '#1E2128'),
  mk('solace-summit', 'Solace Summit', 'suv', 0.7, 0.98, '#FFFFFF', '#4FD1E8'),
  mk('quillon-warden', 'Quillon Warden', 'suv', 0.4, 1.04, '#14161A', '#FF7A3D'),

  // ---- Truck (6) ----
  mk('marrow-haulmark', 'Marrow Haulmark', 'truck', 0.3, 1.00, '#7A1F2B', '#EDEFF3'),
  mk('ironvale-bedrock', 'Ironvale Bedrock', 'truck', 0.2, 1.05, '#4A5568', '#14161A', { drivetrain: 'RWD' }),
  mk('corvidae-ironhaul', 'Corvidae Ironhaul', 'truck', 0.5, 1.00, '#14161A', '#FF7A3D'),
  mk('halcyon-longbed', 'Halcyon Longbed', 'truck', 0.1, 1.08, '#FFFFFF', '#6E7480'),
  mk('voss-cargoline', 'Voss Cargoline', 'truck', 0.6, 0.98, '#294D6B', '#C9C9D1'),
  mk('kestrel-overland', 'Kestrel Overland', 'truck', 0.7, 1.02, '#3E4A3E', '#FFD23F', { drivetrain: 'AWD' }),

  // ---- Off-road (5) ----
  mk('fenwick-trailforge', 'Fenwick Trailforge', 'offroad', 0.5, 1.00, '#3E4A3E', '#FF7A3D'),
  mk('drayton-rockcrawler', 'Drayton Rockcrawler', 'offroad', 0.7, 1.03, '#7A1F2B', '#14161A'),
  mk('northgate-duneraider', 'Northgate Duneraider', 'offroad', 0.6, 0.98, '#C97A3D', '#14161A'),
  mk('baskerton-boulder', 'Baskerton Boulder', 'offroad', 0.4, 1.05, '#4A5568', '#FFD23F'),
  mk('solace-thornback', 'Solace Thornback', 'offroad', 0.8, 1.00, '#14161A', '#4FD1E8'),
];

export const VEHICLES_BY_ID = new Map(VEHICLES.map((v) => [v.id, v]));

export function getVehicle(id) {
  return VEHICLES_BY_ID.get(id) || null;
}

export function isValidVehicleId(id) {
  return typeof id === 'string' && VEHICLES_BY_ID.has(id);
}

export const CATEGORY_LIST = CATEGORIES;
export const DEFAULT_VEHICLE_ID = 'voss-sprintline';
