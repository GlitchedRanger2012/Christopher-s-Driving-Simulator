// shared/termsContent.js
//
// The Terms of Service, written once as structured data. Two things render
// it: client/js/ui/TermsScreen.js (the in-game scrollable acceptance
// screen) and scripts/generate-terms-md.mjs (which writes
// TERMS_OF_SERVICE.md from this same data). Editing the terms means editing
// this file and re-running `node scripts/generate-terms-md.mjs` — the two
// renderings can't drift apart because there's only one source of the text.
//
// This is a template drafted for a hobby project, not legal advice — see
// the note at the end of TERMS_OF_SERVICE.md.

import { TERMS_VERSION, GAME_TITLE } from './constants.js';

export const TERMS_EFFECTIVE_DATE = '2026-09-22';

export const TERMS_SECTIONS = [
  {
    heading: '1. Acceptance of these Terms',
    body: [
      `These Terms of Service ("Terms") govern your use of ${GAME_TITLE} (the "Game"). By clicking "Accept" you agree to these Terms. If you don't agree, click "Decline" and don't use the Game.`,
      `This is version ${TERMS_VERSION}, effective ${TERMS_EFFECTIVE_DATE}. If a future version changes these Terms in a way that matters, you'll be asked to accept the new version before you can keep playing — your previous acceptance doesn't carry over automatically.`,
    ],
  },
  {
    heading: '2. What the Game is',
    body: [
      `${GAME_TITLE} is a browser-based 3D driving game with a singleplayer mode and an optional online multiplayer mode. It runs entirely in your browser; the multiplayer mode additionally connects to a server that relays player positions and a small set of preset "quick chat" messages between connected players.`,
    ],
  },
  {
    heading: '3. Accounts',
    body: [
      `The Game does not currently require an account, and no accounts exist as of this version. If account functionality is added in the future, this section will be updated and you'll be asked to re-accept these Terms.`,
    ],
  },
  {
    heading: '4. Acceptable use',
    body: [
      'When using the Game, especially in multiplayer, you agree not to:',
      { ul: [
        'Cheat, exploit bugs, or use unauthorized third-party software to gain an advantage or disrupt other players.',
        'Attempt to overload, flood, or otherwise disrupt the multiplayer server or other players\u2019 connections.',
        'Harass, threaten, or abuse other players, including through repeated or targeted misuse of the quick-chat system.',
        'Attempt to gain unauthorized access to the multiplayer server, other players\u2019 sessions, or any non-public part of the Game.',
        'Modify the client in a way intended to falsify data sent to the server (for example, reporting a position or vehicle the server did not authorize).',
      ] },
      'The server independently validates the movement and vehicle data it receives (see THIRD_PARTY_LICENSES.md and the project README for the technical detail) and may reject implausible updates or disconnect a client that repeatedly sends invalid data. This is a reasonable, good-faith anti-abuse measure, not a guarantee that cheating is impossible.',
    ],
  },
  {
    heading: '5. User-generated content',
    body: [
      `The Game currently allows very limited user input into shared spaces: a driver name (shown to other players in multiplayer) and a fixed set of preset "quick chat" phrases. You're responsible for the driver name you choose; names that are abusive, impersonate others, or violate these Terms may be reset or blocked. If free-text chat or other user-generated content is added in the future, this section will be updated.`,
    ],
  },
  {
    heading: '6. Intellectual property and attribution',
    body: [
      `Except for the third-party software and assets identified in THIRD_PARTY_LICENSES.md, the original code, game design, vehicle data, and other creative assets made for ${GAME_TITLE} are the work of Christopher Ranger ("the Creator").`,
      'The project\u2019s LICENSE file sets out the specific terms under which this original code and these original assets may be reused. In summary, and subject to the LICENSE file controlling in the event of any conflict:',
      { ul: [
        'Code — if you reuse original code from this project, you must give appropriate credit to Christopher Ranger, as described in LICENSE.',
        'Assets — if you reuse original assets created for this project by Christopher Ranger, you must give appropriate credit to Christopher Ranger, as described in LICENSE.',
        'Derivative projects — if you build a project substantially based on this project\u2019s original code or assets, that project must include appropriate attribution to Christopher Ranger, as described in LICENSE.',
      ] },
      'None of this applies to third-party code, libraries, fonts, or other assets used by the Game — those remain under their own owners\u2019 copyright and their own licenses, listed in THIRD_PARTY_LICENSES.md. The Creator does not claim ownership of any third-party material, and nothing in these Terms should be read as such a claim.',
    ],
  },
  {
    heading: '7. Third-party software and assets',
    body: [
      'The Game uses third-party open-source libraries (for example a 3D rendering library and a multiplayer networking library) and may use third-party fonts. These are listed, with their licenses, in THIRD_PARTY_LICENSES.md. Your use of those components is also subject to their own license terms.',
    ],
  },
  {
    heading: '8. Privacy',
    body: [
      'See PRIVACY.md for what limited information the Game processes (primarily: settings and your Terms acceptance stored in your browser\u2019s local storage, and, in multiplayer, your chosen driver name, vehicle selection, and in-game position relayed through the multiplayer server for the duration of your session).',
    ],
  },
  {
    heading: '9. Service availability',
    body: [
      'Singleplayer runs locally in your browser and doesn\u2019t depend on any server the Creator operates. The multiplayer server, where one is deployed, is provided on an "as available" basis, may be unavailable, rate-limited, or discontinued at any time, and is not guaranteed to be free of downtime, latency, or data loss.',
    ],
  },
  {
    heading: '10. Changes to these Terms',
    body: [
      'These Terms may be updated over time. When a change is significant enough to require it, the Terms version number will be incremented and you\u2019ll be asked to accept the updated Terms the next time you launch the Game before you can continue playing.',
    ],
  },
  {
    heading: '11. Termination and restriction of access',
    body: [
      'Where the Creator operates a shared multiplayer server, access to that server may be limited, rate-limited, or terminated for a given player or client at the Creator\u2019s discretion, including for violations of Section 4. This does not affect your ability to play the singleplayer mode of the Game, which runs entirely in your own browser.',
    ],
  },
  {
    heading: '12. Disclaimer of warranties',
    body: [
      `The Game is provided "as is" and "as available," without warranties of any kind, express or implied, to the fullest extent permitted by applicable law. The Creator does not warrant that the Game will be uninterrupted, error-free, or free of harmful components.`,
    ],
  },
  {
    heading: '13. Limitation of liability',
    body: [
      'To the fullest extent permitted by applicable law, the Creator is not liable for any indirect, incidental, special, or consequential damages arising from your use of, or inability to use, the Game.',
    ],
  },
  {
    heading: '14. Governing law',
    body: [
      '[Placeholder — the Creator should specify the jurisdiction and governing law that apply to these Terms before relying on this document for a public release.]',
    ],
  },
  {
    heading: '15. Contact',
    body: [
      'Questions about these Terms can be sent to: [email protected] (replace with a real contact address before deploying this project).',
    ],
  },
];
