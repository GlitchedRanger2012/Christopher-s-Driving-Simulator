// shared/validation.js
//
// Pure, dependency-free validation functions. The server treats these as the
// authority on what a client is allowed to claim; the client uses the same
// functions to sanity-check its own state before it ever hits the network.
// Being pure functions (no socket.io, no DOM) means they can be unit tested
// directly with plain Node — see server/test/validation.test.mjs.

import { isValidVehicleId } from './vehicleData.js';
import { WORLD_HALF_EXTENT, QUICK_CHAT_MESSAGES } from './constants.js';

export function isFiniteNumber(n) {
  return typeof n === 'number' && Number.isFinite(n);
}

export function isValidPlayerName(name) {
  return (
    typeof name === 'string' &&
    name.trim().length >= 1 &&
    name.trim().length <= 20 &&
    /^[a-zA-Z0-9 _'-]+$/.test(name.trim())
  );
}

export function sanitizePlayerName(name) {
  if (!isValidPlayerName(name)) return 'Driver';
  return name.trim().slice(0, 20);
}

export function isWithinWorldBounds(x, z, margin = 25) {
  const limit = WORLD_HALF_EXTENT + margin;
  return isFiniteNumber(x) && isFiniteNumber(z) && Math.abs(x) <= limit && Math.abs(z) <= limit;
}

/**
 * Validates a { x, y, z, rotationY } transform payload a client sent for its
 * own vehicle. Does NOT check speed plausibility — that requires knowing the
 * previous sample and is done server-side in GameServer, where the time
 * delta between samples is known.
 */
export function isValidTransform(t) {
  if (!t || typeof t !== 'object') return false;
  const { x, y, z, rotationY } = t;
  if (!isFiniteNumber(x) || !isFiniteNumber(y) || !isFiniteNumber(z) || !isFiniteNumber(rotationY)) {
    return false;
  }
  if (!isWithinWorldBounds(x, z)) return false;
  if (y < -50 || y > 200) return false; // generous vertical bound (jumps, ramps)
  return true;
}

/**
 * Given a previous accepted transform + timestamp and a new candidate, checks
 * whether the implied speed is physically plausible for the given vehicle's
 * top speed. This is the core anti-speedhack check: it never trusts a
 * client-reported speed number, only the server's own math on positions it
 * received.
 */
export function isPlausibleMovement(prevTransform, prevTimeMs, nextTransform, nextTimeMs, vehicleTopSpeedKph) {
  let dt = (nextTimeMs - prevTimeMs) / 1000;
  if (dt < 0) return false; // out-of-order or duplicate packet
  // Floor tiny/zero gaps to a plausible minimum tick instead of dividing by
  // ~0. Two updates arriving in the same millisecond (server clock
  // resolution, or a burst on a fast connection) are normal; without this
  // floor, any nonzero movement in "zero" time looks like infinite speed and
  // gets rejected, which would punish legitimate fast connections.
  dt = Math.max(dt, 1 / 120);
  if (dt > 5) return true; // long gap (reconnect, tab throttling) — don't punish, just accept
  const dx = nextTransform.x - prevTransform.x;
  const dz = nextTransform.z - prevTransform.z;
  const distance = Math.sqrt(dx * dx + dz * dz);
  const impliedSpeedMs = distance / dt;
  const topSpeedMs = (vehicleTopSpeedKph / 3.6) * 1.25; // 25% slack for downhill/drift/lag jitter
  return impliedSpeedMs <= topSpeedMs;
}

export function isValidVehicleSelection(vehicleId) {
  return isValidVehicleId(vehicleId);
}

export function isValidQuickChatId(id) {
  return Number.isInteger(id) && id >= 0 && id < QUICK_CHAT_MESSAGES.length;
}
