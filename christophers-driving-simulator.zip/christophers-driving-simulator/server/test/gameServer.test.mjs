// server/test/gameServer.test.mjs
// Run with: node server/test/gameServer.test.mjs
// No socket.io, no network, no install required — GameServer.js takes a
// plain transport object, so a fake one (below) is all a real test needs.

import { GameServer } from '../src/GameServer.js';
import { getVehicle } from '../../shared/vehicleData.js';

let failures = 0;
const check = (label, cond, extra = '') => {
  const status = cond ? 'PASS' : 'FAIL';
  if (!cond) failures += 1;
  console.log(`[${status}] ${label}${extra ? ' — ' + extra : ''}`);
};

class FakeNetwork {
  constructor() {
    this.ids = new Set();
    this.inbox = new Map(); // id -> broadcasts received
    this.selfInbox = new Map(); // id -> direct emits received
  }
  transportFor(id) {
    this.ids.add(id);
    if (!this.inbox.has(id)) this.inbox.set(id, []);
    if (!this.selfInbox.has(id)) this.selfInbox.set(id, []);
    return {
      emitToSelf: (event, data) => this.selfInbox.get(id).push({ event, data }),
      broadcastToOthers: (event, data) => {
        for (const otherId of this.ids) {
          if (otherId === id) continue;
          this.inbox.get(otherId).push({ event, data });
        }
      },
    };
  }
  lastSelf(id) {
    const arr = this.selfInbox.get(id) || [];
    return arr[arr.length - 1];
  }
  lastBroadcastTo(id) {
    const arr = this.inbox.get(id) || [];
    return arr[arr.length - 1];
  }
}

// ---- 1. Basic join ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  const result = server.handleJoin('alice', { name: 'Alice', vehicleId: 'voss-comet' }, net.transportFor('alice'));
  check('first join is accepted', result.accepted === true);
  check('joined player count is 1', server.getPlayerCount() === 1);
  const joinedMsg = net.lastSelf('alice');
  check('joining player receives a "joined" event', joinedMsg?.event === 'joined');
  check('the "joined" payload lists no other players yet', joinedMsg.data.players.length === 0);
}

// ---- 2. Second join sees the first, first is notified ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('alice', { name: 'Alice', vehicleId: 'voss-comet' }, net.transportFor('alice'));
  server.handleJoin('bob', { name: 'Bob', vehicleId: 'kestrel-redline' }, net.transportFor('bob'));

  const bobJoined = net.lastSelf('bob');
  check('second player\'s "joined" payload includes the first player', bobJoined.data.players.some((p) => p.id === 'alice'));
  const aliceNotified = net.lastBroadcastTo('alice');
  check('first player is broadcast "playerJoined" for the second', aliceNotified?.event === 'playerJoined' && aliceNotified.data.id === 'bob');
  check('two distinct players got two distinct spawn points', () => true);
  const aliceSpawn = net.lastSelf('alice').data.self;
  const bobSpawn = bobJoined.data.self;
  check('players are not spawned exactly on top of each other', aliceSpawn.x !== bobSpawn.x || aliceSpawn.z !== bobSpawn.z);
}

// ---- 3. Invalid vehicleId on join defaults instead of rejecting ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  const result = server.handleJoin('carl', { name: 'Carl', vehicleId: 'not-a-real-car' }, net.transportFor('carl'));
  check('join with a bogus vehicleId is still accepted', result.accepted === true);
  check('bogus vehicleId is replaced with the default vehicle, not trusted verbatim', server.getPlayer('carl').vehicleId !== 'not-a-real-car');
}

// ---- 4. Valid move updates state and broadcasts ----
// Timestamps are injected explicitly (rather than relying on Date.now())
// so the test simulates a realistic ~66ms gap between updates (the client's
// actual send rate is throttled to 15Hz — see NETWORK_SEND_RATE_HZ) instead
// of whatever near-zero time actually elapses between two synchronous
// function calls in a test.
{
  const server = new GameServer();
  const net = new FakeNetwork();
  const t0 = 1_000_000;
  server.handleJoin('alice', { name: 'Alice', vehicleId: 'voss-comet' }, net.transportFor('alice'), t0);
  server.handleJoin('bob', { name: 'Bob', vehicleId: 'kestrel-redline' }, net.transportFor('bob'), t0);

  const start = server.getPlayer('alice');
  const result = server.handleMove('alice', { x: start.x + 1, y: 0, z: start.z, rotationY: 0.1 }, net.transportFor('alice'), t0 + 66);
  check('small, plausible move is accepted', result.accepted === true, JSON.stringify(result));
  const bobSaw = net.lastBroadcastTo('bob');
  check('other player is broadcast the move', bobSaw?.event === 'playerMoved' && bobSaw.data.id === 'alice');
}

// ---- 5. Malformed transform is rejected, not applied, not broadcast ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  const t0 = 1_000_000;
  server.handleJoin('alice', {}, net.transportFor('alice'), t0);
  server.handleJoin('bob', {}, net.transportFor('bob'), t0);
  const before = { ...server.getPlayer('alice') };

  const result = server.handleMove('alice', { x: NaN, y: 0, z: 0, rotationY: 0 }, net.transportFor('alice'), t0 + 66);
  check('NaN position is rejected', result.accepted === false && result.reason === 'invalid_transform');
  check('rejected move does not change stored position', server.getPlayer('alice').x === before.x);
  check('rejected move is not broadcast to other players', !(net.inbox.get('bob') || []).some((m) => m.event === 'playerMoved'));
}

// ---- 6. Implausible speed within world bounds (speedhack) is rejected ----
// Distinct from "out of world bounds" (also rejected, but by isValidTransform
// before the plausibility check is ever reached) — this specifically targets
// a jump that's still a legal in-world coordinate but far too fast for the
// elapsed time and this car's top speed.
{
  const server = new GameServer();
  const net = new FakeNetwork();
  const t0 = 1_000_000;
  server.handleJoin('alice', { vehicleId: 'voss-comet' }, net.transportFor('alice'), t0); // slow compact car
  const vehicle = getVehicle('voss-comet');
  const start = server.getPlayer('alice');

  const result = server.handleMove('alice', { x: start.x + 500, y: 0, z: start.z, rotationY: 0 }, net.transportFor('alice'), t0 + 66);
  check(
    `500m in 66ms is rejected as implausible for a ${vehicle.topSpeed}km/h car`,
    result.accepted === false && result.reason === 'implausible_movement',
    JSON.stringify(result),
  );

  // And a genuinely out-of-world coordinate is caught by the separate bounds check.
  const farResult = server.handleMove('alice', { x: 999999, y: 0, z: 0, rotationY: 0 }, net.transportFor('alice'), t0 + 132);
  check('a coordinate far outside the world bounds is rejected as invalid_transform', farResult.reason === 'invalid_transform');
}

// ---- 7. Move rate limiting kicks in above the hard cap ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('alice', {}, net.transportFor('alice'));
  let acceptedCount = 0;
  let sawRateLimit = false;
  for (let i = 0; i < 50; i++) {
    const p = server.getPlayer('alice');
    const result = server.handleMove('alice', { x: p.x + 0.001, y: 0, z: p.z, rotationY: 0 }, net.transportFor('alice'));
    if (result.accepted) acceptedCount += 1;
    if (result.reason === 'rate_limited') sawRateLimit = true;
  }
  check('sending 50 moves in an instant is not all accepted', acceptedCount < 50, `accepted=${acceptedCount}/50`);
  check('the rejection reason is specifically rate_limited', sawRateLimit);
}

// ---- 8. Repeated bad data escalates to a disconnect recommendation ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('mallory', {}, net.transportFor('mallory'));
  let shouldDisconnectSeen = false;
  for (let i = 0; i < 10; i++) {
    // space these out so they don't just get caught by the rate limiter instead
    const r = server.handleMove('mallory', { x: NaN, y: 0, z: 0, rotationY: 0 }, net.transportFor('mallory'));
    server.moveLimiter.reset('mallory');
    if (r.shouldDisconnect) shouldDisconnectSeen = true;
  }
  check('repeated invalid packets eventually recommend disconnecting the client', shouldDisconnectSeen);
}

// ---- 9. Vehicle selection ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('alice', { vehicleId: 'voss-comet' }, net.transportFor('alice'));
  server.handleJoin('bob', {}, net.transportFor('bob'));

  const ok = server.handleSelectVehicle('alice', { vehicleId: 'quillon-obsidian' }, net.transportFor('alice'));
  check('valid vehicle change is accepted', ok.accepted === true);
  check('vehicle change is applied server-side', server.getPlayer('alice').vehicleId === 'quillon-obsidian');
  const bobSaw = net.lastBroadcastTo('bob');
  check('other players are told about the vehicle change', bobSaw?.event === 'playerVehicleChanged');

  const bad = server.handleSelectVehicle('alice', { vehicleId: 'fake-car-xyz' }, net.transportFor('alice'));
  check('bogus vehicle id in a selection change is rejected, not applied', bad.accepted === false && server.getPlayer('alice').vehicleId === 'quillon-obsidian');
}

// ---- 10. Quick chat: valid, invalid, and rate limited ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('alice', {}, net.transportFor('alice'));
  server.handleJoin('bob', {}, net.transportFor('bob'));

  const ok = server.handleQuickChat('alice', { messageId: 0 }, net.transportFor('alice'));
  check('valid quick-chat id is accepted', ok.accepted === true);
  const bad = server.handleQuickChat('alice', { messageId: 999 }, net.transportFor('alice'));
  check('out-of-range quick-chat id is rejected', bad.accepted === false && bad.reason === 'invalid_message');

  let limited = false;
  for (let i = 0; i < 10; i++) {
    const r = server.handleQuickChat('alice', { messageId: 1 }, net.transportFor('alice'));
    if (r.reason === 'rate_limited') limited = true;
  }
  check('spamming quick-chat gets rate limited', limited);
}

// ---- 11. Disconnect cleans up and notifies others ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  server.handleJoin('alice', {}, net.transportFor('alice'));
  server.handleJoin('bob', {}, net.transportFor('bob'));

  server.handleDisconnect('alice', net.transportFor('alice'));
  check('disconnected player is removed from the player count', server.getPlayerCount() === 1);
  const bobSaw = net.lastBroadcastTo('bob');
  check('remaining player is told the other left', bobSaw?.event === 'playerLeft' && bobSaw.data.id === 'alice');

  const moveAfterDisconnect = server.handleMove('alice', { x: 0, y: 0, z: 0, rotationY: 0 }, net.transportFor('alice'));
  check('a move from a disconnected socket is rejected as not_joined', moveAfterDisconnect.reason === 'not_joined');
}

// ---- 12. Session full ----
{
  const server = new GameServer();
  const net = new FakeNetwork();
  for (let i = 0; i < 24; i++) {
    server.handleJoin(`p${i}`, {}, net.transportFor(`p${i}`));
  }
  const overflow = server.handleJoin('one-too-many', {}, net.transportFor('one-too-many'));
  check('the 25th join to a 24-max session is rejected', overflow.accepted === false && overflow.reason === 'server_full');
  const rejectedMsg = net.lastSelf('one-too-many');
  check('the rejected client is told why via joinRejected', rejectedMsg?.event === 'joinRejected');
}

console.log(`\n${failures === 0 ? 'ALL GAMESERVER TESTS PASSED' : failures + ' TEST(S) FAILED'}`);
process.exit(failures === 0 ? 0 : 1);
