// server/test/rateLimiter.test.mjs
// Run with: node server/test/rateLimiter.test.mjs
import { RateLimiter } from '../src/RateLimiter.js';

let failures = 0;
const check = (label, cond, extra = '') => {
  const status = cond ? 'PASS' : 'FAIL';
  if (!cond) failures += 1;
  console.log(`[${status}] ${label}${extra ? ' — ' + extra : ''}`);
};

const rl = new RateLimiter({ maxEvents: 3, windowMs: 1000 });
check('1st event within limit is allowed', rl.tryConsume('a', 0) === true);
check('2nd event within limit is allowed', rl.tryConsume('a', 100) === true);
check('3rd event within limit is allowed', rl.tryConsume('a', 200) === true);
check('4th event within the same window is rejected', rl.tryConsume('a', 300) === false);
check('a different key is tracked independently', rl.tryConsume('b', 300) === true);
check('after the window fully elapses, the key is allowed again', rl.tryConsume('a', 1300) === true);

const rl2 = new RateLimiter({ maxEvents: 1, windowMs: 500 });
rl2.tryConsume('x', 0);
check('reset() clears a key immediately, before its window would naturally expire', (() => {
  rl2.reset('x');
  return rl2.tryConsume('x', 10) === true;
})());

console.log(`\n${failures === 0 ? 'ALL RATE LIMITER TESTS PASSED' : failures + ' TEST(S) FAILED'}`);
process.exit(failures === 0 ? 0 : 1);
