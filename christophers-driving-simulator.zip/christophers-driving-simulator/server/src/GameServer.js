// server/src/GameServer.js
//
// This class has NO socket.io import. It takes a plain "transport" object
// (emitToSelf / broadcastToOthers functions) instead of talking to sockets
// directly. That's a deliberate architecture choice, not just a style
// preference: it means the authoritative logic — the part requirement 14
// ("do not trust the client") actually depends on — can be unit tested with
// a fake transport and no real network, no socket.io installed, nothing
// (see server/test/gameServer.test.mjs, which is exactly what this
// environment's sandboxed, offline testing could actually run end to end).
// server/src/index.js is the thin real-socket.io wiring on top of this.

import { isValidTransform, isPlausibleMovement, isValidVehicleSelection, isValidQuickChatId, sanitizePlayerName } from '../../shared/validation.js';
import { DEFAULT_VEHICLE_ID, getVehicle } from '../../shared/vehicleData.js';
import { SPAWN_POINTS, MAX_PLAYERS_PER_SESSION } from '../../shared/constants.js';
import { RateLimiter } from './RateLimiter.js';

const MAX_STRIKES = 8;
const MOVE_RATE_LIMIT = { maxEvents: 30, windowMs: 1000 }; // hard ceiling — client sends ~15/s normally
const CHAT_RATE_LIMIT = { maxEvents: 5, windowMs: 10000 };

export class GameServer {
  constructor() {
    this.players = new Map(); // socketId -> player record
    this.moveLimiter = new RateLimiter(MOVE_RATE_LIMIT);
    this.chatLimiter = new RateLimiter(CHAT_RATE_LIMIT);
    this._spawnIndex = 0;
  }

  getPlayerCount() {
    return this.players.size;
  }

  getPlayer(socketId) {
    return this.players.get(socketId) || null;
  }

  _nextSpawn() {
    const spawn = SPAWN_POINTS[this._spawnIndex % SPAWN_POINTS.length];
    this._spawnIndex += 1;
    return spawn;
  }

  // `now` defaults to the real clock; tests pass explicit timestamps so they
  // can simulate realistic elapsed time between calls without sleeping.
  handleJoin(socketId, payload, transport, now = Date.now()) {
    if (this.players.has(socketId)) {
      return { accepted: false, reason: 'already_joined' };
    }
    if (this.players.size >= MAX_PLAYERS_PER_SESSION) {
      transport.emitToSelf('joinRejected', { reason: 'This session is full. Try again later.' });
      return { accepted: false, reason: 'server_full' };
    }
    if (!payload || typeof payload !== 'object') {
      transport.emitToSelf('joinRejected', { reason: 'Invalid join request.' });
      return { accepted: false, reason: 'invalid_payload' };
    }

    const name = sanitizePlayerName(payload.name);
    const vehicleId = isValidVehicleSelection(payload.vehicleId) ? payload.vehicleId : DEFAULT_VEHICLE_ID;
    const spawn = this._nextSpawn();

    const player = {
      id: socketId,
      name,
      vehicleId,
      x: spawn.x,
      y: 0,
      z: spawn.z,
      rotationY: spawn.heading,
      lastUpdateAt: now,
      lastMoveServerTime: now,
      strikes: 0,
    };
    this.players.set(socketId, player);

    const others = Array.from(this.players.values()).filter((p) => p.id !== socketId);
    transport.emitToSelf('joined', {
      self: { id: player.id, x: player.x, y: player.y, z: player.z, rotationY: player.rotationY },
      players: others.map(publicView),
    });
    transport.broadcastToOthers('playerJoined', publicView(player));

    return { accepted: true, player };
  }

  handleMove(socketId, payload, transport, now = Date.now()) {
    const player = this.players.get(socketId);
    if (!player) return { accepted: false, reason: 'not_joined' };

    if (!this.moveLimiter.tryConsume(socketId, now)) {
      return this._strike(player, 'rate_limited');
    }
    if (!isValidTransform(payload)) {
      return this._strike(player, 'invalid_transform');
    }

    const vehicle = getVehicle(player.vehicleId);
    const plausible = isPlausibleMovement(
      { x: player.x, z: player.z },
      player.lastMoveServerTime,
      { x: payload.x, z: payload.z },
      now,
      vehicle ? vehicle.topSpeed : 400,
    );

    if (!plausible) {
      return this._strike(player, 'implausible_movement');
    }

    player.x = payload.x;
    player.y = payload.y;
    player.z = payload.z;
    player.rotationY = payload.rotationY;
    player.lastUpdateAt = now;
    player.lastMoveServerTime = now;
    if (player.strikes > 0) player.strikes -= 1; // slow decay so transient lag can't accumulate into a kick

    transport.broadcastToOthers('playerMoved', { id: player.id, x: player.x, y: player.y, z: player.z, rotationY: player.rotationY });
    return { accepted: true };
  }

  _strike(player, reason) {
    player.strikes += 1;
    const shouldDisconnect = player.strikes >= MAX_STRIKES;
    return { accepted: false, reason, shouldDisconnect };
  }

  handleSelectVehicle(socketId, payload, transport) {
    const player = this.players.get(socketId);
    if (!player) return { accepted: false, reason: 'not_joined' };
    if (!payload || !isValidVehicleSelection(payload.vehicleId)) {
      return { accepted: false, reason: 'invalid_vehicle' };
    }
    player.vehicleId = payload.vehicleId;
    transport.broadcastToOthers('playerVehicleChanged', { id: player.id, vehicleId: player.vehicleId });
    return { accepted: true };
  }

  handleQuickChat(socketId, payload, transport) {
    const player = this.players.get(socketId);
    if (!player) return { accepted: false, reason: 'not_joined' };
    if (!this.chatLimiter.tryConsume(socketId)) {
      return { accepted: false, reason: 'rate_limited' };
    }
    if (!payload || !isValidQuickChatId(payload.messageId)) {
      return { accepted: false, reason: 'invalid_message' };
    }
    transport.broadcastToOthers('quickChat', { id: player.id, messageId: payload.messageId });
    return { accepted: true };
  }

  handleDisconnect(socketId, transport) {
    const player = this.players.get(socketId);
    if (!player) return { accepted: false, reason: 'not_joined' };
    this.players.delete(socketId);
    this.moveLimiter.reset(socketId);
    this.chatLimiter.reset(socketId);
    transport.broadcastToOthers('playerLeft', { id: socketId });
    return { accepted: true };
  }
}

function publicView(player) {
  return { id: player.id, name: player.name, vehicleId: player.vehicleId, x: player.x, y: player.y, z: player.z, rotationY: player.rotationY };
}
