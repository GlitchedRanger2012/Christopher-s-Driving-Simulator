// server/src/index.js
// Entry point: `node server/src/index.js` (or `npm start` from server/).
// This file is intentionally thin — it just adapts real socket.io events to
// GameServer's transport-agnostic methods. All the actual game/anti-cheat
// logic lives in GameServer.js and is covered by server/test/*.mjs.

import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { GameServer } from './GameServer.js';

const PORT = process.env.PORT || 3001;
// In production, set this to your deployed frontend's exact origin, e.g.
// https://your-username.github.io — using '*' is fine for local development
// only. See README.md "Deploying the backend".
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || '*';

const gameServer = new GameServer();

const httpServer = createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', players: gameServer.getPlayerCount() }));
    return;
  }
  res.writeHead(404);
  res.end();
});

const io = new Server(httpServer, {
  cors: { origin: CLIENT_ORIGIN },
});

function transportFor(socket) {
  return {
    emitToSelf: (event, data) => socket.emit(event, data),
    broadcastToOthers: (event, data) => socket.broadcast.emit(event, data),
  };
}

io.on('connection', (socket) => {
  socket.on('join', (payload) => {
    const result = gameServer.handleJoin(socket.id, payload, transportFor(socket));
    if (!result.accepted && result.reason === 'server_full') {
      socket.disconnect(true);
    }
  });

  socket.on('move', (payload) => {
    const result = gameServer.handleMove(socket.id, payload, transportFor(socket));
    if (result.shouldDisconnect) {
      console.warn(`[server] disconnecting ${socket.id} after repeated invalid packets`);
      socket.disconnect(true);
    }
  });

  socket.on('selectVehicle', (payload) => {
    gameServer.handleSelectVehicle(socket.id, payload, transportFor(socket));
  });

  socket.on('quickChat', (payload) => {
    gameServer.handleQuickChat(socket.id, payload, transportFor(socket));
  });

  socket.on('disconnect', () => {
    gameServer.handleDisconnect(socket.id, transportFor(socket));
  });
});

httpServer.listen(PORT, () => {
  console.log(`Christopher's Driving Simulator — multiplayer server listening on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
  console.log(`CORS origin: ${CLIENT_ORIGIN}`);
});
