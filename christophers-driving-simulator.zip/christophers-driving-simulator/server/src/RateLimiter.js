// server/src/RateLimiter.js
// A plain sliding-window limiter: at most `maxEvents` accepted per `windowMs`
// per key. No dependencies, so it's directly unit-testable (see
// server/test/rateLimiter.test.mjs).

export class RateLimiter {
  constructor({ maxEvents, windowMs }) {
    this.maxEvents = maxEvents;
    this.windowMs = windowMs;
    this.hits = new Map(); // key -> timestamps within the current window
  }

  tryConsume(key, now = Date.now()) {
    let arr = this.hits.get(key);
    if (!arr) {
      arr = [];
      this.hits.set(key, arr);
    }
    while (arr.length && now - arr[0] > this.windowMs) arr.shift();
    if (arr.length >= this.maxEvents) return false;
    arr.push(now);
    return true;
  }

  reset(key) {
    this.hits.delete(key);
  }
}
