# Server — Christopher's Driving Simulator

The authoritative multiplayer server: a small Node.js app using Socket.IO
for real-time networking, with no database (all state is in-memory and
per-process).

## Architecture

`src/GameServer.js` contains all the actual game/anti-cheat logic and has
**zero import of socket.io** — it takes a plain `{ emitToSelf,
broadcastToOthers }` transport object instead of talking to sockets
directly. `src/index.js` is the thin real-socket.io wiring on top of it.

This split exists specifically so the logic that matters most (validating
what clients claim) can be unit tested with a fake transport, no real
network and no installed dependencies required — see `test/`.

## Run locally

```bash
npm install
npm start            # http://localhost:3001
npm run dev           # same, but restarts on file changes (node --watch)
```

## Test

```bash
npm test
# or individually:
node test/gameServer.test.mjs
node test/rateLimiter.test.mjs
```

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `3001` | HTTP/WebSocket listen port |
| `CLIENT_ORIGIN` | `*` | CORS origin allowed to connect — set this to your deployed frontend's exact origin in production |

## Protocol summary

Client → server: `join`, `move`, `selectVehicle`, `quickChat`.
Server → client: `joined` (sent once, to the joining socket only —
carries your assigned spawn point and the current roster), `joinRejected`,
`playerJoined`, `playerLeft`, `playerMoved`, `playerVehicleChanged`,
`quickChat`.

Every inbound event is validated against `../shared/validation.js` before
it's trusted or broadcast — see `src/GameServer.js` for exactly what's
checked (world bounds, speed plausibility versus the claimed vehicle's own
top speed, rate limits) and `TESTING_REPORT.md` at the repo root for what's
been verified to actually catch bad input.

## Deploying

See the repository root `README.md`, "Deploying the backend" — this app has
no special requirements beyond a Node 18+ runtime and a way to set the two
environment variables above.
