# Christopher's Driving Simulator

A browser-based 3D driving game built with HTML5, CSS3, JavaScript, and
Three.js (WebGL) — 45 original vehicles across 8 categories, a procedurally
generated city to drive around in, real (if intentionally simplified)
vehicle physics, and optional real-time multiplayer over Socket.IO with an
authoritative, anti-cheat-checked server.

Created by **Christopher Ranger**. See `TERMS_OF_SERVICE.md`, `LICENSE`, and
`THIRD_PARTY_LICENSES.md` for the legal/attribution details, and
`TESTING_REPORT.md` for exactly what has and hasn't been verified.

## Quick start (singleplayer, no install needed)

Singleplayer needs no build step and no dependencies — it's just static
files. It does need to be served over `http://`, not opened as a local
`file://` path, because browsers block ES module imports (which this project
uses throughout) from `file://` URLs.

```bash
# From the repository root, any static file server works. For example:
python3 -m http.server 8000
# or: npx serve .

# Then open:
http://localhost:8000
```

## Running multiplayer locally

Multiplayer needs the server in `server/` running separately.

```bash
cd server
npm install
npm start
# Listening on http://localhost:3001 by default
```

With the frontend served locally (see above) and `client/js/config.js`
detecting `localhost`, it automatically points at `http://localhost:3001` —
no configuration needed for local testing. Open the game in two browser tabs
and use Multiplayer in both to test it against yourself.

## Deploying the frontend to GitHub Pages

1. Create a new GitHub repository and push this project to it:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<your-repo>.git
   git push -u origin main
   ```
2. In the repository on GitHub: **Settings → Pages → Build and deployment
   → Source → GitHub Actions**. The included workflow
   (`.github/workflows/deploy-pages.yml`) runs the vehicle-data and
   import-graph checks and the server test suite, then deploys automatically
   on every push to `main`.
3. Your game will be live at `https://<your-username>.github.io/<your-repo>/`.

GitHub Pages only serves static files — it cannot run the multiplayer
server in `server/`. Singleplayer will work immediately; multiplayer needs
the steps below first.

## Deploying the backend (multiplayer server)

`server/` is a small Node.js + Socket.IO app with no database — deploy it to
any Node hosting platform that supports persistent WebSocket connections
(GitHub Pages, being static-only, cannot run it). Render, Railway, Fly.io,
and a plain VPS all work; the general steps are the same everywhere:

1. Point the platform at the `server/` directory (or its own repo/subtree)
   with `npm install` as the build command and `npm start` as the run
   command.
2. Set the environment variable `CLIENT_ORIGIN` to your deployed frontend's
   exact origin, e.g. `https://your-username.github.io` (no trailing path).
   This is required for the browser's CORS check to allow the connection —
   leaving it unset defaults to `*`, which works but is not recommended
   for a real deployment.
3. Note the public URL the platform gives your service, e.g.
   `https://your-app.onrender.com`. Socket.IO negotiates the WebSocket
   upgrade itself, so you use the plain `https://` URL, not `wss://`,
   when configuring the client (next step).

## Configuring the client with your deployed backend

Do **not** hard-code `localhost` as a production fallback. Edit
`client/js/config.js`:

```js
const PRODUCTION_SERVER_URL = 'https://your-app.onrender.com'; // your deployed server
```

Commit that change and push — the next GitHub Pages deploy will pick it up.
You can also override the server URL at any time without rebuilding, by
adding `?server=https://your-app.onrender.com` to the deployed game's URL —
useful for testing a staging backend.

## Controls

| Action | Default key | Gamepad |
|---|---|---|
| Accelerate | `W` / `↑` | Right trigger |
| Brake / Reverse | `S` / `↓` | Left trigger |
| Steer | `A`/`D` or `←`/`→` | Left stick |
| Handbrake | `Space` | Face button 1 |
| Reset vehicle | `R` | Face button 2 |
| Change camera | `C` | — |
| Pause | `Esc` | Start |

All bindings are rebindable in Settings → Controls.

## Project structure

```
christophers-driving-simulator/
├── index.html              entry point (served as-is by GitHub Pages)
├── client/
│   ├── css/style.css
│   ├── js/
│   │   ├── main.js             boot sequence
│   │   ├── config.js            multiplayer server URL
│   │   ├── vendor/three.js      pinned Three.js CDN re-export
│   │   ├── core/                 engine, input, save, audio, loading
│   │   ├── vehicles/             physics, procedural mesh factory, controller
│   │   ├── world/                deterministic city generator + scene builder
│   │   ├── camera/               chase camera
│   │   ├── ui/                   every screen (menu, car select, settings, HUD, ...)
│   │   ├── game/                 session/state management (singleplayer + multiplayer)
│   │   └── multiplayer/          Socket.IO client wrapper
│   └── assets/               (empty by design — see client/assets/README.md)
├── shared/                  used by BOTH client and server
│   ├── constants.js
│   ├── vehicleData.js        the 45-car catalog
│   ├── validation.js         anti-cheat / input validation (client + server)
│   └── termsContent.js       Terms of Service, as data
├── server/                  Node.js + Socket.IO multiplayer server
│   ├── src/                  GameServer.js has NO socket.io import — see below
│   └── test/                 real, runnable tests for the server logic
├── scripts/                 dev tools (see "Development tools" below)
└── .github/workflows/       GitHub Pages auto-deploy
```

## Development tools

```bash
node scripts/validate-vehicles.mjs   # checks all 45 cars have valid, distinct data
node scripts/check-imports.mjs       # every import path resolves to a real export
node scripts/generate-terms-md.mjs   # regenerates TERMS_OF_SERVICE.md from shared/termsContent.js
node server/test/gameServer.test.mjs # authoritative server logic — see TESTING_REPORT.md
node server/test/rateLimiter.test.mjs
```

Or run everything at once: `npm test` from the repository root.

## Known limitations

Being upfront about scope, per `TESTING_REPORT.md`:

- **Vehicles are procedural, not 45 unique models.** Each of the 45 cars has
  genuinely distinct, hand-tuned stats that the physics engine actually
  reads, and 8 category "silhouette" templates give them different
  proportions and colors. They are not 45 individually hand-modeled meshes —
  that was out of scope for a code-only build. See
  `client/js/vehicles/VehicleFactory.js`.
- **Physics is arcade-style, not a full rigid-body simulation.** Ground
  contact, grip, drift, and collision all use simplified, common
  approximations (see the comments in `VehiclePhysics.js`), not a physics
  engine with true per-wheel suspension or tire slip-angle curves.
- **Multiplayer is validated-client-authoritative, not fully
  server-simulated.** The server independently checks every position update
  for world bounds, speed plausibility given the vehicle's own top speed,
  and rate limits (see `server/src/GameServer.js` and its test suite) and
  disconnects clients that repeatedly send invalid data — but it does not
  re-run physics itself. A sufficiently motivated client-side cheat could
  still misreport position within those bounds. The Terms of Service are
  intentionally honest about this ("not a guarantee that cheating is
  impossible").
- **Camera has no collision handling** — it can clip through buildings if
  you park against one.
- **Incoming multiplayer quick-chat has no on-screen speech bubble yet** —
  see the comment in `GameStateManager.js`.
- **No audio files** — every sound is synthesized at runtime with WebAudio
  rather than using recorded/licensed audio. This avoids any licensing risk
  but doesn't sound like a real engine recording.
- **This environment could not visually test WebGL rendering.** Every module
  was syntax-checked, and the pure-logic modules (physics, world generation,
  validation, the multiplayer server) were actually executed against real
  test scenarios (see `TESTING_REPORT.md`) — but nothing here can open a
  real browser with a GPU, so actual on-screen rendering, camera feel, and
  visual polish still need a human to open the game and check.

## License

Original code and assets are © Christopher Ranger — see `LICENSE` for reuse
and attribution terms. Third-party components are listed with their own
licenses in `THIRD_PARTY_LICENSES.md`.
