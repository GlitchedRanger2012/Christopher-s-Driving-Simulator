# Testing Report

This documents what was actually tested during development, what bugs that
testing found and fixed, and — just as important — what this environment
could **not** test, so nothing here is overclaimed. "Everything works" is
never stated unless it was actually run and checked.

## Environment constraints that shaped what's below

The build environment for this project is a sandboxed Linux container with
**no outbound network access for package installation** (`npm install`
cannot reach the npm registry) and **no browser/GPU** (nothing can open a
real Chrome/Firefox window or create a WebGL context). Two things followed
from that:

1. **`server/`'s only npm dependency, socket.io, could not be installed
   here**, so the real socket.io wire protocol was never exercised
   end-to-end in this environment. To still get real, run test coverage of
   the part that matters most — whether the server correctly trusts or
   rejects what a client sends — `GameServer.js` was deliberately written
   with **zero import of socket.io**, taking a plain transport object
   instead (see its file header). That let its actual, shipped logic run
   directly under plain Node with a fake transport standing in for real
   sockets.
2. **Three.js could not be fetched from its CDN inside this environment**
   either (same reason). For the two modules whose logic was worth testing
   with real execution rather than just reading — `VehiclePhysics.js` and
   `World.js` — a minimal local stub implementing only the handful of
   THREE.js APIs those files actually use (`Vector3`, `MathUtils`, and for
   World.js the geometry/material/light constructors) was swapped in for
   `client/js/vendor/three.js`, the tests were run against the real,
   unmodified physics/world source files, and the CDN-backed version was
   restored immediately after. The shipped `vendor/three.js` always points
   at the real CDN — the stub was test-only and never shipped.

## What was actually run, and what it found

### `scripts/validate-vehicles.mjs` — vehicle data integrity
Ran successfully. Confirms exactly 45 vehicles, no duplicate ids or names,
every category represented, every stat within a plausible range, valid hex
colors. **Result: pass, no issues found.**

### `shared/validation.js` — anti-cheat / input validation primitives
Exercised directly with both valid and deliberately hostile inputs (script
tags in names, `NaN` coordinates, out-of-world coordinates, a 5000 km/h
implied speed). **Result: pass** — later reused by the GameServer tests
below, where it caught a real bug (next section).

### `client/js/vehicles/VehiclePhysics.js` — 17 assertions, real execution
Covered: a faster car actually outpaces a slower one; simulated 0-100km/h
time is in the right ballpark of each car's own `acceleration` stat (checked
for 3 different cars); simulated braking distance is in the right ballpark
of the `braking` stat; a handbrake turn at speed produces a real slide
(`drifting=true`, nonzero lateral speed) while gentle low-speed steering
does not; driving into a wall stops the car, keeps it outside the wall's
bounds, and fires a collision event; driving off a ledge produces real
airborne state (gravity, falling, landing at the new height); the
reset-to-safe-position recovery returns to a previously recorded good spot
rather than the crash site; gear/RPM stay in a sane, speed-correlated band.

**Two real bugs found and fixed:**
- Handbrake applied a full braking-strength deceleration that could cancel
  out a moderate throttle input entirely, meaning a handbrake-turn attempted
  from a stop (or at low speed) could never build enough speed to actually
  break rear grip — the car would just sit there. Fixed by reducing the
  handbrake's direct speed penalty to a mild scrub; its real job (cutting
  `effectiveMaxLateral` grip) already does the work of enabling the slide.
- `resetToSafePosition()` reset position/velocity but left gear/RPM at
  whatever they were the instant before the reset, so the HUD could show a
  stale high gear/RPM for one frame after resetting a car that had been
  moving fast. Fixed by also resetting gear to 1 and RPM to idle.

### `client/js/world/TrackGenerator.js` — determinism, real execution
Has no THREE.js dependency at all (pure data), so no stub was needed. Same
seed reliably produces byte-identical layouts; a different seed produces a
different layout; the 7×7 block grid produces exactly 49 blocks with a
sane category mix; the spawn plaza is reliably near the world center.
**Result: pass, no issues found.**

### `client/js/world/World.js` — 7 assertions, real execution
Construction (turning generated layout data into an actual scene graph)
completes without throwing and produces a non-trivial collider set (111
colliders for seed 1337). Ground-height sampling is flat in the city core,
climbs correctly along a ramp's length up to close to its configured max
height, and picks up non-zero rolling terrain out in the off-road
perimeter. The spatially-bucketed collider query returns a real (non-empty
when relevant, and much smaller than the full city) subset — confirmed it's
actually doing spatial partitioning rather than silently degrading to a
full scan. **Result: pass, no issues found** (built cleanly on the first run).

### `server/src/GameServer.js` — 33 assertions, real execution, no stub needed
This one runs completely unmodified in plain Node with no fakes for its own
code — only the transport (socket.io itself) is fake, exactly as it would
be replaced by real sockets in `server/src/index.js`. Covered: spawn
assignment (two joining players don't land on the same spot), the new
`joined`/`playerJoined` handshake, a bogus `vehicleId` on join being
silently corrected rather than trusted, valid moves being applied and
broadcast, a malformed (`NaN`) transform being rejected without being
applied or broadcast, an in-world-bounds-but-physically-implausible jump
being rejected specifically as `implausible_movement` (as distinct from a
value so far outside the world it's caught by the separate bounds check),
move-rate limiting engaging above the 30/second hard cap, repeated bad
packets escalating to a disconnect recommendation, vehicle-selection
validation, quick-chat validation and its own rate limit, disconnect cleanup
and notification, and a full (24-player) session correctly rejecting a 25th
join.

**One real bug found and fixed:** the speed-plausibility check computed
`distance / elapsed_time`, and when two updates landed in the same
millisecond (which happens constantly in fast synchronous test code, and
can plausibly happen on a real fast connection too) `elapsed_time` could be
`0`, making *any* movement look like infinite speed and get incorrectly
rejected. Fixed by flooring the elapsed time to a small minimum (1/120s)
before dividing, which still correctly rejects genuine teleports (even at
that floor, a multi-hundred-meter jump implies a wildly implausible speed)
while no longer false-flagging legitimate near-simultaneous updates.

### `server/src/RateLimiter.js` — 7 assertions, real execution
Sliding-window behavior, per-key isolation, and `reset()` all verified
directly. **Result: pass, no issues found.**

### `scripts/check-imports.mjs` — static cross-reference, real execution
Every `import` statement across all 29 files in `client/` and `shared/`
was checked: does the imported path resolve to a real file, and is every
named import actually exported by that file? All 29 files passed on the
final run — this class of bug (a typo'd path, a renamed export that wasn't
updated everywhere) is exactly the kind of thing that would otherwise only
surface as a browser console error. Two earlier drafts of
`VehicleController.js` were caught and rewritten during development for a
related but distinct issue (see below) before this check was even written.

### `.github/workflows/deploy-pages.yml` — real YAML parse
Parsed with a real YAML library rather than eyeballed. Caught the classic
GitHub Actions gotcha where an unquoted `on:` key is technically read as the
boolean `true` under YAML 1.1 — GitHub's own workflow parser special-cases
this and it would have worked regardless, but it was quoted (`"on":`)
anyway to remove any ambiguity for other tooling.

### `package.json` / `server/package.json` — real JSON parse
Both validated as well-formed JSON.

### A design bug caught during code review (not by a test)
While wiring `VehicleController.js`, reading through the remote-multiplayer
code path surfaced that wheel-spin animation was driven by
`physics.getTelemetry().speedKph` — which is always `0` for a remote
player, because a remote player's `VehiclePhysics` instance never has
`update()` called on it (only its position is set directly from network
data). A remote car would have visibly slid across the map with its wheels
never turning. Fixed by driving wheel spin off actual distance traveled
since the last sync (arc length ÷ wheel radius) instead, which works
identically whether the position change came from local physics or a
network update.

## What this environment could not test

- **Actual WebGL rendering.** Nothing here can open a real browser or
  create a GPU-backed WebGL context, so the 3D scene has never actually
  been *seen* — geometry could still be misplaced, materials could look
  wrong, and none of that would show up in a syntax check or a headless
  logic test.
- **A real two-client multiplayer session over the network**, using the
  actual socket.io library end to end (blocked by the same lack of network
  access that prevented `npm install`). The transport-agnostic design means
  the logic that *would* run on those messages was tested directly — but
  the real wire protocol, reconnection behavior, and actual network latency
  were not.
- **Gamepad input**, for lack of physical hardware attached to this
  environment.
- **Visual/UI correctness** — layout at real screen sizes, the menu
  animation, whether the car-select grid actually looks good, contrast,
  and general polish. The HTML/CSS was written carefully and reviewed, not
  screenshot-tested.
- **Camera feel** — whether the chase camera's follow/look-ahead tuning
  actually feels good is inherently a play-test judgment call, not
  something a script can assert.
- **Cross-browser behavior** (Safari/Firefox/mobile browser quirks).
- **Performance under real load** — instancing and collider-bucketing are
  real, deliberate optimizations (see `World.js`), but neither was
  benchmarked against an actual frame budget.

## Recommended next step

Open `index.html` over a local static server (see README "Quick start"),
drive around, try a few different cars from each category, and try
multiplayer locally with the server running (two browser tabs). Anything
that looks or feels wrong — report it and it can be fixed the same way the
bugs above were: find it, fix it in the real source, re-verify, and note it
here.
