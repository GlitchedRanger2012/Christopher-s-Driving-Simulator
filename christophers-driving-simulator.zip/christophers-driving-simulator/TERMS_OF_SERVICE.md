# Christopher's Driving Simulator — Terms of Service

Version 1.0.0 · Effective 2026-09-22

> This document is auto-generated from `shared/termsContent.js` — the same data the in-game Terms of Service screen renders. Edit that file and re-run `node scripts/generate-terms-md.mjs` rather than editing this file directly, or the two will drift out of sync.

## 1. Acceptance of these Terms

These Terms of Service ("Terms") govern your use of Christopher's Driving Simulator (the "Game"). By clicking "Accept" you agree to these Terms. If you don't agree, click "Decline" and don't use the Game.

This is version 1.0.0, effective 2026-09-22. If a future version changes these Terms in a way that matters, you'll be asked to accept the new version before you can keep playing — your previous acceptance doesn't carry over automatically.

## 2. What the Game is

Christopher's Driving Simulator is a browser-based 3D driving game with a singleplayer mode and an optional online multiplayer mode. It runs entirely in your browser; the multiplayer mode additionally connects to a server that relays player positions and a small set of preset "quick chat" messages between connected players.

## 3. Accounts

The Game does not currently require an account, and no accounts exist as of this version. If account functionality is added in the future, this section will be updated and you'll be asked to re-accept these Terms.

## 4. Acceptable use

When using the Game, especially in multiplayer, you agree not to:

- Cheat, exploit bugs, or use unauthorized third-party software to gain an advantage or disrupt other players.
- Attempt to overload, flood, or otherwise disrupt the multiplayer server or other players’ connections.
- Harass, threaten, or abuse other players, including through repeated or targeted misuse of the quick-chat system.
- Attempt to gain unauthorized access to the multiplayer server, other players’ sessions, or any non-public part of the Game.
- Modify the client in a way intended to falsify data sent to the server (for example, reporting a position or vehicle the server did not authorize).

The server independently validates the movement and vehicle data it receives (see THIRD_PARTY_LICENSES.md and the project README for the technical detail) and may reject implausible updates or disconnect a client that repeatedly sends invalid data. This is a reasonable, good-faith anti-abuse measure, not a guarantee that cheating is impossible.

## 5. User-generated content

The Game currently allows very limited user input into shared spaces: a driver name (shown to other players in multiplayer) and a fixed set of preset "quick chat" phrases. You're responsible for the driver name you choose; names that are abusive, impersonate others, or violate these Terms may be reset or blocked. If free-text chat or other user-generated content is added in the future, this section will be updated.

## 6. Intellectual property and attribution

Except for the third-party software and assets identified in THIRD_PARTY_LICENSES.md, the original code, game design, vehicle data, and other creative assets made for Christopher's Driving Simulator are the work of Christopher Ranger ("the Creator").

The project’s LICENSE file sets out the specific terms under which this original code and these original assets may be reused. In summary, and subject to the LICENSE file controlling in the event of any conflict:

- Code — if you reuse original code from this project, you must give appropriate credit to Christopher Ranger, as described in LICENSE.
- Assets — if you reuse original assets created for this project by Christopher Ranger, you must give appropriate credit to Christopher Ranger, as described in LICENSE.
- Derivative projects — if you build a project substantially based on this project’s original code or assets, that project must include appropriate attribution to Christopher Ranger, as described in LICENSE.

None of this applies to third-party code, libraries, fonts, or other assets used by the Game — those remain under their own owners’ copyright and their own licenses, listed in THIRD_PARTY_LICENSES.md. The Creator does not claim ownership of any third-party material, and nothing in these Terms should be read as such a claim.

## 7. Third-party software and assets

The Game uses third-party open-source libraries (for example a 3D rendering library and a multiplayer networking library) and may use third-party fonts. These are listed, with their licenses, in THIRD_PARTY_LICENSES.md. Your use of those components is also subject to their own license terms.

## 8. Privacy

See PRIVACY.md for what limited information the Game processes (primarily: settings and your Terms acceptance stored in your browser’s local storage, and, in multiplayer, your chosen driver name, vehicle selection, and in-game position relayed through the multiplayer server for the duration of your session).

## 9. Service availability

Singleplayer runs locally in your browser and doesn’t depend on any server the Creator operates. The multiplayer server, where one is deployed, is provided on an "as available" basis, may be unavailable, rate-limited, or discontinued at any time, and is not guaranteed to be free of downtime, latency, or data loss.

## 10. Changes to these Terms

These Terms may be updated over time. When a change is significant enough to require it, the Terms version number will be incremented and you’ll be asked to accept the updated Terms the next time you launch the Game before you can continue playing.

## 11. Termination and restriction of access

Where the Creator operates a shared multiplayer server, access to that server may be limited, rate-limited, or terminated for a given player or client at the Creator’s discretion, including for violations of Section 4. This does not affect your ability to play the singleplayer mode of the Game, which runs entirely in your own browser.

## 12. Disclaimer of warranties

The Game is provided "as is" and "as available," without warranties of any kind, express or implied, to the fullest extent permitted by applicable law. The Creator does not warrant that the Game will be uninterrupted, error-free, or free of harmful components.

## 13. Limitation of liability

To the fullest extent permitted by applicable law, the Creator is not liable for any indirect, incidental, special, or consequential damages arising from your use of, or inability to use, the Game.

## 14. Governing law

[Placeholder — the Creator should specify the jurisdiction and governing law that apply to these Terms before relying on this document for a public release.]

## 15. Contact

Questions about these Terms can be sent to: [email protected] (replace with a real contact address before deploying this project).

---

**This is a template drafted for a hobby project and is not legal advice.** Christopher Ranger (or whoever deploys this project) should have it reviewed by a lawyer before relying on it for a real public release, especially the placeholder governing-law and contact sections above.
