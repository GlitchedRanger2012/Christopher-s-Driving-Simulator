# Third-Party Licenses

Christopher's Driving Simulator is original work by Christopher Ranger (see
LICENSE), except for the third-party software and fonts listed below. None
of this is claimed as Christopher Ranger's own work.

## Three.js

- **Used for:** WebGL 3D rendering (`client/js/vendor/three.js` re-exports
  it from a CDN; see that file for the pinned version).
- **Source:** https://github.com/mrdoob/three.js/
- **License:** MIT License. Full text: https://github.com/mrdoob/three.js/blob/dev/LICENSE
- **How it's loaded:** as an ES module from `https://cdn.jsdelivr.net/npm/three@0.170/...`
  at runtime — it is not bundled into this repository's own source files.

## Socket.IO

- **Used for:** real-time multiplayer networking, both the client
  (`client/js/multiplayer/NetworkClient.js`, loaded from
  `https://cdn.socket.io/...` via `<script>` in `index.html`) and the server
  (`server/src/index.js`, installed as an npm dependency —
  see `server/package.json`).
- **Source:** https://github.com/socketio/socket.io
- **License:** MIT License. Full text: https://github.com/socketio/socket.io/blob/main/LICENSE

## Rajdhani (font)

- **Used for:** display/heading typography (menus, HUD).
- **Source:** https://fonts.google.com/specimen/Rajdhani, loaded via the
  Google Fonts CDN (see the `<link>` tags in `index.html`).
- **License:** SIL Open Font License, version 1.1. Full text:
  https://openfontlicense.org/documents/OFL.txt

## Public Sans (font)

- **Used for:** body typography (settings, Terms of Service, general UI text).
- **Source:** https://fonts.google.com/specimen/Public+Sans, loaded via the
  Google Fonts CDN.
- **License:** SIL Open Font License, version 1.1. Full text:
  https://openfontlicense.org/documents/OFL.txt

## The MIT License (reference text)

Three.js and Socket.IO are both distributed under the MIT License, reproduced
here for reference (the canonical text lives at the links above and governs
in the event of any discrepancy):

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
```

## No other third-party assets

This project does not include any other third-party 3D models, textures,
audio files, or code beyond what's listed above. Vehicle appearances are
built procedurally from primitive geometry in
`client/js/vehicles/VehicleFactory.js`, and all in-game audio is synthesized
at runtime by `client/js/core/AudioManager.js` — see README.md "Known
limitations" for what that trade-off means in practice. If you add real
third-party assets (models, textures, music, sound effects) to your own copy
of this project, add them to this file with their source and license before
distributing your build.
